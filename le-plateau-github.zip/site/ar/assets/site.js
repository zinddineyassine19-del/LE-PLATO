window.CLEL_AMBIANCE="../ambiance.mp3";
/* Le Plateau — site behaviour
   thème, menu mobile, barre de progression, recherche plein texte */
(function () {
  'use strict';

  /* ---------------- theme ---------------- */
  var KEY = 'clel-theme';
  function apply(t) {
    if (t === 'dark' || t === 'light') document.documentElement.setAttribute('data-theme', t);
    else document.documentElement.removeAttribute('data-theme');
    var b = document.getElementById('themeBtn');
    if (b) {
      var dark = t === 'dark' || (t !== 'light' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);
      b.setAttribute('aria-label', dark ? 'Passer en mode clair' : 'Passer en mode sombre');
      b.querySelector('.lbl').textContent = dark
        ? (b.dataset.jour || 'Jour') : (b.dataset.nuit || 'Nuit');
      b.querySelector('.i-sun').style.display = dark ? '' : 'none';
      b.querySelector('.i-moon').style.display = dark ? 'none' : '';
    }
  }
  var stored = null;
  try { stored = localStorage.getItem(KEY); } catch (e) {}
  apply(stored);

  document.addEventListener('click', function (e) {
    var t = e.target.closest && e.target.closest('#themeBtn');
    if (!t) return;
    var cur = document.documentElement.getAttribute('data-theme');
    var sysDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    var next = cur ? (cur === 'dark' ? 'light' : 'dark') : (sysDark ? 'light' : 'dark');
    try { localStorage.setItem(KEY, next); } catch (e2) {}
    apply(next);
  });

  /* ---------------- mobile drawer ---------------- */
  var side = document.querySelector('.side'), scrim = document.querySelector('.scrim');
  function drawer(on) {
    if (!side) return;
    side.classList.toggle('open', on);
    if (scrim) scrim.classList.toggle('on', on);
    document.body.style.overflow = on ? 'hidden' : '';
  }
  var mb = document.getElementById('menuBtn');
  if (mb) mb.addEventListener('click', function () { drawer(!side.classList.contains('open')); });
  if (scrim) scrim.addEventListener('click', function () { drawer(false); });
  if (side) side.addEventListener('click', function (e) {
    if (e.target.closest('a')) drawer(false);
  });

  /* ------- révéler le chapitre courant dans le sommaire ------- */
  var cur = document.querySelector('.side a[aria-current="page"]');
  if (cur && side && side.scrollHeight > side.clientHeight + 8) {
    side.scrollTop = Math.max(0, cur.offsetTop - side.clientHeight / 2 + cur.offsetHeight / 2);
  }

  /* ---------------- reading progress ---------------- */
  var bar = document.querySelector('.progress');
  if (bar) {
    var tick = function () {
      var h = document.documentElement;
      var max = h.scrollHeight - h.clientHeight;
      bar.style.width = (max > 40 ? (h.scrollTop / max) * 100 : 0) + '%';
    };
    addEventListener('scroll', tick, { passive: true });
    addEventListener('resize', tick);
    tick();
  }

  /* ============================================================
     Les schémas se dessinent à l'entrée dans le cadre
     ============================================================ */
  (function () {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var figs = document.querySelectorAll('figure:not(.ix)');
    if (!figs.length || !('IntersectionObserver' in window)) return;
    document.documentElement.classList.add('anim');

    var GEO = { line: 1, path: 1, polyline: 1, polygon: 1, circle: 1, ellipse: 1, rect: 1 };

    function prime(fig) {
      if (fig.dataset.primed) return;
      fig.dataset.primed = '1';
      var svg = fig.querySelector('svg');
      if (!svg) return;
      var nodes = svg.querySelectorAll('*'), n = 0;
      for (var i = 0; i < nodes.length; i++) {
        var el = nodes[i];
        if (el.closest('defs, clipPath, mask, marker, linearGradient, radialGradient, pattern')) continue;
        var tag = el.tagName.toLowerCase();
        var delay = Math.min(n * 13, 620);
        if (GEO[tag] && typeof el.getTotalLength === 'function') {
          var cs = getComputedStyle(el);
          var stroked = cs.stroke && cs.stroke !== 'none';
          var dashed = cs.strokeDasharray && cs.strokeDasharray !== 'none';
          if (stroked && !dashed) {
            var len = 0;
            try { len = el.getTotalLength(); } catch (e) { len = 0; }
            if (len > 0.5 && len < 12000) {
              el.style.setProperty('--l', len.toFixed(1));
              el.style.setProperty('--d', delay + 'ms');
              el.classList.add('dw');
              n++;
              continue;
            }
          }
        }
        if (tag === 'text' || tag === 'use' || tag === 'image' ||
            (GEO[tag] && !el.classList.contains('dw'))) {
          el.style.setProperty('--d', (delay + 260) + 'ms');
          el.classList.add('fdin');
          n++;
        }
      }
    }

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        prime(e.target);
        requestAnimationFrame(function () { e.target.classList.add('seen'); });
        io.unobserve(e.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });

    for (var i = 0; i < figs.length; i++) io.observe(figs[i]);
  })();

  /* ============================================================
     Le texte se pose : ouverture de chapitre, intertitres, encadrés
     ============================================================ */
  (function () {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    if (!('IntersectionObserver' in window)) return;
    var sel = '.ch-h, .ch h3, .tw, .tip, .note, .warn, .close';
    var els = document.querySelectorAll(sel);
    if (!els.length) return;
    document.documentElement.classList.add('anim');

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        e.target.classList.add('seen');
        io.unobserve(e.target);
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.12 });

    for (var i = 0; i < els.length; i++) {
      els[i].classList.add('rv');
      io.observe(els[i]);
    }
  })();

  /* ============================================================
     Loupe : n'importe quel schéma s'ouvre en plein écran
     ============================================================ */
  (function () {
    var dlg = document.getElementById('zdlg');
    if (!dlg) return;
    var wrap = dlg.querySelector('#zWrap'), cap = dlg.querySelector('#zCap'),
        name = dlg.querySelector('#zdlgN');
    var zw = 0, zx = 0, zy = 0, base = 0;

    var ICON = '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/>' +
               '<path d="M20 20l-3.5-3.5M8 11h6M11 8v6"/></svg>';

    function apply() {
      wrap.style.setProperty('--zw', zw + 'px');
      wrap.style.setProperty('--zx', zx + 'px');
      wrap.style.setProperty('--zy', zy + 'px');
    }
    function fit() { zw = base; zx = 0; zy = 0; apply(); }
    function scale(f) { zw = Math.max(280, Math.min(9000, zw * f)); apply(); }

    function open(fig) {
      var svg = fig.querySelector('svg');
      if (!svg) return;
      wrap.innerHTML = '';
      var c = svg.cloneNode(true);
      c.removeAttribute('style');
      wrap.appendChild(c);
      var f = fig.querySelector('figcaption');
      cap.textContent = f ? f.textContent.trim() : '';
      var lab = f ? (f.textContent.trim().match(/^Fig\.\s*[\d.]+/) || [''])[0] : '';
      name.textContent = lab || 'Schéma';
      dlg.classList.add('on');
      document.body.style.overflow = 'hidden';
      requestAnimationFrame(function () {
        var vb = (c.getAttribute('viewBox') || '0 0 620 400').split(/[\s,]+/);
        var ar = (+vb[2] || 620) / (+vb[3] || 400);
        var w = wrap.clientWidth * 0.92, h = wrap.clientHeight * 0.92;
        base = Math.max(280, Math.min(w, h * ar));
        fit();
      });
    }
    function close() {
      dlg.classList.remove('on'); wrap.innerHTML = ''; document.body.style.overflow = '';
    }

    dlg.querySelector('#zClose').onclick = close;
    dlg.querySelector('#zFit').onclick = fit;
    dlg.querySelector('#zIn').onclick = function () { scale(1.35); };
    dlg.querySelector('#zOut').onclick = function () { scale(1 / 1.35); };
    dlg.addEventListener('wheel', function (e) {
      if (!dlg.classList.contains('on')) return;
      e.preventDefault(); scale(e.deltaY < 0 ? 1.12 : 1 / 1.12);
    }, { passive: false });

    var down = false, px = 0, py = 0;
    wrap.addEventListener('pointerdown', function (e) {
      down = true; px = e.clientX; py = e.clientY;
      wrap.classList.add('drag'); wrap.setPointerCapture(e.pointerId);
    });
    wrap.addEventListener('pointermove', function (e) {
      if (!down) return;
      zx += e.clientX - px; zy += e.clientY - py; px = e.clientX; py = e.clientY; apply();
    });
    ['pointerup', 'pointercancel'].forEach(function (t) {
      wrap.addEventListener(t, function () { down = false; wrap.classList.remove('drag'); });
    });
    addEventListener('keydown', function (e) {
      if (!dlg.classList.contains('on')) return;
      if (e.key === 'Escape') { e.preventDefault(); close(); }
      else if (e.key === '+' || e.key === '=') scale(1.25);
      else if (e.key === '-') scale(1 / 1.25);
      else if (e.key === '0') fit();
    });

    var fine = matchMedia('(hover:hover) and (pointer:fine)').matches;

    document.querySelectorAll('figure:not(.ix)').forEach(function (fig) {
      var svg = fig.querySelector('svg');
      if (!svg) return;

      var b = document.createElement('button');
      b.className = 'zoombtn'; b.type = 'button';
      b.setAttribute('aria-label', 'Agrandir le schéma');
      b.innerHTML = ICON;
      b.addEventListener('click', function () { open(fig); });
      fig.appendChild(b);
      if (!fine) return;

      /* --- la loupe suit le curseur --- */
      var lens = null, clone = null, raf = 0, tx = 0, ty = 0, Z = 1.9, D = 168;
      function build() {
        lens = document.createElement('div');
        lens.className = 'lens';
        clone = svg.cloneNode(true);
        clone.removeAttribute('style');
        /* on garde les id : url(#…) et <use> se résolvent sur l'original,
           qui est identique et vient avant dans le document. */
        clone.setAttribute('aria-hidden', 'true');
        clone.setAttribute('focusable', 'false');
        lens.appendChild(clone);
        fig.appendChild(lens);
      }
      function place() {
        raf = 0;
        var r = svg.getBoundingClientRect(), fr = fig.getBoundingClientRect();
        clone.style.width = (r.width * Z) + 'px';
        clone.style.height = (r.height * Z) + 'px';
        clone.style.left = (D / 2 - tx * Z) + 'px';
        clone.style.top = (D / 2 - ty * Z) + 'px';
        lens.style.left = (r.left - fr.left + tx - D / 2) + 'px';
        lens.style.top = (r.top - fr.top + ty - D / 2) + 'px';
      }
      svg.addEventListener('pointerenter', function (e) {
        if (e.pointerType !== 'mouse') return;
        if (!lens) build();
        lens.classList.add('on');
      });
      svg.addEventListener('pointermove', function (e) {
        if (e.pointerType !== 'mouse' || !lens) return;
        var r = svg.getBoundingClientRect();
        tx = e.clientX - r.left; ty = e.clientY - r.top;
        if (!raf) raf = requestAnimationFrame(place);
      });
      svg.addEventListener('pointerleave', function () {
        if (lens) lens.classList.remove('on');
      });
    });
  })();

  /* ---------------- search ---------------- */
  var dlg = document.getElementById('sdlg');
  if (!dlg) return;
  var input = dlg.querySelector('input'), out = dlg.querySelector('.sres');
  var sel = -1, rows = [];

  function esc(s) {
    return s.replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function fold(s) {
    return s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  }
  function mark(text, q) {
    var f = fold(text), i = f.indexOf(q);
    if (i < 0) return esc(text);
    return esc(text.slice(0, i)) + '<em>' + esc(text.slice(i, i + q.length)) + '</em>' +
      esc(text.slice(i + q.length));
  }

  function open() {
    dlg.classList.add('on');
    input.value = ''; out.innerHTML = ''; sel = -1; rows = [];
    render('');
    setTimeout(function () { input.focus(); }, 20);
  }
  function close() { dlg.classList.remove('on'); }

  function render(qraw) {
    var q = fold(qraw.trim());
    out.innerHTML = '';
    rows = [];
    var data = window.BOOK_INDEX || [];
    if (q.length < 2) {
      var html = '';
      for (var i = 0; i < Math.min(8, data.length); i++) {
        html += '<a href="' + data[i].u + '"><span class="rn">' + esc(data[i].n) +
          '</span><div class="rt">' + esc(data[i].t) + '</div>' +
          '<div class="rs">' + esc(data[i].l.slice(0, 110)) + '…</div></a>';
      }
      out.innerHTML = html || '';
      rows = Array.prototype.slice.call(out.querySelectorAll('a'));
      return;
    }
    var hits = [];
    for (var k = 0; k < data.length; k++) {
      var d = data[k];
      var inT = d.tf.indexOf(q), inB = d.bf.indexOf(q);
      if (inT < 0 && inB < 0) continue;
      var snip = '';
      if (inB >= 0) {
        var s = Math.max(0, inB - 60), e = Math.min(d.b.length, inB + q.length + 90);
        snip = (s > 0 ? '…' : '') + d.b.slice(s, e) + (e < d.b.length ? '…' : '');
      } else snip = d.l.slice(0, 130) + '…';
      var freq = 0, at = -1;
      while ((at = d.bf.indexOf(q, at + 1)) >= 0) { freq++; if (freq > 40) break; }
      hits.push({ d: d, snip: snip,
        score: (inT >= 0 ? 0 : 4000) - freq * 60 + (inB < 0 ? 9999 : inB / 40) });
    }
    hits.sort(function (a, b) { return a.score - b.score; });
    if (!hits.length) {
      out.innerHTML = '<a class="sel" style="cursor:default"><div class="rs">' +
        esc(dlg.dataset.vide || 'Aucun résultat pour') +
        ' « ' + esc(qraw.trim()) + ' ».</div></a>';
      rows = []; return;
    }
    var h2 = '';
    for (var j = 0; j < Math.min(24, hits.length); j++) {
      var x = hits[j];
      h2 += '<a href="' + x.d.u + '"><span class="rn">' + esc(x.d.n) + '</span>' +
        '<div class="rt">' + mark(x.d.t, q) + '</div>' +
        '<div class="rs">' + mark(x.snip, q) + '</div></a>';
    }
    out.innerHTML = h2;
    rows = Array.prototype.slice.call(out.querySelectorAll('a'));
    sel = -1;
  }

  function move(step) {
    if (!rows.length) return;
    if (sel >= 0) rows[sel].classList.remove('sel');
    sel = (sel + step + rows.length) % rows.length;
    rows[sel].classList.add('sel');
    rows[sel].scrollIntoView({ block: 'nearest' });
  }

  input.addEventListener('input', function () { render(input.value); });
  dlg.addEventListener('click', function (e) { if (e.target === dlg) close(); });
  var sb = document.getElementById('searchBtn');
  if (sb) sb.addEventListener('click', open);

  addEventListener('keydown', function (e) {
    var opened = dlg.classList.contains('on');
    if (!opened) {
      var tag = (e.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea') return;
      if (e.key === '/' || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k')) {
        e.preventDefault(); open(); return;
      }
      if (e.key === 'ArrowRight' && !e.metaKey && !e.ctrlKey && !e.altKey) {
        var n = document.querySelector('.pager .nxt a, .pager a.nxt'); if (n) n.click();
      }
      if (e.key === 'ArrowLeft' && !e.metaKey && !e.ctrlKey && !e.altKey) {
        var p = document.querySelector('.pager .prv a, .pager a.prv'); if (p) p.click();
      }
      return;
    }
    if (e.key === 'Escape') { e.preventDefault(); close(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
    else if (e.key === 'Enter' && sel >= 0 && rows[sel].href) { rows[sel].click(); }
  });
})();

/* le sommaire s'ouvre sur le chapitre où l'on se trouve */
(function () {
  var side = document.querySelector('.side'), cur = side && side.querySelector('a[aria-current="page"]');
  if (!side || !cur) return;
  var d = cur.offsetTop - side.clientHeight / 2 + cur.offsetHeight / 2;
  side.scrollTop = Math.max(0, d);
})();


/* ==========================================================================
   La lumière suit la main — moteur
   --------------------------------------------------------------------------
   Une seule boucle d'animation pour toute la page. Elle n'écrit que des
   variables CSS, et uniquement quand quelque chose a bougé ; dès que tout
   est au repos elle s'arrête d'elle-même.
   ========================================================================== */
(function () {
  'use strict';

  var root = document.documentElement;
  var calm = matchMedia('(prefers-reduced-motion: reduce)');
  var fine = matchMedia('(hover:hover) and (pointer:fine)');

  /* ---- le fond remonte sur la racine : les calques se glissent dessous ---- */
  function syncBg() {
    document.body.style.background = '';
    var bg = getComputedStyle(document.body).backgroundColor;
    if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
      root.style.background = bg;
      document.body.style.background = 'transparent';
    }
  }
  syncBg();
  new MutationObserver(syncBg).observe(root, { attributes: true, attributeFilter: ['data-theme'] });
  try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', syncBg); } catch (e) {}

  /* ---- les calques ---- */
  var stage = document.createElement('div');
  stage.className = 'fx-stage';
  stage.setAttribute('aria-hidden', 'true');
  var rich = document.body.classList.contains('home') ||
             !!document.querySelector('.hero');
  if (rich) root.classList.add('fx-rich');
  /* dans le fichier trilingue, seule la langue affichée compte */
  function laBooksec() {
    return document.querySelector('.L:not([hidden]) .booksec')
        || document.querySelector('.booksec');
  }
  var book = laBooksec();
  var html = book ? '<div class="fx-ground"></div>' : '';
  html += '<div class="fx-key"></div><div class="fx-fill"></div>';
  if (rich) html += '<div class="fx-beam"></div>';
  if (!calm.matches) html += '<div class="fx-grain"></div>';
  stage.innerHTML = html;
  document.body.insertBefore(stage, document.body.firstChild);
  root.classList.add('fx-on');

  /* ======================================================================
     L'état : où est la souris, où en est le scroll
     ====================================================================== */
  var W = innerWidth, H = innerHeight;
  var mx = 0.5, my = 0.34;          /* cible, en fraction d'écran */
  var cx = 0.5, cy = 0.34;          /* position lissée */
  var lum = 0;                      /* présence du curseur */
  var lumT = 0;
  var running = false, frame = 0;

  function wake() {
    if (running) return;
    running = true;
    frame = requestAnimationFrame(tick);
  }

  function setVar(n, v) { root.style.setProperty(n, v); }

  /* ---- le héros : progression du scroll dans le premier écran ---- */
  var hero = document.querySelector('.hero');
  var hp = 0, hpShown = -1, gShown = -1;
  function heroProgress() {
    if (!hero) return 0;
    var r = hero.getBoundingClientRect();
    var span = r.height || 1;
    return Math.max(0, Math.min(1, -r.top / span));
  }

  /* ======================================================================
     La boucle
     ====================================================================== */
  function tick() {
    frame = 0;
    var moved = false;

    /* lissage : la lumière n'est jamais nerveuse */
    var k = calm.matches ? 1 : 0.085;
    var dx = mx - cx, dy = my - cy, dl = lumT - lum;
    if (Math.abs(dx) > 0.0004 || Math.abs(dy) > 0.0004) {
      cx += dx * k; cy += dy * k; moved = true;
    }
    if (Math.abs(dl) > 0.004) { lum += dl * 0.07; moved = true; }

    if (moved) {
      var px = (cx - 0.5) * W, py = (cy - 0.5) * H;
      setVar('--kx', px.toFixed(1) + 'px');
      setVar('--ky', py.toFixed(1) + 'px');
      /* l'appoint répond à l'opposé, mais de moins loin : c'est un appoint */
      setVar('--fx', (-px * 0.62).toFixed(1) + 'px');
      setVar('--fy', (-py * 0.34 + H * 0.12).toFixed(1) + 'px');
      setVar('--bx', (px * 0.22).toFixed(1) + 'px');
      setVar('--lum', lum.toFixed(3));
      setVar('--pmx', (cx * 2 - 1).toFixed(3));
      setVar('--pmy', (cy * 2 - 1).toFixed(3));
    }

    if (hero) {
      var v = heroProgress();
      if (Math.abs(v - hpShown) > 0.002) {
        hp = hpShown = v;
        hero.style.setProperty('--hp', v.toFixed(3));
        moved = true;
      }
    }

    book = laBooksec();
    if (book && book.offsetParent !== null) {
      /* Le papier doit être entièrement levé AVANT que la première ligne du
         livre n'apparaisse : on l'allume un écran plus tôt, sinon on lirait
         du texte sombre sur un fond sombre le temps du fondu. */
      var top = book.getBoundingClientRect().top;
      var g = Math.max(0, Math.min(1, (H * 2 - top) / (H * 0.7)));
      if (Math.abs(g - gShown) > 0.004) {
        gShown = g;
        setVar('--inbook', g.toFixed(3));
        moved = true;
      }
    } else if (gShown !== 0) {
      gShown = 0; setVar('--inbook', '0'); moved = true;
    }

    if (moved) frame = requestAnimationFrame(tick);
    else running = false;
  }

  /* ======================================================================
     Les entrées
     ====================================================================== */
  addEventListener('resize', function () {
    W = innerWidth; H = innerHeight; hpShown = -1; wake();
  }, { passive: true });

  addEventListener('scroll', function () { wake(); }, { passive: true });

  if (fine.matches && !calm.matches) {
    addEventListener('pointermove', function (e) {
      if (e.pointerType !== 'mouse') return;
      mx = e.clientX / W; my = e.clientY / H; lumT = 1; wake();
    }, { passive: true });
    addEventListener('pointerleave', function () { lumT = 0; wake(); }, { passive: true });
    document.addEventListener('mouseleave', function () { lumT = 0; wake(); });
  }
  wake();

  /* ======================================================================
     Le titre se lève ligne par ligne
     ====================================================================== */
  (function () {
    if (calm.matches) return;
    var h = document.querySelector('.htitle');
    if (!h) return;
    var lines = [];
    /* la structure est « texte + <span class="l2">texte </span> » */
    Array.prototype.slice.call(h.childNodes).forEach(function (n) {
      if (n.nodeType === 3) {
        if (!n.textContent.trim()) return;
        lines.push({ node: n, text: n.textContent, cls: '' });
      } else if (n.nodeType === 1) {
        lines.push({ node: n, text: n.textContent, cls: n.className });
      }
    });
    if (!lines.length) return;
    var out = '';
    lines.forEach(function (l, i) {
      out += '<span class="fx-ln ' + l.cls + '" style="--d:' + (80 + i * 120) + 'ms">' +
             '<i>' + l.text.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</i></span>';
    });
    h.innerHTML = out;
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        h.querySelectorAll('.fx-ln').forEach(function (s) { s.classList.add('seen'); });
      });
    });
  })();

  /* ======================================================================
     Tout ce qui entre dans le cadre se pose
     ====================================================================== */
  (function () {
    if (calm.matches || !('IntersectionObserver' in window)) return;
    var sel = '.sec-h, .sec-p, .pcard, .acard, .hstat > div, .tocgrid > *, ' +
              '.homefoot .wrap > *, .bookcard, .cta-row';
    var els = Array.prototype.slice.call(document.querySelectorAll(sel));
    if (!els.length) return;

    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        e.target.classList.add('seen');
        io.unobserve(e.target);
      });
    }, { rootMargin: '0px 0px -7% 0px', threshold: 0.1 });

    /* le décalage se compte entre voisins, pas sur toute la page :
       une carte au bas du document ne doit pas attendre deux secondes */
    var last = null, n = 0;
    els.forEach(function (el) {
      if (el.parentElement !== last) { last = el.parentElement; n = 0; }
      el.classList.add('fx-up');
      el.style.setProperty('--d', Math.min(n * 70, 420) + 'ms');
      n++;
      io.observe(el);
    });
  })();

  /* ======================================================================
     Les cartes s'inclinent sous le curseur
     ====================================================================== */
  (function () {
    if (calm.matches || !fine.matches) return;
    var cards = document.querySelectorAll('.pcard, .acard, .bookcard');
    if (!cards.length) return;

    Array.prototype.forEach.call(cards, function (c) {
      c.classList.add('fx-tilt');
      var raf = 0, nx = 0, ny = 0, gx = 50, gy = 50;

      function paint() {
        raf = 0;
        c.style.setProperty('--tx', nx.toFixed(3));
        c.style.setProperty('--ty', ny.toFixed(3));
        c.style.setProperty('--th', '1');
        c.style.setProperty('--gx', gx.toFixed(1) + '%');
        c.style.setProperty('--gy', gy.toFixed(1) + '%');
      }
      c.addEventListener('pointermove', function (e) {
        if (e.pointerType !== 'mouse') return;
        var r = c.getBoundingClientRect();
        nx = (e.clientX - r.left) / r.width * 2 - 1;
        ny = (e.clientY - r.top) / r.height * 2 - 1;
        gx = (e.clientX - r.left) / r.width * 100;
        gy = (e.clientY - r.top) / r.height * 100;
        c.classList.add('fx-live');
        if (!raf) raf = requestAnimationFrame(paint);
      }, { passive: true });
      c.addEventListener('pointerleave', function () {
        c.classList.remove('fx-live');
        nx = ny = 0;
        c.style.setProperty('--tx', '0');
        c.style.setProperty('--ty', '0');
        c.style.setProperty('--th', '0');
      });
    });
  })();
})();

/* le choix de langue se retient d'une page à l'autre */
(function () {
  var l = document.documentElement.lang;
  if (l) { try { localStorage.setItem('clel-lang', l.slice(0, 2)); } catch (e) {} }
})();


/* ==========================================================================
   Le son du site
   --------------------------------------------------------------------------
   Deux choses, et elles ne se mélangent pas.

   LE FOND — un morceau, en boucle, très bas : vingt décibels sous son propre
   niveau. Assez bas pour qu'on l'oublie au bout d'une minute, ce qui est
   exactement ce qu'on demande à une musique de fond. Il entre en fondu sur
   huit secondes — personne ne doit sursauter.

   LE DÉCLENCHEUR — le bruit d'un appareil photo, fabriqué à chaque clic. Du
   bruit blanc filtré pour la mécanique, une impulsion pour l'éclair, et le
   sifflement du condensateur derrière. Sur un bouton ou un lien :
   l'obturateur complet. Ailleurs : le petit claquement sec d'un obturateur
   électronique. L'écart entre les deux rideaux change à chaque fois — deux
   clics ne sonnent jamais exactement pareil.

   Une seule machine pour toute la page, même quand trois langues cohabitent
   dans un seul document : le garde-fou ci-dessous y veille.
   ========================================================================== */
(function () {
  'use strict';
  if (window.__clelAmbiance) return;
  window.__clelAmbiance = true;

  var CLE = 'clel-son';
  var etat = null;                 /* null = jamais choisi, '1' ou '0' sinon */
  try { etat = localStorage.getItem(CLE); } catch (e) {}

  var VOL = 0.10;                  /* le fond : −20 dB sous le morceau */
  var fond = null, fondu = null, allume = false;
  var ctx = null, clics = null, sec = null, mouille = null, dernier = 0;

  /* ====================================================================== */
  /*  LE FOND                                                               */
  /* ====================================================================== */
  function faireFond() {
    if (fond !== null || !window.CLEL_AMBIANCE) return fond;
    fond = new Audio();
    fond.loop = true;
    fond.preload = 'auto';
    fond.volume = 0;
    /* Si le fichier manque, on ne casse rien : il reste le déclencheur. */
    fond.addEventListener('error', function () { fond = false; });
    fond.src = window.CLEL_AMBIANCE;
    return fond;
  }

  function versVolume(cible, ms, puisArreter) {
    clearInterval(fondu);
    if (!fond) return;
    var de = fond.volume, t0 = Date.now();
    fondu = setInterval(function () {
      if (!fond) { clearInterval(fondu); return; }
      var k = Math.min(1, (Date.now() - t0) / ms);
      try { fond.volume = Math.max(0, Math.min(1, de + (cible - de) * k)); } catch (e) {}
      if (k >= 1) {
        clearInterval(fondu);
        if (puisArreter) { try { fond.pause(); } catch (e) {} }
      }
    }, 60);
  }

  /* ====================================================================== */
  /*  LE DÉCLENCHEUR                                                        */
  /* ====================================================================== */

  /* Une réverbération ne se télécharge pas : on la calcule. Du bruit qui
     s'éteint en exponentielle, c'est déjà une pièce. */
  function salle() {
    var d = 1.6, n = Math.floor(ctx.sampleRate * d);
    var buf = ctx.createBuffer(2, n, ctx.sampleRate);
    for (var c = 0; c < 2; c++) {
      var ch = buf.getChannelData(c);
      for (var i = 0; i < n; i++) {
        var t = i / n;
        ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, 3.2) * (t < 0.002 ? t / 0.002 : 1);
      }
    }
    var cv = ctx.createConvolver();
    cv.buffer = buf;
    return cv;
  }

  function brancher(src, dry, wet) {
    var a = ctx.createGain(), b = ctx.createGain();
    a.gain.value = dry; b.gain.value = wet;
    src.connect(a); a.connect(sec);
    src.connect(b); b.connect(mouille);
  }

  var BRUIT = null;
  function bruit() {
    if (BRUIT) return BRUIT;
    var n = Math.floor(ctx.sampleRate * 0.9);
    BRUIT = ctx.createBuffer(1, n, ctx.sampleRate);
    var d = BRUIT.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return BRUIT;
  }

  /* une bouffée de bruit filtré : c'est avec ça qu'on fait de la mécanique */
  function souffle(t, dur, type, f, q, vol) {
    var src = ctx.createBufferSource();
    src.buffer = bruit();
    var bp = ctx.createBiquadFilter();
    bp.type = type; bp.frequency.value = f; bp.Q.value = q;
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.0015);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(bp); bp.connect(g); g.connect(clics);
    src.start(t, Math.random() * 0.4); src.stop(t + dur + 0.02);
  }

  /* le corps de l'appareil : une masse qui bouge, donc du grave très court */
  function corps(t, f, dur, vol) {
    var o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(f * 1.6, t);
    o.frequency.exponentialRampToValueAtTime(f, t + dur * 0.5);
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(clics);
    o.start(t); o.stop(t + dur + 0.02);
  }

  function obturateur(t) {
    /* premier rideau : le miroir claque, le grave part avec lui */
    corps(t, 96, 0.075, 0.30);
    souffle(t, 0.022, 'bandpass', 2300, 1.1, 0.34);
    souffle(t + 0.002, 0.010, 'highpass', 5200, 0.7, 0.16);
    /* second rideau, un souffle plus tard : c'est lui qui donne la « pose » */
    var d = 0.068 + Math.random() * 0.012;
    souffle(t + d, 0.026, 'bandpass', 1850, 1.0, 0.26);
    corps(t + d, 78, 0.055, 0.17);
  }

  function flash(t) {
    /* l'éclair : une impulsion, rien de plus — très court et très clair */
    souffle(t, 0.016, 'highpass', 3400, 0.6, 0.30);
    souffle(t, 0.045, 'bandpass', 1200, 0.9, 0.10);
    /* la recharge : le sifflement qui monte derrière, et qu'on oublie */
    var o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(4600, t + 0.05);
    o.frequency.exponentialRampToValueAtTime(8200, t + 0.62);
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.017, t + 0.18);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.66);
    o.connect(g); g.connect(clics);
    o.start(t + 0.05); o.stop(t + 0.7);
  }

  function moteurClics() {
    if (ctx) return true;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();
    var rev = salle();
    sec = ctx.createGain(); sec.gain.value = 1; sec.connect(ctx.destination);
    mouille = ctx.createGain(); mouille.gain.value = 1;
    mouille.connect(rev); rev.connect(ctx.destination);
    clics = ctx.createGain(); clics.gain.value = 0.30;
    brancher(clics, 1, 0.16);
    return true;
  }

  function declic(plein) {
    if (!allume || !moteurClics()) return;
    if (ctx.state === 'suspended') ctx.resume();
    var now = Date.now();
    if (now - dernier < 110) return;        /* un double-clic ne double pas le son */
    dernier = now;
    var t = ctx.currentTime + 0.006;
    if (plein) { obturateur(t); flash(t + 0.014); }
    else {
      /* obturateur électronique : un seul petit claquement, sans mécanique */
      souffle(t, 0.012, 'bandpass', 2600, 1.4, 0.13);
      corps(t, 150, 0.030, 0.07);
    }
  }

  /* ====================================================================== */
  /*  L'INTERRUPTEUR                                                        */
  /* ====================================================================== */
  function demarrer() {
    if (allume) return;
    allume = true;
    moteurClics();
    if (ctx && ctx.state === 'suspended') ctx.resume();
    if (faireFond()) {
      var p = fond.play();
      if (p && p.catch) p.catch(function () {});
      versVolume(VOL, 8000);                /* la montée dure huit secondes */
    }
    marquer();
  }

  function arreter() {
    if (!allume) { marquer(); return; }
    allume = false;
    versVolume(0, 900, true);
    if (ctx) setTimeout(function () { if (!allume && ctx) ctx.suspend(); }, 1400);
    marquer();
  }

  function marquer() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-son]'), function (x) {
      x.classList.toggle('on', allume);
      x.setAttribute('aria-pressed', allume ? 'true' : 'false');
      var l = x.querySelector('.lbl');
      if (l) l.textContent = x.getAttribute(allume ? 'data-off' : 'data-on') || l.textContent;
    });
  }

  var ACTIFS = 'a,button,summary,label,input,select,[role="button"],[data-go],' +
               '.ix-b,.pcard,.acard,.langsel a,.side a,.pager a';

  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-son]');
    if (b) {
      e.preventDefault();
      if (allume) {
        arreter(); etat = '0';
      } else {
        demarrer(); etat = '1';
        declic(true);                   /* on entend tout de suite ce qu'on allume */
      }
      try { localStorage.setItem(CLE, etat); } catch (err) {}
      return;
    }
    /* Sélectionner du texte n'est pas cliquer : on ne sonne pas là-dessus. */
    try { if (String(window.getSelection()).length > 1) return; } catch (err) {}
    declic(!!(e.target.closest && e.target.closest(ACTIFS)));
  });

  /* Un navigateur refuse le son tant que personne n'a rien fait : on attend
     donc le premier geste. Sur l'accueil on part tout seul ; ailleurs, on ne
     repart que si le lecteur l'avait demandé. */
  function accueil() { return !!document.querySelector('.hero'); }

  ['pointerdown', 'keydown', 'wheel', 'touchstart'].forEach(function (ev) {
    window.addEventListener(ev, function once() {
      ['pointerdown', 'keydown', 'wheel', 'touchstart'].forEach(function (e2) {
        window.removeEventListener(e2, once);
      });
      if (etat === '0') return;
      if (etat === '1' || accueil()) demarrer();
    }, { passive: true });
  });

  /* Onglet caché : on se tait. Rien de plus agaçant qu'un son qui sort d'un
     onglet qu'on ne regarde plus. */
  document.addEventListener('visibilitychange', function () {
    if (!allume) return;
    if (document.hidden) {
      if (fond) { try { fond.pause(); } catch (e) {} }
      if (ctx) ctx.suspend();
    } else {
      if (fond) { var p = fond.play(); if (p && p.catch) p.catch(function () {}); }
      if (ctx && ctx.state === 'suspended') ctx.resume();
    }
  });

  window.addEventListener('beforeprint', function () { if (allume) arreter(); });
  marquer();
})();

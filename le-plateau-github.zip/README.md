# Le Plateau

Manuel illustré de prise de vues, de lumière, de son et de montage.
42 chapitres, deux annexes, 68 schémas dessinés à la main, en français,
anglais et arabe.

© Yassine Zineddine — tous droits réservés.

---

## Ce qu'il faut comprendre avant de toucher à quoi que ce soit

Le site n'est pas écrit à la main. Il est **fabriqué** à partir d'un seul
livre source, en français. C'est ce qui permet d'avoir trois langues,
44 pages par langue, un livre-sur-une-page, un PDF et un fichier unique —
tous d'accord entre eux, toujours.

| Dossier | Ce qu'il y a dedans |
|---|---|
| `fr/` | **le livre, la source.** C'est ici qu'on écrit. |
| `site_src/` | les scripts, les styles, les figures pilotables, les traductions de l'habillage |
| `site/` | **le site fabriqué.** Ne rien y modifier à la main : tout y est écrasé à chaque construction. C'est ce dossier que Netlify publie. |
| `sortie/` | le PDF et le fichier unique. Pas dans Git — on les télécharge depuis l'onglet Actions. |

Le même mot d'un chapitre est écrit à quatre endroits du site fabriqué :
la page du chapitre, le livre-sur-une-page, l'index de recherche et le PDF.
Corriger `site/fr/ch12.html` ne corrige donc qu'un quart du problème, et la
correction disparaît à la construction suivante.

> **On corrige toujours dans `fr/`, jamais dans `site/`.**

---

## Modifier sans rien installer, depuis GitHub

1. Ouvrir le fichier à modifier — pour un chapitre, c'est un des `fr/f*.html`
   (cherchez le titre du chapitre avec la recherche de GitHub).
2. Cliquer sur le crayon, corriger, **Commit changes**.
3. Aller dans l'onglet **Actions** : la construction démarre toute seule.
   Elle prend trois à quatre minutes — l'essentiel, c'est le PDF.
4. Quand la coche verte apparaît, le dossier `site/` est à jour et Netlify
   a publié.

Si la coche est rouge, **rien n'a été publié** : le site en ligne est resté
celui d'avant. Ouvrez l'action pour voir laquelle des deux vérifications a
échoué — un lien cassé, ou deux textes qui se chevauchent dans un schéma.

---

## Modifier depuis un ordinateur

Il faut Python 3 :

```bash
pip install playwright
python -m playwright install chromium
```

Puis, à chaque changement :

```bash
cd fr         && python build.py && python mkpdf.py
cd ../site_src && python mksite.py --lang=fr \
                && python mksite.py --lang=en \
                && python mksite.py --lang=ar \
                && python mkracine.py && python mkone3.py
python chkliens.py        # aucun lien ne doit être cassé
python chkfigs.py         # aucun texte ne doit se chevaucher
```

Puis `git add -A && git commit && git push`. L'action refera le travail de
son côté, ce qui est normal et sans conséquence.

---

## Où se trouve quoi

| Ce qu'on veut changer | Où |
|---|---|
| Un chapitre | `fr/f*.html` |
| Un schéma du livre | `fr/mkfigs*.py`, puis relancer le script |
| Une figure qu'on manipule | `site_src/fx/figN-N.html` |
| Les mots de l'habillage, les trois langues | `site_src/i18n.py` |
| La page d'accueil | `site_src/index.tpl.html` |
| Les couleurs et la mise en page du livre | `fr/f0.html`, tout en haut |
| La barre du haut, la recherche, le sommaire | `site_src/chrome.css` |
| Les animations | `site_src/fx/motion.css`, `motion.js` |
| Le son : musique de fond et déclencheur | `site_src/fx/ambient.js` |
| La musique de fond elle-même | `site_src/assets/ambiance.mp3` |
| Le portrait | `site_src/assets/portrait.webp` et `.png` |

Deux nombres reviennent partout et doivent rester d'accord : le nombre de
chapitres et le nombre de schémas. Ils sont dans `fr/f0.html` (le bandeau),
`site_src/i18n.py` et `site_src/index.tpl.html`.

---

## Netlify

Le site est entièrement statique : aucun serveur, aucune base de données,
**aucune commande de construction côté Netlify** — c'est l'action GitHub qui
fabrique, Netlify ne fait que servir.

1. Netlify → **Add new site** → **Import an existing project** → ce dépôt
2. **Build command :** laisser vide
3. **Publish directory :** `site`
4. Deploy

Le fichier `netlify.toml` à la racine dit déjà tout cela, et ajoute les
réglages de cache : les pages sont revalidées à chaque visite (une
correction se voit tout de suite), les styles et le PDF sont gardés une
semaine.

Pour un nom de domaine à soi : Site configuration → Domain management →
Add a domain. Netlify pose le certificat HTTPS tout seul.

Chaque construction apparaît dans l'onglet **Deploys** de Netlify. On peut
revenir à n'importe quelle version d'un clic, sans toucher à Git.

---

## Le son

La musique de fond est un fichier (`site_src/assets/ambiance.mp3`, réencodé
en 64 kb/s et fondu aux deux bouts pour que la boucle ne claque pas). Elle
est jouée vingt décibels sous son propre niveau : on doit l'oublier au bout
d'une minute.

Le bruit d'appareil photo au clic, lui, n'est pas un fichier : il est
fabriqué à chaque clic par le navigateur — du bruit blanc filtré pour la
mécanique, une impulsion pour l'éclair. Il ne pèse rien et ne sonne jamais
deux fois pareil.

Les navigateurs interdisent le son avant un geste du visiteur : le premier
clic sur la page d'accueil met le tout en route. Ailleurs, rien ne part tout
seul. Le bouton haut-parleur de la barre du haut coupe et remet, et ce choix
est retenu d'une page à l'autre.

**Si vous changez la musique**, gardez la preuve de sa licence quelque part :
un site public, même gratuit, reste une diffusion.

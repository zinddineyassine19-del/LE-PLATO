#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Dessine les huit schémas des parties V (le son) et VI (le montage)."""
import json
import math
import os

D = os.path.dirname(os.path.abspath(__file__))
S = {}


def fmt(v):
    if isinstance(v, str):
        return v
    return ("%.1f" % v).rstrip("0").rstrip(".")


def svg(key, w, h, alt, body):
    S[key] = ('<svg viewBox="0 0 %d %d" role="img" aria-label="%s">\n%s\n</svg>'
              % (w, h, alt, body.strip()))


def t(x, y, s, cls="", anchor="", extra=""):
    a = ' text-anchor="%s"' % anchor if anchor else ""
    c = ' class="%s"' % cls if cls else ""
    return '<text x="%s" y="%s"%s%s%s>%s</text>' % (
        fmt(x), fmt(y), c, a, (" " + extra) if extra else "", s)


def ln(x1, y1, x2, y2, cls="sl", w=1.4, extra=""):
    return '<line x1="%s" y1="%s" x2="%s" y2="%s" class="%s" stroke-width="%s"%s/>' % (
        fmt(x1), fmt(y1), fmt(x2), fmt(y2), cls, w, (" " + extra) if extra else "")


def rect(x, y, w, h, cls="", extra=""):
    return '<rect x="%s" y="%s" width="%s" height="%s"%s%s/>' % (
        fmt(x), fmt(y), fmt(w), fmt(h),
        ' class="%s"' % cls if cls else "", (" " + extra) if extra else "")


# ===========================================================================
# 34.1  les directivités : ce que le micro entend, et d'où
# ===========================================================================
b = [t(20, 26, "CE QUE LE MICRO ENTEND — VU DE DESSUS", "b kt")]

MOTIFS = [
    ("omnidirectionnel", "omni", lambda a: 1.0,
     "tout, à égalité", "cravate, ambiance"),
    ("cardioïde", "cardio", lambda a: 0.5 + 0.5 * math.cos(a),
     "devant et un peu les côtés", "interview, voix off"),
    ("hypercardioïde", "hyper", lambda a: 0.25 + 0.75 * math.cos(a),
     "devant, serré", "perche, en intérieur"),
    ("canon", "canon", lambda a: max(0.0, math.cos(a)) ** 3.2,
     "devant, très serré", "perche, dehors et loin"),
]

CX0, CY, R = 96, 132, 58
for i, (nom, key, f, quoi, ou) in enumerate(MOTIFS):
    cx = CX0 + i * 143
    # le cadre de chaque vignette
    b.append(rect(cx - 66, 44, 132, 196, "nf sl",
                  'stroke-width="1" rx="9" opacity=".55"'))
    # le lobe : on part du micro, vers le haut = l'avant
    pts = []
    for k in range(0, 361, 4):
        a = math.radians(k)
        r = R * f(a)
        pts.append("%s,%s" % (fmt(cx + r * math.sin(a)), fmt(CY - r * math.cos(a))))
    b.append('<polygon points="%s" class="bgk" opacity=".30"/>' % " ".join(pts))
    b.append('<polygon points="%s" class="nf sk" stroke-width="1.7"/>' % " ".join(pts))
    # les cercles de repère
    for rr in (R * 0.5, R):
        b.append('<circle cx="%s" cy="%s" r="%s" class="nf sl" stroke-width=".8" '
                 'stroke-dasharray="2 4" opacity=".6"/>' % (cx, CY, fmt(rr)))
    # le micro lui-même
    b.append(rect(cx - 4, CY - 2, 8, 26, "fc", 'rx="3"'))
    b.append(t(cx, 66, nom, "sm b kt", "middle"))
    b.append(t(cx, 218, quoi, "sm", "middle"))
    b.append(t(cx, 232, ou, "sm mut", "middle"))

# la légende de l'axe
b.append(ln(CX0 - 96, CY, CX0 - 78, CY, "sd", 1.4, 'marker-end="url(#arwD)"'))
b.append(t(28, 118, "l'avant", "sm b dt"))
b.append(t(28, 150, "du micro", "sm mut"))

b.append(t(20, 272, "Un micro n'est pas un zoom : la directivité ne rapproche pas le son, "
                    "elle écarte ce qui vient d'ailleurs.", "sm mut"))
svg("SVG057", 620, 288,
    "Quatre diagrammes de directivité vus de dessus — omnidirectionnel, cardioïde, "
    "hypercardioïde et canon — chacun avec son usage.", "\n".join(b))


# ===========================================================================
# 35.1  l'échelle des niveaux : où viser, où ça casse
# ===========================================================================
b = [t(20, 26, "LE NIVEAU, EN dBFS — ZÉRO EST UN MUR", "b kt")]

X0, X1 = 132, 596
TOP, BOT = 48, 244


def ydb(db):
    """−60 dBFS en bas, 0 en haut."""
    return BOT - (db + 60) / 60.0 * (BOT - TOP)


# les zones
ZONES = [
    (-6, 0, "var(--axisbg)", "écrêtage", "axis", "l'onde est coupée net"),
    (-20, -6, "var(--keybg)", "crêtes", "key", "un cri, une porte"),
    (-30, -20, "var(--daybg)", "la voix, ici", "day", "le dialogue normal"),
    (-60, -30, "var(--panel2)", "trop bas", "", "on remonterait le souffle"),
]
for lo, hi, fill, nom, cls, note in ZONES:
    b.append('<rect x="%s" y="%s" width="%s" height="%s" fill="%s" opacity=".75"/>'
             % (X0, fmt(ydb(hi)), X1 - X0, fmt(ydb(lo) - ydb(hi)), fill))
    ym = (ydb(lo) + ydb(hi)) / 2
    b.append(t(X0 + 12, ym + 4, nom, "b " + (cls + "t" if cls else "mut")))
    b.append(t(X1 - 12, ym + 4, note, "sm mut", "end"))

b.append(rect(X0, TOP, X1 - X0, BOT - TOP, "nf sl", 'stroke-width="1.2"'))

# la graduation
for db in range(-60, 1, 10):
    y = ydb(db)
    b.append(ln(X0 - 7, y, X0, y, "sl", 1))
    b.append(t(X0 - 12, y + 4, "%d" % db, "sm n mut", "end"))
b.append(t(X0 - 12, TOP - 14, "dBFS", "sm mut", "end"))

# le trait de zéro, et la cible
b.append(ln(X0 - 4, ydb(0), X1 + 4, ydb(0), "sa", 2.4))
b.append(ln(X0, ydb(-12), X1, ydb(-12), "sd", 1.8, 'stroke-dasharray="6 4"'))
b.append(t(X1 - 12, ydb(-12) + 17, "viser −12 dBFS", "sm b dt", "end"))

# les trois niveaux, en petit dans la marge de gauche
for k, (db, cls, lab) in enumerate(((-40, "sl", "trop bas"),
                                    (-12, "sd", "juste"),
                                    (-2, "sa", "trop fort"))):
    yc = ydb(db)
    amp = min(16.0, (60 + db) / 60.0 * 20)
    pts = []
    for i in range(0, 49):
        xx = 26 + i * 1.5
        v = math.sin(i / 48.0 * math.pi * 5) * amp
        if db > -6:
            v = max(-9, min(9, v))      # au-delà du mur, l'onde est rabotée
        pts.append("%s,%s" % (fmt(xx), fmt(yc - v)))
    b.append('<polyline points="%s" class="nf %s" stroke-width="1.4"/>' % (" ".join(pts), cls))
    b.append(t(26, yc + 30, lab, "sm mut"))

b.append(t(20, 268, "Le zéro numérique n'est pas « fort » : c'est la limite physique du fichier.", "sm mut"))
b.append(t(20, 282, "On garde vingt décibels de marge parce qu'un tournage est imprévisible.", "sm mut"))
svg("SVG058", 620, 298,
    "Une échelle de niveaux en dBFS avec la zone de la voix, la zone des crêtes et "
    "l'écrêtage au-dessus de zéro, et trois formes d'onde.", "\n".join(b))


# ===========================================================================
# 36.1  la distance est reine
# ===========================================================================
b = [t(20, 26, "PLACER LE MICRO — LA DISTANCE FAIT TOUT", "b kt")]

# le comédien
b.append('<use href="#person" transform="translate(300,86) scale(.46)" class="fc"/>')
b.append(t(300, 252, "le comédien", "sm mut", "middle"))

# la perche, au-dessus, hors champ
b.append('<g transform="translate(300,58)">'
         '<rect x="-3" y="-6" width="6" height="30" rx="3" class="fc"/>'
         '<line x1="0" y1="-6" x2="-72" y2="-20" class="sc" stroke-width="3"/>'
         '</g>')
b.append(t(120, 46, "perche,", "sm b kt", "middle"))
b.append(t(120, 60, "juste hors du cadre", "sm b kt", "middle"))

# le cadre de l'image
b.append(rect(214, 42, 172, 100, "nf sd", 'stroke-width="1.4" stroke-dasharray="5 4"'))
b.append(t(390, 52, "le cadre", "sm dt"))

# les distances, et le niveau qui tombe
b.append(ln(300, 86, 300, 62, "sk", 1.6, 'marker-end="url(#arwK)"'))
b.append(t(310, 76, "40 cm", "sm n kt"))

DIST = [(40, "40 cm", "la voix, pleine", "kt"),
        (80, "80 cm", "−6 dB · la pièce s'invite", "dt"),
        (160, "1,6 m", "−12 dB · on entend la salle", "mut"),
        (320, "3,2 m", "−18 dB · c'est la pièce", "mut")]
YY = 168
for i, (d, lab, quoi, cls) in enumerate(DIST):
    y = YY + i * 27
    w = 150 * (40.0 / d)
    b.append(rect(412, y - 9, fmt(w), 13, "bgk" if i == 0 else "bgp",
                  'rx="2" opacity=".85"'))
    b.append(t(406, y + 1, lab, "sm n " + cls, "end"))
    b.append(t(412, y + 15, quoi, "sm mut"))

b.append(t(412, YY - 22, "ce qui reste de la voix", "sm b kt"))

b.append(t(20, 288, "Doubler la distance coûte six décibels de voix — mais la réverbération de la", "sm mut"))
b.append(t(20, 302, "pièce, elle, ne bouge pas. C'est le rapport entre les deux qui s'effondre.", "sm mut"))
svg("SVG059", 620, 316,
    "Une perche au-dessus d'un comédien, hors du cadre, et quatre distances montrant "
    "la chute du niveau de la voix.", "\n".join(b))


# ===========================================================================
# 37.1  la synchronisation : pourquoi on claque
# ===========================================================================
b = [t(20, 26, "LE CLAP — DEUX ENREGISTREMENTS, UN SEUL INSTANT", "b kt")]

# la bande image
b.append(t(20, 66, "IMAGE", "sm b dt"))
for i in range(10):
    x = 96 + i * 48
    b.append(rect(x, 52, 44, 34, "bgp", 'rx="2"'))
    b.append(rect(x + 2, 55, 40, 28, "nf sl", 'stroke-width=".8" rx="1"'))
b.append(ln(96, 94, 576, 94, "sl", 1, 'stroke-dasharray="3 4"'))

# la bande son
b.append(t(20, 152, "SON", "sm b kt"))
pts = []
for i in range(0, 481):
    x = 96 + i
    if 140 <= x <= 152:
        v = 34 * (1 - abs(x - 146) / 6.0)
    else:
        v = 9 * math.sin(i * 0.5) * math.sin(i * 0.031)
    pts.append("%s,%s" % (fmt(x), fmt(146 - v)))
b.append(rect(96, 112, 480, 68, "bgp", 'rx="3" opacity=".6"'))
b.append('<polyline points="%s" class="nf sk" stroke-width="1.3"/>' % " ".join(pts))

# le clap, et l'instant commun
b.append(ln(146, 44, 146, 194, "sa", 2, 'stroke-dasharray="6 4"'))
b.append('<g transform="translate(146,34)">'
         '<rect x="-16" y="-12" width="32" height="18" rx="2" class="fc"/>'
         '<rect x="-16" y="-22" width="32" height="9" rx="2" class="fa" '
         'transform="rotate(-17 -16 -13)"/></g>')
b.append(t(146, 214, "l'instant du clap", "sm b at", "middle"))
b.append(t(146, 228, "une image nette, un pic net", "sm mut", "middle"))

b.append(t(596, 70, "→", "b dt", "end"))
b.append(t(596, 152, "→", "b kt", "end"))

b.append(rect(20, 240, 580, 34, "bgd", 'rx="6" opacity=".5"'))
b.append(t(32, 262, "Le logiciel aligne le pic du son sur l'image où les bras se touchent. "
                    "Sans clap, il faut le faire à l'œil, plan par plan.", "sm dt"))
svg("SVG060", 620, 288,
    "Une bande image et une bande son alignées sur le pic du clap, qui marque le même "
    "instant dans les deux enregistrements.", "\n".join(b))


# ===========================================================================
# 38.1  dérusher : trois copies, un rangement
# ===========================================================================
b = [t(20, 26, "AVANT DE MONTER — TROIS COPIES, PUIS UN RANGEMENT", "b kt")]

# la carte, et les trois copies
b.append('<g transform="translate(60,74)">'
         '<rect x="-26" y="-18" width="52" height="36" rx="4" class="fc"/>'
         '<rect x="-18" y="-12" width="20" height="10" rx="2" class="bgp"/></g>')
b.append(t(60, 118, "la carte", "sm b kt", "middle"))
b.append(t(60, 132, "ne la formatez pas", "sm at", "middle"))

CIBLES = [("disque de travail", "celui où monte"),
          ("disque de sauvegarde", "posé ailleurs"),
          ("le nuage, ou un 3ᵉ disque", "hors du studio")]
for i, (nom, ou) in enumerate(CIBLES):
    y = 54 + i * 44
    b.append(ln(92, 74, 158, y + 12, "sk", 1.4, 'marker-end="url(#arwK)" opacity=".8"'))
    b.append('<g transform="translate(176,%d)">'
             '<rect x="-16" y="-13" width="32" height="26" rx="3" class="nf sc" '
             'stroke-width="1.6"/><circle cx="0" cy="0" r="4" class="fc"/></g>' % (y + 12))
    b.append(t(200, y + 10, nom, "sm b"))
    b.append(t(200, y + 24, ou, "sm mut"))

b.append(rect(20, 154, 340, 30, "bga", 'rx="6" opacity=".45"'))
b.append(t(32, 174, "Une copie n'est pas une sauvegarde. Trois, oui.", "sm b at"))

# l'arborescence
b.append(t(380, 52, "UN RANGEMENT, TOUJOURS LE MÊME", "sm b kt"))
ARBRE = [(0, "2026-04-12_court-metrage/"),
         (1, "01_rushes/"), (2, "camera_A/"), (2, "son/"),
         (1, "02_montage/"), (1, "03_sons_et_musiques/"),
         (1, "04_exports/")]
for i, (lvl, nom) in enumerate(ARBRE):
    y = 76 + i * 21
    x = 388 + lvl * 18
    if lvl:
        b.append(ln(x - 10, y - 4, x - 4, y - 4, "sl", 1))
        b.append(ln(x - 10, y - 16, x - 10, y - 4, "sl", 1))
    b.append(t(x, y, nom, "n sm" + (" b dt" if lvl == 0 else " mut")))

b.append(t(20, 216, "Nommer, c'est déjà monter : un rush qu'on ne retrouve pas n'existe pas.",
           "sm mut"))
b.append(t(20, 234, "La date en tête range les dossiers toute seule, dans l'ordre.", "sm mut"))
svg("SVG061", 620, 252,
    "Une carte mémoire copiée vers trois destinations, et l'arborescence d'un projet "
    "de montage rangée par étapes.", "\n".join(b))


# ===========================================================================
# 39.1  la coupe J et la coupe L
# ===========================================================================
b = [t(20, 26, "LA COUPE FRANCHE, LA COUPE J, LA COUPE L", "b kt")]

CAS = [("FRANCHE", "l'image et le son changent ensemble", 0, 0),
       ("COUPE J", "le son du plan B arrive avant son image", -46, 0),
       ("COUPE L", "le son du plan A continue sur l'image de B", 0, 46)]
Y0 = 56
for i, (nom, quoi, avance, tient) in enumerate(CAS):
    y = Y0 + i * 74
    b.append(t(20, y + 14, nom, "sm b kt"))
    b.append(t(20, y + 30, quoi, "sm mut"))
    xa, xm, xb = 268, 396, 576

    # la piste image
    b.append(rect(xa, y, xm - xa, 24, "bgd", 'rx="3"'))
    b.append(rect(xm, y, xb - xm, 24, "bgk", 'rx="3"'))
    b.append(t(xa + 10, y + 16, "image A", "sm dt"))
    b.append(t(xm + 10, y + 16, "image B", "sm kt"))

    # la piste son, décalée
    cut = xm + avance - tient
    b.append(rect(xa, y + 30, cut - xa, 24, "bgd", 'rx="3" opacity=".75"'))
    b.append(rect(cut, y + 30, xb - cut, 24, "bgk", 'rx="3" opacity=".75"'))
    b.append(t(xa + 10, y + 46, "son A", "sm dt"))
    b.append(t(cut + 10, y + 46, "son B", "sm kt"))

    # le trait de coupe image
    b.append(ln(xm, y - 5, xm, y + 59, "sa", 1.6, 'stroke-dasharray="4 3"'))
    if avance or tient:
        b.append(ln(cut, y + 26, cut, y + 58, "sa", 1.2, 'stroke-dasharray="2 3"'))
        b.append('<path d="M%s %s L%s %s" class="nf sa" stroke-width="1.2" '
                 'marker-end="url(#arwA)"/>' % (fmt(xm), fmt(y + 66), fmt(cut), fmt(y + 66)))

b.append(rect(20, 278, 580, 34, "bgk", 'rx="6" opacity=".4"'))
b.append(t(32, 300, "Décaler le son de quelques images suffit : l'oreille croit alors que "
                    "les deux plans appartiennent à la même scène.", "sm kt"))
svg("SVG062", 620, 326,
    "Trois façons de couper : franche, coupe J où le son précède l'image, coupe L où "
    "le son se prolonge.", "\n".join(b))


# ===========================================================================
# 40.1  le rythme : la durée des plans
# ===========================================================================
b = [t(20, 26, "LE RYTHME SE VOIT — DURÉE DE CHAQUE PLAN", "b kt")]

SEQ = [("l'installation", [7.0, 6.2, 5.4, 6.6, 4.8], "day"),
       ("la tension", [3.4, 2.8, 2.2, 1.8, 1.4, 1.1, 0.8, 0.6], "key"),
       ("la retombée", [4.0, 6.0, 9.0], "axis")]

X = 128
Y0 = 58
ECH = 15.0        # pixels par seconde
for gi, (nom, durees, cls) in enumerate(SEQ):
    y = Y0 + gi * 62
    b.append(t(20, y + 18, nom, "sm b " + cls[0] + "t"))
    x = X
    for d in durees:
        w = d * ECH
        b.append(rect(x, y, w, 28, "bg" + cls[0], 'rx="2"'))
        b.append(rect(x, y, w, 28, "nf s" + cls[0], 'stroke-width="1" rx="2" opacity=".7"'))
        if w > 26:
            b.append(t(x + w / 2, y + 19, ("%.1f" % d).replace(".", ","),
                       "sm n mut", "middle"))
        x += w + 2
    b.append(t(20, y + 34, "%d plans · %.0f s" % (len(durees), sum(durees)), "sm mut"))

# l'échelle
b.append(ln(X, 232, X + 10 * ECH, 232, "sl", 1.2))
for k in range(0, 11, 2):
    b.append(ln(X + k * ECH, 228, X + k * ECH, 236, "sl", 1))
    b.append(t(X + k * ECH, 250, "%d s" % k, "sm n mut", "middle"))

b.append(t(20, 272, "Personne ne compte les secondes en regardant — mais tout le monde les sent.", "sm mut"))
b.append(t(20, 286, "Raccourcir accélère le cœur ; laisser durer laisse respirer.", "sm mut"))
svg("SVG063", 620, 300,
    "Trois séquences dont on voit la durée de chaque plan : l'installation lente, la "
    "tension qui accélère, la retombée qui s'étire.", "\n".join(b))


# ===========================================================================
# 41.1  exporter : une chaîne, trois décisions
# ===========================================================================
b = [t(20, 26, "EXPORTER — CE QUI SE DÉCIDE, ET DANS QUEL ORDRE", "b kt")]

ETAPES = [("le montage", "ProRes ou DNx", "on travaille dans un codec\nqui se coupe bien"),
          ("le master", "ProRes 422 HQ", "la copie qu'on garde,\nlourde et intacte"),
          ("la livraison", "H.264 / H.265", "la copie qu'on envoie,\nlégère et lisible partout")]
X0 = 40
for i, (nom, codec, quoi) in enumerate(ETAPES):
    x = X0 + i * 196
    b.append(rect(x, 52, 164, 92, "bgp", 'rx="8"'))
    b.append(rect(x, 52, 164, 92, "nf sl", 'stroke-width="1" rx="8"'))
    b.append(t(x + 14, 76, nom, "b"))
    b.append(t(x + 14, 96, codec, "n dt"))
    for k, li in enumerate(quoi.split("\n")):
        b.append(t(x + 14, 116 + k * 14, li, "sm mut"))
    if i < 2:
        b.append(ln(x + 170, 98, x + 190, 98, "sk", 1.8, 'marker-end="url(#arwK)"'))

# les trois réglages
b.append(t(20, 178, "LES TROIS SEULS RÉGLAGES QUI COMPTENT", "sm b kt"))
REG = [("définition", "celle du montage", "ne jamais agrandir après coup"),
       ("cadence", "celle du tournage", "25 i/s au Maroc et en Europe"),
       ("débit", "15 à 25 Mb/s en 1080p", "au-delà, personne ne voit la différence")]
for i, (nom, val, note) in enumerate(REG):
    y = 200 + i * 24
    b.append(t(36, y, nom, "sm kt"))
    b.append(t(160, y, val, "sm n dt"))
    b.append(t(330, y, note, "sm mut"))

b.append(rect(20, 268, 580, 30, "bga", 'rx="6" opacity=".45"'))
b.append(t(32, 288, "Un export de livraison n'est pas un master : il est fait pour être "
                    "regardé, pas pour être remonté.", "sm at"))
svg("SVG064", 620, 312,
    "La chaîne d'export en trois étapes — montage, master, livraison — et les trois "
    "réglages qui comptent : définition, cadence et débit.", "\n".join(b))


# ---------------------------------------------------------------- magasin
p = os.path.join(D, "svgstore_fr.json")
store = json.load(open(p, encoding="utf-8"))
store.update(S)
json.dump(store, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print("schémas écrits :", ", ".join(sorted(S)))
print("magasin :", len(store), "entrées")

from playwright.sync_api import sync_playwright
import pathlib, shutil
import os as _os
ICI = _os.path.dirname(_os.path.abspath(__file__))
RACINE = _os.path.dirname(ICI)            # le dossier du dépôt


SRC = (pathlib.Path(ICI) / "le-plateau-fr.html").resolve()
OUTDIR = pathlib.Path(RACINE) / "sortie"
OUTDIR.mkdir(parents=True, exist_ok=True)
html_out = OUTDIR / "Le-Plateau.html"
pdf_out = OUTDIR / "Le-Plateau.pdf"
shutil.copy(SRC, html_out)

FOOT = ("<div style=\"width:100%;font-size:7.5pt;color:#8A94A3;"
        "font-family:'IBM Plex Mono',ui-monospace,monospace;padding:0 13mm;"
        "display:flex;justify-content:space-between;align-items:baseline\">"
        "<span>&copy; Yassine Zineddine &mdash; tous droits r&eacute;serv&eacute;s</span>"
        "<span style='letter-spacing:.06em'>Le Plateau</span>"
        "<span class='pageNumber'></span></div>")

with sync_playwright() as p:
    exe = "/opt/pw-browsers/chromium"
    b = p.chromium.launch(executable_path=exe if pathlib.Path(exe).exists() else None)
    pg = b.new_page(viewport={"width": 900, "height": 1200})
    pg.emulate_media(media="print", color_scheme="light")
    pg.goto("file://" + str(SRC))
    pg.wait_for_timeout(4500)
    pg.pdf(path=str(pdf_out), format="A4", print_background=True,
           margin={"top": "13mm", "bottom": "16mm", "left": "13mm", "right": "13mm"},
           display_header_footer=True,
           header_template="<div></div>",
           footer_template=FOOT)
    b.close()
print("pdf ->", pdf_out)

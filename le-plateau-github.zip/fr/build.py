#!/usr/bin/env python3
import json, re, os, collections
import os as _os
ICI = _os.path.dirname(_os.path.abspath(__file__))
RACINE = _os.path.dirname(ICI)            # le dossier du dépôt


D = ICI
ORDER = ["f0","f1","f2","f3","f4a","f5a","f5b","f6","f7","f8","f11","f9","f4c","f4b"]

store = json.load(open(os.path.join(D,"svgstore_fr.json"), encoding="utf-8"))

parts = []
for n in ORDER:
    p = os.path.join(D, n + ".html")
    parts.append(open(p, encoding="utf-8").read())
body = "\n".join(parts)

# --- re-inject SVGs ---
used = []
missing = []
def rep(m):
    k = m.group(0).strip("@")
    used.append(k)
    if k not in store:
        missing.append(k)
        return "<!-- MISSING " + k + " -->"
    return store[k]

body = re.sub(r"@@SVG\d{3}@@", rep, body)

# --- les caractères, embarqués : plus aucune dépendance réseau ---
_fonts = open(_os.path.join(RACINE, "site_src", "fonts.css"), encoding="utf-8").read().rstrip()
assert "/*@FONTS@*/" in body, "marqueur des fontes introuvable"
body = body.replace("/*@FONTS@*/", _fonts, 1)
print("fontes embarquées     :", round(len(_fonts) / 1024), "Ko")

print("placeholders injected :", len(used))
print("unique placeholders   :", len(set(used)))
print("missing in store      :", missing)
dupes = [k for k,v in collections.Counter(used).items() if v > 1]
print("duplicated            :", dupes)
notused = sorted(set(store.keys()) - set(used))
print("in store, never used  :", notused)

# --- integrity checks ---
for tag in ("section","figure","table","div","main","nav","tbody","thead","tr","td","th","ul","ol","li","p"):
    o = len(re.findall(r"<%s[\s>]" % tag, body))
    c = len(re.findall(r"</%s>" % tag, body))
    flag = "" if o == c else "   <-- MISMATCH"
    print("  %-8s open=%-4d close=%-4d%s" % (tag, o, c, flag))

ar = re.findall(r"[؀-ۿ]+", body)
print("arabic runs remaining :", len(ar), ar[:12])

ids = re.findall(r'\bid="([^"]+)"', body)
d2 = [k for k,v in collections.Counter(ids).items() if v > 1]
print("duplicate ids         :", d2)

hrefs = set(re.findall(r'href="#([^"]+)"', body))
print("dangling toc links    :", sorted(hrefs - set(ids)))

uses = set(re.findall(r'(?:xlink:)?href="#([^"]+)"', body))
print("figures               :", len(re.findall(r"<figure[\s>]", body)))
print("chapters              :", len(re.findall(r'<section class="ch"', body)))

# --- standalone shell ---
html = """<!doctype html>
<html lang="fr" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Le Plateau — manuel illustré de prise de vues, de lumière, de son et de montage, en français avec la terminologie anglaise.">
<style>@page{size:A4;margin:16mm 13mm}</style>
""" + body.replace("</div>\n", "</div>\n", 1) + """
</body>
</html>
"""
# body already ends with </main></div>; wrap head/body properly
html = html.replace("<style>@page{size:A4;margin:16mm 13mm}</style>\n<link",
                    "<link")

# ---- le sommaire suit le lecteur et reste toujours atteignable ----
SPY = """<style>
nav.toc a[aria-current="page"]{background:var(--panel);color:var(--ink);font-weight:600;
  border-radius:6px;box-shadow:inset 2px 0 0 var(--key)}
nav.toc a[aria-current="page"] b{color:var(--key)}
</style>
<script>
(function () {
  var toc = document.querySelector('nav.toc');
  if (!toc || !window.IntersectionObserver) return;
  var links = {}, cur = null;
  Array.prototype.forEach.call(toc.querySelectorAll('a[href^="#"]'), function (a) {
    links[a.getAttribute('href').slice(1)] = a;
  });
  function mark(a) {
    if (a === cur) return;
    if (cur) cur.removeAttribute('aria-current');
    cur = a; if (!a) return;
    a.setAttribute('aria-current', 'page');
    if (toc.scrollHeight <= toc.clientHeight + 2) return;   /* rien a faire : tout tient */
    var t = a.offsetTop - toc.clientHeight / 2 + a.offsetHeight / 2;
    var d = Math.abs(t - toc.scrollTop);
    toc.scrollTo({ top: Math.max(0, t), behavior: d > 600 ? 'auto' : 'smooth' });
  }
  var seen = {};
  var io = new IntersectionObserver(function (es) {
    es.forEach(function (e) { seen[e.target.id] = e.isIntersecting ? e.boundingClientRect.top : null; });
    var best = null, bt = 1e9;
    for (var id in seen) {
      if (seen[id] === null || seen[id] === undefined) continue;
      var v = Math.abs(seen[id] - 90);
      if (v < bt) { bt = v; best = id; }
    }
    if (best && links[best]) mark(links[best]);
  }, { rootMargin: '-80px 0px -55% 0px', threshold: 0 });
  Array.prototype.forEach.call(document.querySelectorAll('section[id]'), function (s) {
    if (links[s.id]) io.observe(s);
  });
})();
</script>"""
out = os.path.join(D, "le-plateau-fr.html")
# rebuild cleanly
head_end = body.index("</style>") + len("</style>")
head_part = body[:head_end]
rest = body[head_end:]
html = ("<!doctype html>\n<html lang=\"fr\" dir=\"ltr\">\n<head>\n"
        "<meta charset=\"utf-8\">\n"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
        "<meta name=\"description\" content=\"Le Plateau — manuel illustré de prise de vues, de lumière, de son et de montage.\">\n"
        + head_part
        + "\n<style>@page{size:A4;margin:16mm 13mm}</style>\n</head>\n<body>\n"
        + rest
        + "\n" + SPY + "\n</body>\n</html>\n")

open(out, "w", encoding="utf-8").write(html)
print("\nwrote", out, os.path.getsize(out), "bytes")

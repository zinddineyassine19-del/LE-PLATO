#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Les deux schémas de l'annexe C : la claquette légendée, et les huit angles."""
import json
import math
import os

D = os.path.dirname(os.path.abspath(__file__))
S = {}


def fmt(v):
    if isinstance(v, str):
        return v
    return ("%.1f" % v).rstrip("0").rstrip(".")


def svg(key, w, h, alt, body):
    S[key] = ('<svg viewBox="0 0 %d %d" role="img" aria-label="%s">\n%s\n</svg>'
              % (w, h, alt, body.strip()))


def t(x, y, s, cls="", anchor="", extra=""):
    a = ' text-anchor="%s"' % anchor if anchor else ""
    c = ' class="%s"' % cls if cls else ""
    return '<text x="%s" y="%s"%s%s%s>%s</text>' % (
        fmt(x), fmt(y), c, a, (" " + extra) if extra else "", s)


def ln(x1, y1, x2, y2, cls="sl", w=1.4, extra=""):
    return '<line x1="%s" y1="%s" x2="%s" y2="%s" class="%s" stroke-width="%s"%s/>' % (
        fmt(x1), fmt(y1), fmt(x2), fmt(y2), cls, w, (" " + extra) if extra else "")


def rect(x, y, w, h, cls="", extra=""):
    return '<rect x="%s" y="%s" width="%s" height="%s"%s%s/>' % (
        fmt(x), fmt(y), fmt(w), fmt(h),
        ' class="%s"' % cls if cls else "", (" " + extra) if extra else "")


def pastille(x, y, n, cls="fk"):
    """Une pastille numérotée : la légende se lit dans le tableau, pas sur le dessin."""
    return ('<circle cx="%s" cy="%s" r="9" class="%s"/>'
            '<text x="%s" y="%s" text-anchor="middle" class="sm b n" '
            'fill="var(--panel)" style="font-size:10.5px">%d</text>'
            % (fmt(x), fmt(y), cls, fmt(x), fmt(y + 3.6), n))


# ===========================================================================
# C.1  la claquette, champ par champ
# ===========================================================================
b = [t(20, 26, "LA CLAQUETTE — CE QU'ON ÉCRIT DANS CHAQUE CASE", "b kt")]

# ---- le bâton claqueur, en haut ----
BX, BY, BW, BH = 60, 46, 470, 30
b.append(rect(BX, BY, BW, BH, "bgp", 'rx="2"'))
# les bandes obliques : une sur deux pleine
pas = BW / 12.0
for i in range(12):
    x0 = BX + i * pas
    if i % 2 == 0:
        b.append('<path class="fc" opacity=".82" d="M%s,%s L%s,%s L%s,%s L%s,%s Z"/>'
                 % (fmt(x0), fmt(BY + BH), fmt(x0 + pas * .58), fmt(BY),
                    fmt(x0 + pas), fmt(BY), fmt(x0 + pas * .42), fmt(BY + BH)))
b.append(rect(BX, BY, BW, BH, "nf sc", 'rx="2" stroke-width="1.4"'))
b.append(t(BX + BW + 12, BY + 12, "le bâton", "sm mut"))
b.append(t(BX + BW + 12, BY + 26, "claque ici", "sm mut"))

# ---- l'ardoise ----
AX, AY, AW, AH = 60, 88, 470, 240
b.append(rect(AX, AY, AW, AH, "bgp", 'rx="3"'))
b.append(rect(AX, AY, AW, AH, "nf sc", 'rx="3" stroke-width="1.6"'))

# la grille : (x, y, w, h, étiquette, valeur, n° de pastille, classe de valeur)
COL = AW
CASES = [
    (0,   0,   1.00, .215, "PROD.",      "LE PLATEAU",      1, "kt"),
    (0,   .215, .34, .215, "ROLL",       "A001",            2, "dt"),
    (.34, .215, .33, .215, "SCENE",      "12 B",            3, "at"),
    (.67, .215, .33, .215, "TAKE",       "87",              4, "at"),
    (0,   .43,  1.00, .19, "DIRECTOR",   "Y. ZINEDDINE",    5, "kt"),
    (0,   .62,  1.00, .19, "CAMERA",     "A. BENALI",       6, "kt"),
    (0,   .81,  .40, .19, "DATE",        "16 · 09 · 26",    7, "dt"),
    (.40, .81,  .30, .19, "DAY / NIGHT", "NUIT",            8, "dt"),
    (.70, .81,  .30, .19, "SYNC / MOS",  "SYNC",            9, "dt"),
]
for cx, cy, cw, ch, lab, val, num, vcls in CASES:
    x, y = AX + cx * COL, AY + cy * AH
    w, h = cw * COL, ch * AH
    b.append(rect(x, y, w, h, "nf sl", 'stroke-width="1"'))
    b.append(t(x + 9, y + 15, lab, "sm mut"))
    b.append(t(x + 9, y + h - 12, val, vcls + " b n", extra='style="font-size:15px"'))
    b.append(pastille(x + w - 16, y + 16, num))

b.append(t(20, 350, "Les pastilles renvoient au tableau ci-dessous.", "sm mut"))

svg("SVG065", 620, 362,
    "Une claquette de tournage renseignée : production, rouleau, scène, prise, "
    "réalisateur, caméra, date, jour ou nuit, son ou muet — chaque case portant "
    "une pastille numérotée.", "\n".join(b))


# ===========================================================================
# C.2  les huit angles — cinq hauteurs, deux places, et le hollandais à part
# ===========================================================================
b = [t(20, 24, "LES HUIT ANGLES", "b kt")]

# ---------------- panneau gauche : la hauteur (vue de profil) ----------------
b.append(t(20, 46, "EN HAUTEUR — vue de profil", "sm dt b"))
b.append(rect(20, 54, 344, 330, "nf sl", 'rx="6" stroke-width="1"'))

# Le personnage tient la hauteur du panneau : c'est lui le sujet. La caméra se
# dessine à son échelle — un objet qu'on porte, pas un meuble.
PS, CS = 0.62, 0.58
SX, GY = 320, 352
EY = GY - 278 * PS                       # l'œil, à sa vraie hauteur sur le corps
R = 112
b.append(ln(40, GY, 356, GY, "sl", 1.6))
b.append('<g class="fc" transform="translate(%s,%s) scale(%s)"><use href="#person"/></g>'
         % (fmt(SX), fmt(GY - 300 * PS), fmt(PS)))
b.append(ln(40, EY, 356, EY, "sl", 1, 'stroke-dasharray="5 5"'))
b.append(t(44, EY - 7, "ligne d\'œil", "sm mut"))

POS = [
    ("Vol d\'oiseau", "bird\'s eye", 88, "fk", "kt"),
    ("Plongée", "high angle", 42, "fk", "kt"),
    ("Hauteur d\'œil", "eye level", 0, "fd", "dt"),
    ("Contre-plongée", "low angle", -34, "fa", "at"),
    ("Ras du sol", "worm\'s eye", -62, "fa", "at"),
]
for nom, en, deg, cls, tcls in POS:
    a = math.radians(deg)
    rr = R + (30 if deg < -50 else 0)
    cx = SX - rr * math.cos(a)
    cy = EY - rr * math.sin(a)
    if cy > GY - 16:
        cy = GY - 16
    b.append(ln(cx, cy, SX, EY, "sl", 1, 'stroke-dasharray="3 4"'))
    # l'orientation vient de la visée : la caméra regarde là où le cadre regarde
    rot = math.degrees(math.atan2(EY - cy, SX - cx))
    b.append('<g class="%s"><g transform="translate(%s,%s) rotate(%s) scale(%s)">'
             '<use href="#cam"/></g></g>'
             % (cls, fmt(cx), fmt(cy), fmt(rot), fmt(CS)))
    lx = cx - (28 if abs(deg) > 60 else 22)
    b.append(t(lx, cy, nom, tcls + " b sm", anchor="end"))
    b.append(t(lx, cy + 13, en, "sm mut", anchor="end"))

# ---------------- panneau droit : le plan (vue de dessus) ----------------
b.append(t(384, 46, "EN PLAN — vue de dessus", "sm dt b"))
b.append(rect(384, 54, 216, 330, "nf sl", 'rx="6" stroke-width="1"'))


def duo(y0, titre, en, cls, cam_dx, cam_dy, _rot_ignore, note1, note2):
    """Deux personnages vus de dessus, et la caméra quelque part autour."""
    g = []
    g.append(t(398, y0, titre, "kt b sm"))
    g.append(t(398, y0 + 13, en, "sm mut"))
    cx0, cy0 = 500, y0 + 68
    g.append('<g class="fc" opacity=".30" transform="translate(%s,%s) rotate(90) '
             'scale(0.13)"><use href="#person"/></g>' % (fmt(cx0 - 50), fmt(cy0 + 16)))
    g.append('<g class="fc" transform="translate(%s,%s) rotate(-90) scale(0.13)">'
             '<use href="#person"/></g>' % (fmt(cx0 + 52), fmt(cy0 - 16)))
    rot = math.degrees(math.atan2((cy0 - 14) - (cy0 + cam_dy), (cx0 + 44) - (cx0 + cam_dx)))
    g.append('<g class="%s"><g transform="translate(%s,%s) rotate(%s) scale(%s)">'
             '<use href="#cam"/></g></g>'
             % (cls, fmt(cx0 + cam_dx), fmt(cy0 + cam_dy), fmt(rot), fmt(CS)))
    g.append('<path class="nf %s" stroke-width="1" stroke-dasharray="3 4" d="M%s,%s L%s,%s"/>'
             % ("sk" if cls == "fk" else "sa",
                fmt(cx0 + cam_dx + 14), fmt(cy0 + cam_dy - 6), fmt(cx0 + 44), fmt(cy0 - 14)))
    g.append(t(398, y0 + 126, note1, "sm mut"))
    g.append(t(398, y0 + 139, note2, "sm mut"))
    return g


b += duo(72, "Amorce", "over the shoulder", "fk", -74, 22, 22,
         "la caméra passe derrière une épaule :",
         "on voit qui parle et qui écoute")
b.append(ln(396, 228, 588, 228, "sl", 1, 'stroke-dasharray="4 4"'))
b += duo(242, "Point de vue", "point of view", "fa", -46, -14, 0,
         "la caméra prend la place des yeux :",
         "l\'autre regarde l\'objectif")

# ---------------- bande du bas : le plan hollandais ----------------
b.append(rect(20, 398, 580, 76, "bga", 'rx="6" opacity=".38"'))
b.append(t(36, 420, "ET LE HUITIÈME : LE PLAN HOLLANDAIS", "b at sm"))
b.append(t(36, 440, "Ni une hauteur ni une place : la caméra tourne autour de son", "sm mut"))
b.append(t(36, 455, "axe optique. Seul l\'horizon penche — et tout le monde le sent.", "sm mut"))
b.append('<defs><clipPath id="acdu"><rect x="472" y="404" width="112" height="64" rx="3"/>'
         '</clipPath></defs>')
b.append(rect(472, 404, 112, 64, "bgp", 'rx="3"'))
b.append('<g clip-path="url(#acdu)"><g transform="rotate(13 528 436)">'
         + ln(462, 452, 594, 452, "sl", 1.3)
         + '<g class="fc" opacity=".85" transform="translate(528,406) scale(0.165)">'
           '<use href="#person"/></g></g></g>')
b.append(rect(472, 404, 112, 64, "nf sl", 'rx="3" stroke-width="1.2"'))

svg("SVG066", 620, 486,
    "Les huit angles : à gauche, cinq hauteurs de caméra vues de profil ; à droite, "
    "l\'amorce et le point de vue vus de dessus ; en bas, le plan hollandais et son "
    "horizon penché.", "\n".join(b))


# ---------------------------------------------------------------- magasin
p = os.path.join(D, "svgstore_fr.json")
store = json.load(open(p, encoding="utf-8"))
store.update(S)
json.dump(store, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print("schémas écrits :", ", ".join(sorted(S)))
print("magasin :", len(store), "entrées")

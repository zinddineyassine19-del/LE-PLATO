#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Dessine les douze schémas de la Partie IV et les range dans le magasin SVG."""
import json, math, os, random

D = os.path.dirname(os.path.abspath(__file__))
S = {}


def svg(key, w, h, alt, body):
    S[key] = ('<svg viewBox="0 0 %d %d" role="img" aria-label="%s">\n%s\n</svg>'
              % (w, h, alt, body.strip()))


def t(x, y, s, cls="", anchor="", extra=""):
    a = ' text-anchor="%s"' % anchor if anchor else ""
    c = ' class="%s"' % cls if cls else ""
    return '<text x="%s" y="%s"%s%s%s>%s</text>' % (
        fmt(x), fmt(y), c, a, (" " + extra) if extra else "", s)


def fmt(v):
    if isinstance(v, str):
        return v
    return ("%.1f" % v).rstrip("0").rstrip(".")


def ln(x1, y1, x2, y2, cls="sl", w=1.4, extra=""):
    return '<line x1="%s" y1="%s" x2="%s" y2="%s" class="%s" stroke-width="%s"%s/>' % (
        fmt(x1), fmt(y1), fmt(x2), fmt(y2), cls, w, (" " + extra) if extra else "")


def rect(x, y, w, h, cls="", extra=""):
    return '<rect x="%s" y="%s" width="%s" height="%s"%s%s/>' % (
        fmt(x), fmt(y), fmt(w), fmt(h),
        ' class="%s"' % cls if cls else "", (" " + extra) if extra else "")


# ===========================================================================
# 28.1  incident / réfléchi
# ===========================================================================
b = []
b.append(t(20, 30, "MESURER LA LUMIÈRE — DEUX QUESTIONS, DEUX RÉPONSES", "b kt"))

# --- la scène ---
b.append('<use href="#cam" transform="translate(74,196) scale(1.3)" class="fc"/>')
b.append(t(74, 232, "caméra", "sm mut", "middle"))

b.append('<use href="#person" transform="translate(336,44) scale(.60)" class="fc"/>')

# le projecteur
lx, ly = 528, 92
ang = math.degrees(math.atan2(120 - ly, 350 - lx))
b.append('<use href="#lamp" transform="translate(%d,%d) rotate(%.1f) scale(1.05)" class="fk"/>' % (lx, ly, ang))
b.append(t(566, 78, "source", "sm kt", "middle"))
for dy in (-14, 0, 14):
    b.append(ln(lx - 22, ly + dy * .5, 372, 118 + dy, "sk", 1.3,
                'marker-end="url(#arwK)" opacity=".85"'))
b.append(t(430, 78, "ce qui ARRIVE", "sm kt", "middle"))

# le posemètre incident, à la joue, tourné vers l'objectif
b.append('<g transform="translate(300,104)">'
         + rect(-8, -13, 17, 27, "bgp", 'rx="3" stroke="var(--key)" stroke-width="1.5"')
         + '<path d="M-8 -8 a9 9 0 0 0 0 16z" class="fk"/>'
         + rect(-4, -7, 10, 8, "", 'fill="var(--key)" opacity=".28" rx="1"')
         + '</g>')
b.append(ln(292, 104, 150, 168, "sk", 1.1, 'stroke-dasharray="4 4" opacity=".55"'))
b.append(t(296, 76, "posemètre incident", "sm kt", "end"))
b.append(t(296, 89, "demi-sphère vers l'objectif", "sm mut", "end"))

# le trajet réfléchi
b.append('<path d="M318 134 Q234 156 124 178" class="nf sd" stroke-width="1.5" '
         'marker-end="url(#arwD)"/>')
b.append(t(224, 168, "ce qui REPART", "sm dt", "middle"))
b.append('<g transform="translate(120,152)">'
         + rect(-9, -13, 18, 27, "bgp", 'rx="3" stroke="var(--day)" stroke-width="1.5"')
         + '<path d="M9 -9 l10 -7 v32 l-10 -7z" class="fd" opacity=".55"/>'
         + '</g>')
b.append(t(110, 116, "posemètre réfléchi", "sm b dt"))
b.append(t(110, 130, "ou spotmètre", "sm mut"))

b.append(ln(20, 250, 600, 250, "sl", 1))

# --- la même lumière, trois sujets ---
b.append(t(20, 272, "LA MÊME LUMIÈRE, TROIS SUJETS", "b", 'style="font-size:11.5px"'))
cols = [(120, "#14171B", "costume noir", "4 %", "f/2,8", "deux diaphs trop ouvert"),
        (310, "#8C8F94", "gris moyen", "18 %", "f/5,6", "juste — par chance"),
        (500, "#EDEFF2", "chemise blanche", "90 %", "f/11", "deux diaphs trop fermé")]
for cx, col, name, pc, rd, note in cols:
    b.append(rect(cx - 78, 282, 156, 26, "", 'fill="%s" rx="3" stroke="var(--line)" stroke-width="1"' % col))
    b.append(t(cx, 299, name + " · " + pc, "sm", "middle",
               'style="fill:%s"' % ("#EDEFF2" if col == "#14171B" else "#14171B")))
    b.append(t(cx, 324, "réfléchi " + rd, "sm dt", "middle"))
    b.append(t(cx, 338, note, "sm mut", "middle"))
b.append(t(310, 358, "incident : f/5,6 — la même lecture pour les trois", "b kt", "middle",
           'style="font-size:12.5px"'))
svg("SVG045", 620, 372,
    "Le posemètre incident se place au sujet et mesure la lumière qui arrive ; "
    "le posemètre réfléchi mesure depuis la caméra la lumière renvoyée, "
    "qui varie de quatre diaphragmes selon la clarté du sujet",
    "\n".join(b))


# ===========================================================================
# 28.2  fausses couleurs
# ===========================================================================
b = []
X0, XW = 74, 486                      # 0 → 100 IRE


def ire(v):
    return X0 + v * XW / 100.0


b.append('<defs><linearGradient id="fcRamp" x1="0" y1="0" x2="1" y2="0">'
         '<stop offset="0" stop-color="#16191D"/><stop offset="1" stop-color="#F2F4F6"/>'
         '</linearGradient></defs>')
b.append(t(20, 28, "FAUSSES COULEURS — CE QUE CHAQUE TEINTE VEUT DIRE", "b kt"))

BAR_Y, BAR_H = 52, 46
b.append(rect(X0, BAR_Y, XW, BAR_H, "", 'fill="url(#fcRamp)" rx="2"'))
BANDS = [(0, 2.5, "#8E5BD0", "violet", "noir écrêté — plus rien dedans"),
         (2.5, 4, "#3D6FD6", "bleu", "le plancher du noir"),
         (38, 42, "#3FA96B", "vert", "gris 18 % · la charte grise"),
         (52, 56, "#E27AAE", "rose", "peau claire au bon niveau"),
         (97, 99, "#E8C13F", "jaune", "un demi-diaph avant la casse"),
         (99, 100, "#C0392B", "rouge", "blanc écrêté — plus rien dedans")]
for a, z, col, _, _2 in BANDS:
    b.append(rect(ire(a), BAR_Y, max(3.2, ire(z) - ire(a)), BAR_H, "", 'fill="%s"' % col))
b.append(rect(X0, BAR_Y, XW, BAR_H, "nf sl", 'stroke-width="1.4" rx="2"'))
for v in range(0, 101, 10):
    b.append(ln(ire(v), BAR_Y + BAR_H, ire(v), BAR_Y + BAR_H + 5, "sl", 1))
    b.append(t(ire(v), BAR_Y + BAR_H + 18, str(v), "sm mut", "middle"))
b.append(t(X0 - 10, BAR_Y + BAR_H + 18, "IRE", "sm mut", "end"))

LY = 132
for i, (a, z, col, name, lab) in enumerate(BANDS):
    cx = 30 + (i % 2) * 300
    cy = LY + (i // 2) * 24
    b.append(rect(cx, cy - 9, 13, 13, "", 'fill="%s" rx="2"' % col))
    b.append(t(cx + 21, cy + 1, name, "sm b", "", 'style="fill:%s"' % col))
    b.append(t(cx + 74, cy + 1, lab, "sm mut"))

b.append(ln(20, 212, 600, 212, "sl", 1))
b.append(t(20, 236, "OÙ POSER UN VISAGE", "b", 'style="font-size:11.5px"'))
SK = [(96, "#F0CBA8", "peau très claire", "58 IRE"),
      (250, "#D8A87C", "peau claire", "55 IRE"),
      (404, "#A9764E", "peau mate", "50 IRE"),
      (546, "#6B4630", "peau foncée", "45 IRE")]
for cx, col, name, v in SK:
    b.append('<circle cx="%d" cy="272" r="21" fill="%s" stroke="var(--line)" stroke-width="1"/>'
             % (cx, col))
    b.append(t(cx, 308, name, "sm mut", "middle"))
    b.append(t(cx, 322, v, "sm b kt", "middle"))
b.append(t(310, 348, "la peau ne se pose pas à 50 IRE parce que c'est le milieu :",
           "sm mut", "middle"))
b.append(t(310, 362, "elle se pose là où elle garde de la matière", "sm mut", "middle"))
svg("SVG046", 620, 376,
    "L'échelle des fausses couleurs de 0 à 100 IRE, avec les bandes violette, bleue, "
    "verte, rose, jaune et rouge, et les niveaux où poser les différentes carnations",
    "\n".join(b))


# ===========================================================================
# 29.1  les quatre familles de filtres
# ===========================================================================
b = []
b.append('<defs>'
         '<linearGradient id="ftGrad" x1="0" y1="0" x2="0" y2="1">'
         '<stop offset="0" stop-color="#20242A" stop-opacity=".82"/>'
         '<stop offset=".55" stop-color="#20242A" stop-opacity=".18"/>'
         '<stop offset="1" stop-color="#20242A" stop-opacity="0"/></linearGradient>'
         '<radialGradient id="ftHalo"><stop offset="0" stop-color="#E8A33D" stop-opacity=".85"/>'
         '<stop offset=".45" stop-color="#E8A33D" stop-opacity=".28"/>'
         '<stop offset="1" stop-color="#E8A33D" stop-opacity="0"/></radialGradient>'
         '</defs>')


def cell(x, y, w, h, title, sub):
    return [rect(x, y, w, h, "bgp", 'rx="8"'),
            rect(x, y, w, h, "nf sl", 'rx="8" stroke-width="1.2"'),
            t(x + 14, y + 25, title, "b kt", "", 'style="font-size:12.5px"'),
            t(x + 14, y + 41, sub, "sm mut")]


CW, CH = 288, 166
b += cell(18, 34, CW, CH, "NEUTRE · ND", "retire de la quantité, pas de la couleur")
gx = 18 + 158
b.append(rect(gx, 76, 9, 100, "", 'fill="#20242A" opacity=".55" rx="1"'))
b.append(rect(gx, 76, 9, 100, "nf sl", 'stroke-width="1" rx="1"'))
for i in range(7):
    yy = 84 + i * 13
    b.append(ln(52, yy, gx - 10, yy, "sk", 2, 'marker-end="url(#arwK)" opacity=".9"'))
for i in (2, 4):
    yy = 84 + i * 13
    b.append(ln(gx + 14, yy, 18 + CW - 24, yy, "sk", 2, 'marker-end="url(#arwK)"'))
b.append(t(52, 190, "7 entrent", "sm mut"))
b.append(t(18 + CW - 24, 190, "2 sortent · ND 0.9", "sm kt", "end"))

b += cell(314, 34, CW, CH, "POLARISANT", "ne garde qu'une orientation d'onde")
gx = 314 + 158
b.append(rect(gx, 76, 9, 100, "bgp", 'rx="1"'))
for i in range(9):
    b.append(ln(gx + 1 + i, 76, gx + 1 + i, 176, "sd", .9, 'opacity=".9"'))
b.append(rect(gx, 76, 9, 100, "nf sl", 'stroke-width="1" rx="1"'))
random.seed(7)
for i in range(7):
    yy = 84 + i * 13
    b.append(ln(348, yy, gx - 10, yy, "sd", 1, 'opacity=".6"'))
    a = random.uniform(0.3, math.pi - 0.3)
    for k in (0, 1):
        px = 366 + k * 40
        b.append(ln(px - 5 * math.cos(a), yy - 5 * math.sin(a),
                    px + 5 * math.cos(a), yy + 5 * math.sin(a), "sd", 1.7))
for i in (1, 3, 5):
    yy = 84 + i * 13
    b.append(ln(gx + 22, yy - 5, gx + 22, yy + 5, "sd", 1.8))
    b.append(ln(gx + 30, yy, 314 + CW - 24, yy, "sd", 1, 'marker-end="url(#arwD)"'))
b.append(t(348, 190, "toutes orientations", "sm mut"))
b.append(t(314 + CW - 24, 190, "une seule passe", "sm dt", "end"))

b += cell(18, 214, CW, CH, "DIFFUSION", "ajoute du halo, baisse le contraste")
b.append('<circle cx="76" cy="308" r="9" fill="#E8A33D"/>')
b.append(t(76, 348, "sans filtre", "sm mut", "middle"))
b.append(ln(104, 308, 152, 308, "sl", 1.2, 'marker-end="url(#arw)"'))
b.append(rect(160, 268, 9, 82, "bgp", 'rx="1"'))
b.append(rect(160, 268, 9, 82, "nf sl", 'stroke-width="1" rx="1"'))
random.seed(31)
for i in range(26):
    b.append('<circle cx="%.1f" cy="%.1f" r="1" fill="var(--muted)" opacity=".75"/>'
             % (160 + random.uniform(1, 8), 270 + random.uniform(0, 78)))
b.append(t(164, 362, "micro-particules", "sm mut", "middle"))
b.append('<circle cx="248" cy="308" r="42" fill="url(#ftHalo)"/>')
b.append('<circle cx="248" cy="308" r="9" fill="#E8A33D"/>')
b.append(t(248, 348, "avec 1/4", "sm kt", "middle"))

b += cell(314, 214, CW, CH, "DÉGRADÉ · GRAD ND", "n'assombrit que le haut du cadre")
fx0, fy0, fw, fh = 356, 256, 152, 90
b.append(rect(fx0, fy0, fw, fh, "", 'fill="#9FB6CE" rx="2"'))
b.append(rect(fx0, fy0 + 52, fw, fh - 52, "", 'fill="#C0A87E"'))
b.append('<circle cx="%d" cy="%d" r="11" fill="#F0D08A"/>' % (fx0 + 110, fy0 + 24))
b.append(rect(fx0, fy0, fw, 58, "", 'fill="url(#ftGrad)"'))
b.append(rect(fx0, fy0, fw, fh, "nf sl", 'stroke-width="1.3" rx="2"'))
b.append(ln(fx0, fy0 + 52, fx0 + fw, fy0 + 52, "", 1, 'stroke="var(--panel)" opacity=".5"'))
b.append(t(fx0 - 8, fy0 + 26, "ciel", "sm mut", "end"))
b.append(t(fx0 - 8, fy0 + 78, "sol", "sm mut", "end"))
b.append(t(fx0 + fw + 8, fy0 + 26, "−2 diaphs", "sm kt"))
b.append(t(fx0 + fw + 8, fy0 + 78, "intact", "sm mut"))
svg("SVG047", 620, 394,
    "Les quatre familles de filtres : le neutre retire de la quantité, le polarisant "
    "ne laisse passer qu'une orientation d'onde, la diffusion ajoute des halos, "
    "le dégradé n'assombrit que le haut du cadre",
    "\n".join(b))


# ===========================================================================
# 29.2  la polarisation : la mécanique et l'angle
# ===========================================================================
b = []
b.append(t(20, 28, "LA MÉCANIQUE — L'ANGLE DE BREWSTER", "b kt"))
# la vitre
b.append('<path d="M44 214 L232 138" class="sl" stroke-width="3.4" opacity=".5"/>')
b.append(t(44, 234, "vitre, eau, carrosserie laquée", "sm mut"))
# rayon incident
b.append(ln(76, 62, 140, 182, "sk", 1.7, 'marker-end="url(#arwK)"'))
b.append(t(74, 56, "le soleil", "sm b kt"))
# rayon réfléchi, polarisé
b.append(ln(140, 182, 232, 84, "sd", 1.7, 'marker-end="url(#arwD)"'))
for i in range(3):
    px, py = 162 + i * 22, 159 - i * 23
    b.append(ln(px - 5.5, py - 3.5, px + 5.5, py + 3.5, "sd", 1.9))
b.append(t(238, 78, "reflet polarisé", "sm b dt"))
b.append(t(238, 92, "ses ondes vibrent", "sm mut"))
b.append(t(238, 106, "dans un seul plan", "sm mut"))
# transmis
b.append(ln(140, 182, 178, 246, "sl", 1.2, 'stroke-dasharray="4 4"'))
b.append(t(182, 254, "transmis", "sm mut"))
# l'angle
b.append('<path d="M140 138 A44 44 0 0 0 165 168" class="nf sa" stroke-width="1.3"/>')
b.append(ln(140, 182, 140, 128, "sl", 1, 'stroke-dasharray="3 3"'))
b.append(t(148, 132, "≈ 56°", "sm b at"))
# le filtre devant l'objectif
b.append('<g transform="translate(66,304)">'
         '<circle r="28" class="nf sl" stroke-width="2.2"/>'
         + "".join('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" class="sd" stroke-width="1.1" '
                   'opacity=".8"/>'
                   % (-math.sqrt(784 - v * v), v, math.sqrt(784 - v * v), v)
                   for v in range(-24, 25, 7))
         + '<path d="M0 -38 A38 38 0 0 1 27 -27" class="nf sk" stroke-width="1.8" '
         'marker-end="url(#arwK)"/></g>')
b.append(t(108, 288, "on tourne le filtre :", "sm kt"))
b.append(t(108, 302, "la grille retient le reflet", "sm kt"))
b.append(t(108, 316, "ou le laisse passer", "sm kt"))
b.append(t(108, 338, "coût : 1 à 2 diaphs,", "sm mut"))
b.append(t(108, 352, "même sans effet", "sm mut"))

b.append(ln(322, 34, 322, 350, "sl", 1))

b.append(t(342, 24, "OÙ L'EFFET EST MAXIMAL", "b kt"))
b.append(t(342, 38, "vue de dessus", "sm mut"))
CX, CY, R = 470, 172, 86


def wedge(a1, a2):
    return ('<path d="M%s %s A%d %d 0 0 1 %s %s L%s %s Z" fill="var(--daybg)"/>'
            % (fmt(CX + R * math.cos(math.radians(a1))), fmt(CY + R * math.sin(math.radians(a1))),
               R, R,
               fmt(CX + R * math.cos(math.radians(a2))), fmt(CY + R * math.sin(math.radians(a2))),
               CX, CY))


b.append(wedge(-118, -62))
b.append(wedge(62, 118))
b.append('<circle cx="%d" cy="%d" r="%d" class="nf sl" stroke-width="1.3"/>' % (CX, CY, R))
b.append(ln(CX, CY, CX + 104, CY, "sk", 1.6, 'marker-end="url(#arwK)"'))
b.append(t(CX + 26, CY - 8, "vers le soleil", "sm kt"))
b.append(ln(CX, CY, CX - 100, CY, "sl", 1.2, 'stroke-dasharray="4 4"'))
b.append('<use href="#cam" transform="translate(%d,%d) rotate(-90) scale(1)" class="fc"/>'
         % (CX, CY))
b.append(t(CX, CY - R - 12, "90° — effet maximal", "sm b dt", "middle"))
b.append(t(CX, CY + R + 22, "90° — effet maximal", "sm b dt", "middle"))
b.append(t(CX + 104, CY + 16, "0 %", "sm mut", "end"))
b.append(t(CX - 100, CY + 16, "0 %", "sm mut"))
b.append(t(470, 292, "en visant le soleil ou en lui tournant le dos,", "sm mut", "middle"))
b.append(t(470, 306, "le polarisant ne fait plus rien du tout —", "sm mut", "middle"))
b.append(t(470, 320, "c'est pourquoi un panoramique polarisé", "sm mut", "middle"))
b.append(t(470, 334, "fait respirer le bleu du ciel", "sm mut", "middle"))
svg("SVG048", 620, 366,
    "La mécanique du polarisant : le reflet d'une vitre vu vers 56 degrés est polarisé "
    "et la grille du filtre le retient ou le laisse passer ; vue de dessus, l'effet est "
    "maximal à 90 degrés du soleil et nul dans son axe",
    "\n".join(b))


# ===========================================================================
# 30.1  la tranche de netteté
# ===========================================================================
b = []
b.append(t(20, 28, "LA ZONE DE NETTETÉ SE DÉPLACE AVEC LA BAGUE", "b kt"))
AX, AY, AW = 92, 176, 460          # l'axe optique
b.append(ln(AX, AY, AX + AW, AY, "sl", 1.4))
b.append('<use href="#cam" transform="translate(50,176) scale(1.25)" class="fc"/>')
for m in (1, 2, 3, 4, 5, 6):
    x = AX + (m - 1) * AW / 5.5
    b.append(ln(x, AY - 5, x, AY + 5, "sl", 1))
    b.append(t(x, AY + 20, "%d m" % m, "sm mut", "middle"))
F1, F2 = AX + 1.62 * AW / 5.5, AX + 2.62 * AW / 5.5
FP = AX + 1.95 * AW / 5.5
b.append(rect(F1, 68, F2 - F1, 98, "bgk", 'rx="2"'))
b.append(ln(F1, 68, F1, 166, "sk", 1.3, 'stroke-dasharray="4 3"'))
b.append(ln(F2, 68, F2, 166, "sk", 1.3, 'stroke-dasharray="4 3"'))
b.append(ln(FP, 58, FP, 166, "sa", 1.6))
b.append(t(FP, 50, "plan de mise au point", "sm at", "middle"))
b.append('<use href="#person" transform="translate(%.1f,66) scale(.33)" class="fc"/>' % FP)
b.append(ln(F1, 208, FP - 3, 208, "sk", 1.2, 'marker-start="url(#arwK)" marker-end="url(#arwK)"'))
b.append(ln(FP + 3, 208, F2, 208, "sk", 1.2, 'marker-start="url(#arwK)" marker-end="url(#arwK)"'))
b.append(t((F1 + FP) / 2 - 6, 224, "⅓ devant", "sm kt", "end"))
b.append(t((FP + F2) / 2 + 6, 224, "⅔ derrière", "sm kt"))
b.append(ln(FP + 30, 100, FP + 96, 100, "sd", 1.5, 'marker-end="url(#arwD)"'))
b.append(t(FP + 100, 96, "il avance : la tranche", "sm dt"))
b.append(t(FP + 100, 110, "avance au même rythme", "sm dt"))

b.append(ln(20, 246, 600, 246, "sl", 1))
b.append(t(20, 268, "LA MÊME SCÈNE, TROIS DIAPHRAGMES — 50 mm sur 3 m", "b",
           'style="font-size:11.5px"'))
ROWS = [("f/1,4", 0.10, "8 cm — le point est sur l'œil"),
        ("f/4", 0.29, "24 cm — une tête entière"),
        ("f/11", 0.86, "75 cm — deux comédiens dedans")]
for i, (lab, frac, note) in enumerate(ROWS):
    y = 286 + i * 30
    b.append(t(62, y + 12, lab, "b kt", "end"))
    b.append(ln(74, y + 8, 74 + 260, y + 8, "sl", 1))
    w = max(5, frac * 260 / 0.9)
    b.append(rect(74 + 130 - w / 2, y, w, 17, "bgk", 'rx="2"'))
    b.append(rect(74 + 130 - w / 2, y, w, 17, "nf sk", 'rx="2" stroke-width="1.2"'))
    b.append(ln(74 + 130, y - 3, 74 + 130, y + 20, "sa", 1.2))
    b.append(t(348, y + 12, note, "sm mut"))
svg("SVG049", 620, 392,
    "La zone de netteté forme une tranche autour du plan de mise au point, un tiers "
    "devant et deux tiers derrière, dont l'épaisseur passe de huit centimètres à "
    "f/1,4 à soixante-quinze centimètres à f/11",
    "\n".join(b))


# ===========================================================================
# 30.2  le poste du pointeur
# ===========================================================================
b = []
b.append(t(20, 28, "LE POSTE DU POINTEUR", "b kt"))
GY = 176
# caméra vue de côté
b.append('<use href="#cam" transform="translate(112,120) scale(2.0)" class="fc"/>')
b.append(ln(86, 82, 86, 160, "sa", 1.5, 'stroke-dasharray="6 4"'))
b.append(t(26, 70, "\u03d5  plan du capteur", "sm at"))
# le trajet du comédien
b.append(ln(206, GY, 596, GY, "sl", 1.4))
MARKS = [(268, "1", "1,4 m", .22), (392, "2", "2,6 m", .28), (520, "3", "3,9 m", .34)]
for x, lab, dist, sc in MARKS:
    b.append('<use href="#person" transform="translate(%d,%.0f) scale(%s)" class="fc" '
             'opacity="%s"/>' % (x, GY - 300 * sc - 4, sc, ".95" if lab == "2" else ".33"))
    b.append('<path d="M%d %d h26 M%d %d v14" class="sk" stroke-width="2.6"/>'
             % (x - 13, GY, x, GY))
    b.append('<circle cx="%d" cy="%d" r="8.5" class="fk"/>' % (x, GY + 28))
    b.append('<text x="%d" y="%d" class="sm" text-anchor="middle" '
             'style="fill:var(--panel)">%s</text>' % (x, GY + 31.5, lab))
    b.append(t(x, GY + 48, dist, "sm b kt", "middle"))
b.append(ln(100, 84, 380, 100, "sd", 1.3, 'stroke-dasharray="5 4" marker-end="url(#arwD)"'))
b.append(t(252, 60, "la mesure se prend aux YEUX", "sm b dt", "middle"))
b.append(ln(20, 250, 600, 250, "sl", 1))

# disque de suivi de point
b.append('<g transform="translate(76,302)">'
         '<circle r="32" class="bgp"/><circle r="32" class="nf sl" stroke-width="1.5"/>'
         '<circle r="24" class="nf sl" stroke-width="1"/>')
for i2 in range(24):
    a = math.radians(i2 * 15)
    r1 = 24 if i2 % 3 else 19
    b.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" class="sl" stroke-width="%s"/>'
             % (r1 * math.cos(a), r1 * math.sin(a), 32 * math.cos(a), 32 * math.sin(a),
                "1.4" if i2 % 3 == 0 else ".8"))
for a, lab in ((-128, "1"), (-72, "2"), (-16, "3")):
    ar = math.radians(a)
    b.append('<circle cx="%.1f" cy="%.1f" r="5" class="fk"/>'
             % (28 * math.cos(ar), 28 * math.sin(ar)))
    b.append('<text x="%.1f" y="%.1f" class="sm" text-anchor="middle" '
             'style="fill:var(--panel)">%s</text>'
             % (28 * math.cos(ar), 28 * math.sin(ar) + 3.5, lab))
b.append('</g>')
b.append(t(122, 286, "le disque de suivi", "sm b kt"))
b.append(t(122, 302, "porte les trois marques", "sm mut"))
b.append(t(122, 318, "au crayon gras", "sm mut"))

# moniteur du pointeur
b.append(rect(308, 266, 146, 84, "bgp", 'rx="5"'))
b.append(rect(308, 266, 146, 84, "nf sl", 'rx="5" stroke-width="1.3"'))
b.append(rect(318, 276, 126, 52, "", 'fill="#20242A" rx="2"'))
b.append('<use href="#person" transform="translate(382,272) scale(.17)" fill="#8C8F94"/>')
b.append('<path d="M362 284 q20 -9 40 0" class="nf" stroke="#E14B3B" stroke-width="1.7"/>')
b.append(rect(326, 284, 24, 16, "nf", 'stroke="#E8A33D" stroke-width="1.3" rx="1"'))
b.append(t(381, 342, "le moniteur du pointeur", "sm mut", "middle"))
b.append(t(466, 286, "aide au point", "sm", "", 'style="fill:#C0392B"'))
b.append(t(466, 302, "agrandissement", "sm kt"))
b.append(t(466, 324, "il regarde le", "sm mut"))
b.append(t(466, 338, "comédien, pas l'écran", "sm mut"))
svg("SVG050", 620, 366,
    "Le poste du premier assistant caméra : plan du capteur repéré par le sigle phi, "
    "disque de suivi de point marqué au crayon, marques au sol du comédien et "
    "moniteur avec aide au point et agrandissement",
    "\n".join(b))


# ===========================================================================
# 31.1  les signatures de chaque support
# ===========================================================================
b = []
b.append(t(20, 26, "LA SIGNATURE DE CHAQUE SUPPORT — SIX SECONDES DE PLAN", "b kt"))
b.append(t(600, 26, "amplitude, en degrés", "sm mut", "end"))
LANES = [("à main levée", "tout passe", 13.0, 1.00, 1.0),
         ("à l'épaule", "le tronc amortit", 6.5, 0.55, 0.75),
         ("Steadicam", "le bras découple", 2.6, 0.10, 0.30),
         ("tête motorisée", "trois axes corrigés", 1.5, 0.62, 0.14),
         ("trépied", "rien ne bouge", 0.35, 0.05, 0.05)]
LX, LW = 194, 400
for i, (name, note, amp, hi, mid) in enumerate(LANES):
    y = 64 + i * 56
    b.append(rect(LX, y - 23, LW, 46, "bgp", 'rx="4"'))
    b.append(ln(LX, y, LX + LW, y, "sl", 1))
    b.append(t(LX - 16, y - 2, name, "b", "end", 'style="font-size:12.5px"'))
    b.append(t(LX - 16, y + 14, note, "sm mut", "end"))
    random.seed(4000 + i * 17)
    ph = [random.uniform(0, 6.28) for _ in range(6)]
    pts = []
    for k in range(203):
        u = k / 202.0
        v = (amp * .55 * math.sin(u * 5.4 + ph[0])
             + amp * mid * .8 * math.sin(u * 21 + ph[1])
             + amp * hi * .45 * math.sin(u * 63 + ph[2])
             + amp * hi * .30 * math.sin(u * 118 + ph[3])
             + amp * mid * .35 * math.sin(u * 37 + ph[4]))
        pts.append("%.1f,%.1f" % (LX + u * LW, y + max(-20, min(20, v))))
    b.append('<polyline points="%s" class="nf %s" stroke-width="1.6" '
             'stroke-linejoin="round"/>' % (" ".join(pts), "sk" if i < 2 else "sd"))
b.append(t(310, 358, "La tête motorisée efface les rotations mais laisse passer le pas.",
           "sm mut", "middle"))
svg("SVG051", 620, 372,
    "Le tremblement de la caméra tracé dans le temps pour cinq supports : main levée, "
    "épaule, Steadicam, tête motorisée et trépied",
    "\n".join(b))


# ===========================================================================
# 31.2  six libertés
# ===========================================================================
b = []
b.append(t(20, 28, "TROIS ROTATIONS — CE QUE LA TÊTE MOTORISÉE CORRIGE", "b dt"))
ROT = [(112, "panoramique", "lacet"), (310, "inclinaison", "tangage"),
       (508, "roulis", "l'horizon penche")]
for i, (cx, fr_, en) in enumerate(ROT):
    cy = 100
    b.append('<use href="#cam" transform="translate(%d,%d) scale(1.35)" class="fc"/>' % (cx, cy))
    if i == 0:
        b.append('<path d="M%d %d a46 15 0 1 0 .1 0" class="nf sd" stroke-width="1.5" '
                 'marker-end="url(#arwD)" stroke-dasharray="5 4"/>' % (cx - 2, cy + 38))
        b.append(ln(cx, cy - 40, cx, cy + 46, "sl", 1, 'stroke-dasharray="3 3"'))
    elif i == 1:
        b.append('<path d="M%d %d a15 42 0 1 0 0 .1" class="nf sd" stroke-width="1.5" '
                 'marker-end="url(#arwD)" stroke-dasharray="5 4"/>' % (cx + 52, cy))
        b.append(ln(cx - 52, cy, cx + 56, cy, "sl", 1, 'stroke-dasharray="3 3"'))
    else:
        b.append('<path d="M%d %d a42 42 0 1 1 -.1 0" class="nf sd" stroke-width="1.5" '
                 'marker-end="url(#arwD)" stroke-dasharray="5 4"/>' % (cx, cy - 42))
    b.append(t(cx, cy + 82, fr_, "b dt", "middle", 'style="font-size:12.5px"'))
    b.append(t(cx, cy + 98, en, "sm mut", "middle"))

b.append(ln(20, 224, 600, 224, "sl", 1))
b.append(t(20, 248, "TROIS TRANSLATIONS — CE QU'ELLE NE CORRIGE PAS", "b kt"))
TRA = [(112, "latérale", "un pas de côté", 0),
       (310, "avant-arrière", "on avance, on recule", 0),
       (508, "verticale", "LE PAS", 1)]
for cx, fr_, en, hot in TRA:
    cy = 320
    b.append('<use href="#cam" transform="translate(%d,%d) scale(1.35)" class="%s"/>'
             % (cx, cy, "fk" if hot else "fc"))
    ac = "sk" if hot else "sl"
    am = "url(#arwK)" if hot else "url(#arw)"
    if fr_ == "latérale":
        b.append(ln(cx - 56, cy + 40, cx + 56, cy + 40, ac, 1.6,
                    'marker-start="%s" marker-end="%s"' % (am, am)))
    elif fr_ == "avant-arrière":
        b.append(ln(cx + 24, cy + 40, cx + 64, cy + 40, ac, 1.6, 'marker-end="%s"' % am))
        b.append(ln(cx - 24, cy + 40, cx - 64, cy + 40, ac, 1.6, 'marker-end="%s"' % am))
    else:
        b.append(ln(cx + 56, cy - 34, cx + 56, cy + 34, ac, 2.2,
                    'marker-start="%s" marker-end="%s"' % (am, am)))
        for k in range(3):
            b.append('<path d="M%d %d q11 -10 22 0" class="nf sk" stroke-width="1.3" '
                     'opacity=".45"/>' % (cx - 74 + k * 5, cy + 18 + k * 8))
    b.append(t(cx, cy + 68, fr_, "b " + ("kt" if hot else ""), "middle",
               'style="font-size:12.5px"'))
    b.append(t(cx, cy + 84, en, "sm " + ("kt" if hot else "mut"), "middle"))
b.append(t(310, 432, "Le bras à ressorts du Steadicam travaille sur cette verticale.",
           "sm mut", "middle"))
svg("SVG052", 620, 446,
    "Les six libertés d'une caméra : trois rotations — panoramique, inclinaison, roulis — "
    "corrigées par la tête motorisée, et trois translations dont la verticale du pas, "
    "qu'aucun moteur ne compense",
    "\n".join(b))


# ===========================================================================
# 32.1  le soleil dans la journée
# ===========================================================================
b = []
b.append(t(20, 26, "UNE MÊME SCÈNE, CINQ HEURES DE LA JOURNÉE", "b kt"))
HX, HY, HR = 310, 216, 150
b.append('<path d="M%d %d A%d %d 0 0 1 %d %d" class="nf sl" stroke-width="1.2" '
         'stroke-dasharray="5 5"/>' % (HX - HR, HY, HR, HR, HX + HR, HY))
b.append(ln(HX - HR - 44, HY, HX + HR + 44, HY, "sl", 1.4))
b.append(t(HX - HR - 44, HY + 20, "EST", "sm mut"))
b.append(t(HX + HR + 44, HY + 20, "OUEST", "sm mut", "end"))
SUN = [(172, "#E8663D", "2 400 K", "aube"),
       (135, "#F0A03C", "3 200 K", "heure dorée"),
       (90, "#C98A24", "5 600 K", "midi"),
       (45, "#F0A03C", "2 800 K", "heure dorée"),
       (8, "#E8663D", "2 000 K", "coucher")]
DISC = {172: "#E8663D", 135: "#F0A03C", 90: "#FBF0D2", 45: "#F0A03C", 8: "#E8663D"}
for a, col, kel, lab in SUN:
    ar = math.radians(a)
    sx, sy = HX + HR * math.cos(ar), HY - HR * math.sin(ar)
    b.append('<circle cx="%.1f" cy="%.1f" r="15" fill="%s" opacity=".22"/>' % (sx, sy, DISC[a]))
    b.append('<circle cx="%.1f" cy="%.1f" r="9" fill="%s"/>' % (sx, sy, DISC[a]))
    if a == 90:
        b.append(t(sx, sy - 20, kel, "sm b", "middle", 'style="fill:%s"' % col))
        b.append(t(sx, sy + 32, lab, "sm mut", "middle"))
    else:
        side = "end" if a > 90 else "start"
        dx = -20 if a > 90 else 20
        b.append(t(sx + dx, sy - 4, kel, "sm b", side, 'style="fill:%s"' % col))
        b.append(t(sx + dx, sy + 12, lab, "sm mut", side))

b.append(ln(20, 252, 600, 252, "sl", 1))
b.append(t(310, 274, "la hauteur fixe la longueur de l'ombre, l'atmosphère fixe sa couleur",
           "sm mut", "middle"))
VY = 308
for a, col, kel, lab in SUN:
    i2 = [x[0] for x in SUN].index(a)
    cx = 82 + i2 * 114
    b.append(ln(cx - 50, VY + 22, cx + 50, VY + 22, "sl", 1.2))
    hgt = a if a <= 90 else 180 - a
    L = max(10.0, min(46.0, 20 / math.tan(math.radians(max(6.0, hgt)))))
    sgn = 1 if a > 90 else -1                      # l'ombre fuit le soleil
    b.append('<ellipse cx="%s" cy="%s" rx="%s" ry="4.5" fill="#20242A" opacity=".30"/>'
             % (fmt(cx + sgn * L / 2), VY + 23, fmt(L / 2 + 8)))
    b.append('<circle cx="%d" cy="%d" r="15" fill="var(--panel2)" stroke="var(--line)" '
             'stroke-width="1"/>' % (cx, VY + 6))
    b.append('<g transform="translate(%d,%d) rotate(%s)">'
             '<path d="M-15 0 A15 15 0 0 1 15 0 Z" fill="%s" opacity=".62"/></g>'
             % (cx, VY + 6, fmt(90 - a), DISC[a]))
    b.append('<circle cx="%d" cy="%d" r="15" class="nf sl" stroke-width="1"/>' % (cx, VY + 6))
    b.append(rect(cx - 8, VY + 21, 16, 2, "", 'fill="var(--line)"'))
    b.append(t(cx, VY + 48, lab, "sm mut", "middle"))
    b.append(t(cx, VY + 62, ("ombre ×%s" % fmt(L / 20.0)).replace(".", ","),
               "sm b kt", "middle"))
svg("SVG053", 620, 386,
    "La course du soleil dans la journée : cinq positions de l'aube au coucher, "
    "avec leur température de couleur et la longueur de l'ombre portée qui en résulte",
    "\n".join(b))


# ===========================================================================
# 32.2  dispositif extérieur, vue de dessus
# ===========================================================================
b = []
b.append(t(20, 26, "UN PLAN DE JOUR EN EXTÉRIEUR — VUE DE DESSUS", "b kt"))
b.append(rect(24, 40, 572, 296, "", 'fill="url(#grid)" rx="6" opacity=".5"'))
b.append(rect(24, 40, 572, 296, "nf sl", 'rx="6" stroke-width="1.2"'))
# le mur clair
b.append(rect(548, 118, 40, 150, "", 'fill="#E4E0D6" rx="2" stroke="var(--line)" stroke-width="1"'))
b.append('<text transform="translate(572,196) rotate(90)" class="sm mut" '
         'text-anchor="middle">mur clair</text>')
# le soleil
b.append('<circle cx="474" cy="80" r="18" fill="#F0A03C" opacity=".26"/>')
b.append('<circle cx="474" cy="80" r="11" fill="#F0A03C"/>')
b.append(t(474, 62, "SOLEIL", "sm b kt", "middle"))
for d in (-14, 0, 14):
    b.append(ln(462 + d * .2, 94, 344 + d * .5, 178 + d * .3, "sk", 1.4,
                'marker-end="url(#arwK)" opacity=".9"'))
b.append(t(392, 130, "contre-jour ¾", "sm b kt"))
b.append(t(392, 144, "il fait le liseré", "sm kt"))
# la soie
b.append(rect(198, 70, 150, 62, "", 'fill="var(--daybg)" opacity=".9" rx="3"'))
b.append(rect(198, 70, 150, 62, "nf sd", 'rx="3" stroke-width="1.4" stroke-dasharray="6 4"'))
b.append(t(273, 96, "SOIE 4 × 4", "sm b dt", "middle"))
b.append(t(273, 112, "au-dessus du jeu", "sm dt", "middle"))
for x in (198, 348):
    b.append('<circle cx="%d" cy="%d" r="5" class="fd"/>' % (x, 132))
b.append(t(198, 150, "pied lesté", "sm mut", "middle"))
b.append(t(348, 150, "pied lesté", "sm mut", "middle"))
# le comédien
SX, SY = 300, 202
b.append('<circle cx="%d" cy="%d" r="18" class="bgk"/>' % (SX, SY))
b.append('<circle cx="%d" cy="%d" r="18" class="nf sk" stroke-width="1.5"/>' % (SX, SY))
b.append('<use href="#head" transform="translate(%d,%d) scale(.28)" class="fc"/>' % (SX, SY))
b.append(t(SX, SY + 36, "le comédien", "sm mut", "middle"))
# caméra
b.append('<use href="#cam" transform="translate(%d,296) rotate(-90) scale(1.25)" class="fc"/>' % SX)
b.append(t(SX + 26, 302, "caméra", "sm mut"))
b.append(ln(SX, 276, SX, SY + 26, "sl", 1, 'stroke-dasharray="4 4"'))
# le réflecteur
b.append('<g transform="translate(122,246) rotate(-34)">'
         + rect(-40, -5, 80, 10, "", 'fill="#F2F4F6" stroke="var(--line)" stroke-width="1.2" rx="2"')
         + '</g>')
b.append(t(122, 284, "réflecteur", "sm b dt", "middle"))
b.append(ln(150, 232, SX - 26, SY + 8, "sd", 1.4, 'marker-end="url(#arwD)"'))
b.append(t(112, 216, "l'appoint dans les yeux", "sm dt"))
# le drapeau
b.append('<g transform="translate(452,240) rotate(56)">'
         + rect(-34, -5, 68, 10, "", 'fill="#20242A" rx="2"')
         + '</g>')
b.append(t(452, 292, "drapeau", "sm b", "middle", 'style="fill:var(--ink)"'))
b.append(t(452, 308, "il coupe le rebond du mur", "sm mut", "middle"))
b.append('<path d="M430 218 L%d %d" class="nf" stroke="var(--ink)" stroke-width="1.4" '
         'stroke-dasharray="4 4"/>' % (SX + 26, SY + 6))
b.append(t(310, 358, "aucun projecteur allumé — des pieds, des sacs de sable et du tissu",
           "sm mut", "middle"))
svg("SVG054", 620, 372,
    "Vue de dessus d'un plan de jour en extérieur : soleil en contre-jour trois-quarts, "
    "soie tendue au-dessus du jeu, réflecteur côté caméra et drapeau qui coupe le rebond du mur",
    "\n".join(b))


# ===========================================================================
# 33.1  distance et uniformité
# ===========================================================================
b = []
GREEN = "#2FB457"
b.append(t(20, 26, "LA DISTANCE AU FOND", "b kt"))
for i2, (lab, dist, ok) in enumerate((("0,8 m — trop près", 46, 0), ("3 m — juste", 150, 1))):
    x0 = 24 + i2 * 296
    b.append(rect(x0, 40, 268, 166, "bgp", 'rx="6"'))
    b.append(rect(x0, 40, 268, 166, "nf sl", 'rx="6" stroke-width="1.2"'))
    b.append(rect(x0 + 10, 54, 14, 128, "", 'fill="%s" rx="2"' % GREEN))
    b.append('<text transform="translate(%d,118) rotate(-90)" class="sm" text-anchor="middle" '
             'style="fill:#F2F4F6">FOND</text>' % (x0 + 18))
    px = x0 + 24 + dist
    b.append('<use href="#person" transform="translate(%d,62) scale(.40)" class="fc"/>' % px)
    b.append('<g transform="translate(%d,158) rotate(180)"><use href="#cam" class="fc"/></g>'
             % (x0 + 248))
    if not ok:
        for k in range(3):
            b.append('<path d="M%d %d q24 %d 42 3" fill="none" stroke="%s" stroke-width="1.7" '
                     'opacity=".95"/>' % (x0 + 26, 74 + k * 24, -11 + k * 9, GREEN))
            b.append('<path d="M%d %d l-9 -3 l1 7 z" fill="%s"/>'
                     % (x0 + 68, 77 + k * 24, GREEN))
        b.append(t(x0 + 116, 66, "débordement", "sm b", "", 'style="fill:%s"' % GREEN))
        b.append(t(x0 + 116, 80, "sur les épaules", "sm", "", 'style="fill:%s"' % GREEN))
        b.append('<path d="M%d 182 l34 -12 v16 z" fill="#14562A" opacity=".85"/>' % (x0 + 24))
        b.append(t(x0 + 30, 198, "son ombre creuse le fond", "sm", "",
                   'style="fill:#14562A"'))
    else:
        b.append(t(x0 + 30, 66, "pas de débordement", "sm b dt"))
        b.append(t(x0 + 30, 198, "l'ombre tombe hors du cadre", "sm dt"))
    b.append(ln(x0 + 26, 218, px - 14, 218, "sk", 1.2,
                'marker-start="url(#arwK)" marker-end="url(#arwK)"'))
    b.append(t(x0 + 134, 236, lab, "sm b kt", "middle"))

b.append(ln(20, 252, 600, 252, "sl", 1))
b.append(t(20, 276, "L'UNIFORMITÉ DU FOND", "b kt"))
for i2, (lab, spread) in enumerate((("±2 diaphs — le détourage mange les cheveux", 1),
                                    ("±⅓ de diaph — le logiciel n'hésite plus", 0))):
    x0 = 24 + i2 * 296
    b.append('<defs><radialGradient id="gsU%d" cx=".5" cy=".45" r=".72">'
             '<stop offset="0" stop-color="%s" stop-opacity="1"/>'
             '<stop offset="1" stop-color="%s" stop-opacity="%s"/></radialGradient></defs>'
             % (i2, GREEN, GREEN, ".20" if spread else ".88"))
    b.append(rect(x0, 288, 268, 104, "", 'fill="#0F1418" rx="4"'))
    b.append(rect(x0, 288, 268, 104, "", 'fill="url(#gsU%d)" rx="4"' % i2))
    vals = (("−2", "−2", "0", "−2,5", "−1,5") if spread
            else ("−⅓", "0", "0", "−⅓", "−⅓"))
    for (cx, cy), v in zip(((x0 + 32, 312), (x0 + 236, 312), (x0 + 134, 340),
                            (x0 + 32, 372), (x0 + 236, 372)), vals):
        b.append(t(cx, cy, v, "sm b", "middle", 'style="fill:#F2F4F6"'))
    b.append(rect(x0, 288, 268, 104, "nf sl", 'rx="4" stroke-width="1.2"'))
    b.append(t(x0 + 134, 412, lab, "sm " + ("at" if spread else "dt"), "middle"))
svg("SVG055", 620, 426,
    "Le fond vert : trop près, la lumière verte déborde sur les épaules et l'ombre "
    "portée creuse le fond ; un fond dont les coins sont deux diaphragmes sous le "
    "centre oblige le logiciel à élargir sa tolérance",
    "\n".join(b))


# ===========================================================================
# 33.2  le plan de feu du fond vert
# ===========================================================================
b = []
GREEN = "#2FB457"
b.append(t(20, 26, "LE PLAN DE FEU DU FOND VERT — VUE DE DESSUS", "b kt"))
b.append(rect(24, 40, 572, 300, "", 'fill="url(#grid)" rx="6" opacity=".5"'))
b.append(rect(24, 40, 572, 300, "nf sl", 'rx="6" stroke-width="1.2"'))
b.append(rect(128, 62, 364, 14, "", 'fill="%s" rx="2"' % GREEN))
b.append(t(310, 56, "FOND VERT — tendu, mat, sans un pli", "sm b", "middle",
           'style="fill:%s"' % GREEN))
# les deux sources du fond, à 45°
for sgn, x in ((1, 74), (-1, 546)):
    b.append('<use href="#lamp" transform="translate(%d,138) rotate(%d) scale(1.0)" class="fd"/>'
             % (x, -48 if sgn > 0 else 228))
    b.append(t(x, 174, "source fond", "sm b dt", "middle"))
    b.append(t(x, 188, "large · 45°", "sm mut", "middle"))
    for d in (-10, 0, 10):
        b.append(ln(x + sgn * 22, 124, 310 - sgn * (66 + d * 4), 84,
                    "sd", 1.2, 'marker-end="url(#arwD)" opacity=".8"'))
# le comédien
SX, SY = 310, 254
b.append('<circle cx="%d" cy="%d" r="19" class="bgk"/>' % (SX, SY))
b.append('<use href="#head" transform="translate(%d,%d) scale(.30)" class="fc"/>' % (SX, SY))
# la cote au fond
b.append(ln(SX, 80, SX, SY - 24, "sk", 1.1,
            'marker-start="url(#arwK)" marker-end="url(#arwK)" stroke-dasharray="5 4"'))
b.append(t(SX - 8, 166, "3 m du fond", "sm b kt", "end"))
# drapeau noir
b.append(rect(SX - 58, 200, 116, 7, "", 'fill="#20242A" rx="2"'))
b.append(t(SX - 70, 200, "drapeau noir", "sm", "end", 'style="fill:var(--ink)"'))
b.append(t(SX - 70, 214, "il coupe le débordement", "sm mut", "end"))
# le trois-points du sujet
b.append('<use href="#lamp" transform="translate(158,304) rotate(-34) scale(.95)" class="fk"/>')
b.append(t(158, 336, "key", "sm b kt", "middle"))
b.append('<use href="#lamp" transform="translate(464,304) rotate(214) scale(.85)" class="fk" '
         'opacity=".72"/>')
b.append(t(464, 336, "fill", "sm b kt", "middle"))
b.append('<use href="#lamp" transform="translate(406,196) rotate(138) scale(.85)" class="fk"/>')
b.append(t(428, 232, "contre — gélatiné", "sm kt"))
b.append(t(428, 246, "paille, jamais en vert", "sm kt"))
for x0, y0 in ((176, 294), (446, 294)):
    b.append(ln(x0, y0, SX + (28 if x0 < SX else -28), SY + 8, "sk", 1.1,
                'marker-end="url(#arwK)" opacity=".8"'))
b.append(ln(394, 208, SX + 16, SY - 16, "sk", 1.1, 'marker-end="url(#arwK)" opacity=".8"'))
# caméra
b.append('<use href="#cam" transform="translate(%d,314) rotate(-90) scale(1.2)" class="fc"/>' % SX)
b.append(t(SX + 26, 320, "caméra · f/4", "sm mut"))
b.append(ln(SX, 294, SX, SY + 26, "sl", 1, 'stroke-dasharray="4 4"'))
b.append(t(310, 362, "les deux faisceaux se croisent : c'est le croisement qui égalise,",
           "sm mut", "middle"))
b.append(t(310, 376, "pas la puissance — et le fond se pose au diaphragme du visage",
           "sm mut", "middle"))
svg("SVG056", 620, 390,
    "Plan de feu du fond vert vu de dessus : deux sources larges croisées à 45 degrés "
    "sur le fond, comédien à trois mètres avec son propre trois-points, drapeau noir "
    "entre les deux et caméra vers f/4",
    "\n".join(b))


# ===========================================================================
store = json.load(open(os.path.join(D, "svgstore_fr.json"), encoding="utf-8"))
store.update(S)
json.dump(store, open(os.path.join(D, "svgstore_fr.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=0)
print("schémas écrits :", ", ".join(sorted(S)))
print("magasin :", len(store), "entrées")

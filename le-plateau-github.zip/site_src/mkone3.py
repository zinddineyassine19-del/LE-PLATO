#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Le fichier unique trilingue : les trois langues dans un seul document,
le sélecteur bascule sans recharger la page."""
import base64, json, os, re, sys
import os as _os
ICI = _os.path.dirname(_os.path.abspath(__file__))
RACINE = _os.path.dirname(ICI)            # le dossier du dépôt


SRC = ICI
VIT = _os.path.join(RACINE, "site")
OUT = _os.path.join(RACINE, "sortie", "le-plateau-site.html")
_os.makedirs(_os.path.dirname(OUT), exist_ok=True)
sys.path.insert(0, SRC)
import i18n

durl = "data:image/webp;base64," + base64.b64encode(
    open(SRC + "/assets/portrait.webp", "rb").read()).decode()

def anc_de(f):
    """Le nom de fichier d'un chapitre, rendu en ancre du document unique."""
    n = re.match(r"ch(\d+)\.html", f)
    if n:
        return "#c%d" % int(n.group(1))
    return {"annexe-a.html": "#pf", "annexe-b.html": "#ck"}.get(f, f)


# Les trois langues cohabitent dans un seul document, donc les mêmes
# identifiants s'y trouvent trois fois. Chaque script d'un bloc reçoit un
# « document » qui ne voit que son bloc : sans cela, le bouton arabe câblerait
# l'élément français, et les figures pilotables de deux langues sur trois
# seraient mortes.
def borne(bloc):
    def w(m):
        ouvre, corps = m.group(1), m.group(2)
        if "src=" in ouvre or ("type=" in ouvre and "javascript" not in ouvre):
            return m.group(0)
        return (ouvre + "\n;(function(_r){var document=CLEL_DOC(_r);\n"
                + corps + "\n})(document.currentScript.closest('.L'));\n</script>")
    return re.sub(r"(<script[^>]*>)(.*?)</script>", w, bloc, flags=re.S)


parts, head_css, js, motion, ambient, ixs = [], "", "", "", "", {}
for L in i18n.LANGS:
    home = open(os.path.join(VIT, L, "index.html"), encoding="utf-8").read()
    full = open(os.path.join(VIT, L, "livre-complet.html"), encoding="utf-8").read()
    if not head_css:
        head_css = "\n".join(re.findall(r"<style>.*?</style>", home, re.S))
        head_css += ("\n<style>\n" + open(os.path.join(VIT, L, "assets/book.css"),
                                          encoding="utf-8").read() + "\n</style>")
        js = open(SRC + "/site.js", encoding="utf-8").read()
        motion = open(SRC + "/fx/motion.js", encoding="utf-8").read()
        ambient = open(SRC + "/fx/ambient.js", encoding="utf-8").read()

    # la recherche : l'index de chaque langue, ses liens ramenés à des ancres
    _ix = open(os.path.join(VIT, L, "assets/search-index.js"), encoding="utf-8").read()
    _ix = json.loads(_ix[_ix.index("=") + 1:].rstrip().rstrip(";"))
    for _e in _ix:
        _e["u"] = anc_de(_e["u"])
    ixs[L] = _ix

    body = re.search(r"<body[^>]*>(.*)</body>", home, re.S).group(1)
    body = re.sub(r"<script[^>]*src=[^>]*></script>", "", body)
    body = re.sub(r"<picture>.*?</picture>",
                  '<img src="%s" alt="" width="1000" height="925">' % durl, body, flags=re.S)
    body = body.replace("--pm:url('assets/portrait.webp')", "--pm:url('%s')" % durl)
    body = re.sub(r"<link[^>]*>", "", body)

    shell = re.search(r'(<div class="shell">.*?</div>)\s*<div class="sdlg"', full, re.S).group(1)
    defs = re.search(r'(<svg width="0".*?</svg>)', full, re.S).group(1)

    def anc(m):
        f = m.group(1)
        n = re.match(r"ch(\d+)\.html", f)
        if n:
            return 'href="#c%d"' % int(n.group(1))
        return {"annexe-a.html": 'href="#pf"', "annexe-b.html": 'href="#ck"',
                "index.html": 'href="#top-%s"' % L,
                "livre-complet.html": 'href="#livre-%s"' % L}.get(f, m.group(0))

    bloc = body + '<div id="livre-%s" class="booksec">%s\n%s</div>' % (L, defs, shell)
    bloc = re.sub(r'href="((?:ch\d+|annexe-[ab]|acces|index|livre-complet)\.html)"', anc, bloc)
    bloc = re.sub(r'href="\.\./([a-z]{2})/[^"]*"',
                  lambda m: 'href="#" data-go="%s"' % m.group(1), bloc)
    # Le fichier unique voyage seul : le PDF n'est pas à côté de lui. Un bouton
    # qui ne télécharge rien vaut moins que pas de bouton du tout.
    _pdf = r'<a[^>]*href="\.\./Le-Plateau\.pdf"[^>]*>.*?</a>'
    bloc = re.sub(r"\s*·\s*" + _pdf, "", bloc, flags=re.S)   # dans le pied, entre deux points
    bloc = re.sub(r"\s*" + _pdf + r"\s*", "", bloc, flags=re.S)   # en bouton isolé
    bloc = borne(bloc)
    parts.append('<div class="L" data-l="%s" lang="%s" dir="%s"%s><span id="top-%s"></span>%s</div>'
                 % (L, i18n.HTMLLANG[L], i18n.DIR[L], "" if L == "fr" else " hidden", L, bloc))


CLELJS = """<script>
/* Un « document » borné à une langue. Les trois blocs portent les mêmes
   identifiants ; chacun doit pourtant trouver les siens. */
function CLEL_DOC(root) {
  if (!root || typeof Proxy === 'undefined') return document;
  var suf = '-' + (root.dataset ? root.dataset.l : '');
  return new Proxy(document, {
    get: function (d, k) {
      if (k === 'querySelector') return function (s) { return root.querySelector(s); };
      if (k === 'querySelectorAll') return function (s) { return root.querySelectorAll(s); };
      if (k === 'getElementById') return function (i) {
        return root.querySelector('#' + i) || root.querySelector('#' + i + suf);
      };
      var v = d[k];
      return typeof v === 'function' ? v.bind(d) : v;
    }
  });
}
</script>"""

ANCRES = """
<script>
/* Un lien « #c39 » doit mener au c39 de la langue affichée, pas au premier du
   document. On résout donc l'ancre dans le bloc d'où part le clic. */
(function () {
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href^="#"]');
    if (!a || a.hasAttribute('data-go')) return;
    var id = a.getAttribute('href').slice(1);
    if (!id) return;
    var blk = a.closest('.L') || document.querySelector('.L:not([hidden])');
    var t = blk && blk.querySelector('[id="' + id + '"]');
    if (!t) return;
    e.preventDefault();
    var dlg = blk.querySelector('.sdlg.on'); if (dlg) dlg.classList.remove('on');
    var side = blk.querySelector('.side.on'); if (side) side.classList.remove('on');
    t.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
})();
</script>"""

FIXCSS = """<style>
.L[hidden]{display:none!important}
/* Trois langues dans un document : le fondu du « papier » ne sait pas laquelle
   est visible. On rend donc son fond au livre, et on éteint le calque. */
.fx-ground{display:none!important}
.fx-on .booksec{background:var(--ground);color:var(--ink)}
/* La règle body du livre arrive après celle de l'accueil et l'annulait :
   on remet le noir du plateau, en dernier mot. */
body{background:#06080C;color:#E7EBF2}
</style>"""
SWITCH = """
<script>
(function () {
  function go(l) {
    var any = false;
    document.querySelectorAll('.L').forEach(function (d) {
      var on = d.dataset.l === l; d.hidden = !on; if (on) any = true;
    });
    if (!any) return;
    document.documentElement.lang = l;
    document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr';
    if (window.BOOK_IX) window.BOOK_INDEX = window.BOOK_IX[l] || [];
    document.querySelectorAll('.langsel a').forEach(function (a) {
      a.classList.toggle('on', a.getAttribute('data-go') === l);
    });
    try { localStorage.setItem('clel-lang', l); } catch (e) {}
    window.scrollTo(0, 0);
    dispatchEvent(new Event('resize'));
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('[data-go]');
    if (!a) return;
    e.preventDefault(); go(a.getAttribute('data-go'));
  });
  var L = null;
  try { L = localStorage.getItem('clel-lang'); } catch (e) {}
  if (!L) {
    var n = (navigator.languages || [navigator.language || 'fr']).join(',').toLowerCase();
    L = /(^|,)ar/.test(n) ? 'ar' : (/(^|,)en/.test(n) ? 'en' : 'fr');
  }
  go(['fr', 'en', 'ar'].indexOf(L) >= 0 ? L : 'fr');
})();
</script>"""

# Le fichier unique voyage seul : la musique part avec lui, embarquée une
# seule fois pour les trois langues.
_amb = SRC + "/assets/ambiance.mp3"
AMBJS = ""
if os.path.exists(_amb):
    AMBJS = ('<script>window.CLEL_AMBIANCE="data:audio/mpeg;base64,'
             + base64.b64encode(open(_amb, "rb").read()).decode() + '";</script>')
    print("musique embarquée     : %.1f Mo" % (os.path.getsize(_amb) / 1048576))

IXJS = ("<script>window.BOOK_IX="
        + json.dumps(ixs, ensure_ascii=False, separators=(",", ":"))
        + ";window.BOOK_INDEX=window.BOOK_IX.fr;</script>")

CHROME = ("<script>\nfunction CLEL_CHROME(root){var document=CLEL_DOC(root);\n"
          + js + "\n}\ndocument.querySelectorAll('.L').forEach(CLEL_CHROME);\n</script>")

out = ("<title>Le Plateau · The Set · البلاطو</title>\n"
       + head_css + "\n" + FIXCSS + "\n" + CLELJS + "\n" + "\n".join(parts)
       + "\n" + AMBJS + "\n" + IXJS + "\n" + CHROME
       + "\n<script>\n" + motion + "\n" + ambient + "\n</script>\n"
       + ANCRES + "\n" + SWITCH)
out = re.sub(r"\.home(?![\w-])", "body", out)

# La version « artifact » se publie sans balises de document : la plateforme
# fournit elle-même l'enveloppe.
open(SRC + "/artifact-trilingue.html", "w", encoding="utf-8").write(out)
for bad in (r"<!doctype", r"<html[\s>]", r"<head[\s>]", r"<body[\s>]",
            r"</html>", r"</head>", r"</body>"):
    assert not re.search(bad, out, re.I), bad

# Le fichier qu'on télécharge, lui, est un vrai document : il s'ouvre d'un
# double-clic, hors ligne, sur n'importe quel appareil.
doc = ('<!doctype html>\n<html lang="fr" dir="ltr">\n<head>\n'
       '<meta charset="utf-8">\n'
       '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
       '<meta name="description" content="Le Plateau — manuel illustré de prise '
       'de vues, de lumière, de son et de montage. Français · English · العربية.">\n'
       '<meta name="color-scheme" content="dark light">\n'
       + out + "\n</body>\n</html>\n")
# la coupure head/body tombe après le dernier bloc de styles, juste avant la
# première langue
i = doc.rindex("</style>", 0, doc.index('<div class="L"')) + len("</style>")
doc = doc[:i] + "\n</head>\n<body>\n" + doc[i:]
open(OUT, "w", encoding="utf-8").write(doc)
print("fichier unique trilingue — %.0f Ko" % (len(doc) / 1024))

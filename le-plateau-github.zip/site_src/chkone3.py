#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Le fichier unique, langue par langue : chrome, recherche, ancres, figures."""
import asyncio, json
import os as _os
ICI = _os.path.dirname(_os.path.abspath(__file__))
RACINE = _os.path.dirname(ICI)            # le dossier du dépôt

from playwright.async_api import async_playwright

F = "file://" + _os.path.join(RACINE, "sortie", "le-plateau-site.html")
MOTS = {"fr": "montage", "en": "editing", "ar": "عدسة"}


async def main():
    errs, rap = [], {}
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/opt/pw-browsers/chromium")
        pg = await b.new_page(viewport={"width": 1280, "height": 900})
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(F)
        await pg.evaluate("async()=>{await document.fonts.ready}")
        await pg.wait_for_timeout(500)

        for lang in ("fr", "en", "ar"):
            await pg.evaluate(
                "(l)=>document.querySelector('.L:not([hidden]) .langsel [data-go=\"'+l+'\"]').click()",
                lang)
            await pg.wait_for_timeout(350)
            r = {}

            # le thème : le bouton de CETTE langue doit agir
            await pg.evaluate("()=>document.querySelector('.L:not([hidden]) #themeBtn').click()")
            await pg.wait_for_timeout(200)
            r["thème après clic"] = await pg.evaluate(
                "()=>document.documentElement.getAttribute('data-theme')")
            await pg.evaluate("()=>document.querySelector('.L:not([hidden]) #themeBtn').click()")
            await pg.wait_for_timeout(150)

            # la recherche
            await pg.evaluate("()=>document.querySelector('.L:not([hidden]) #searchBtn').click()")
            await pg.wait_for_timeout(250)
            r["dialogue ouvert"] = await pg.evaluate(
                "()=>!!document.querySelector('.L:not([hidden]) .sdlg.on')")
            if r["dialogue ouvert"]:
                await pg.fill(".L:not([hidden]) .sdlg.on input", MOTS[lang])
                await pg.wait_for_timeout(400)
                r["résultats « %s »" % MOTS[lang]] = await pg.evaluate(
                    """()=>{var a=[...document.querySelectorAll('.L:not([hidden]) .sdlg a')];
                       return {n:a.length, t:a.slice(0,2).map(x=>x.textContent.trim().slice(0,40))};}""")
                # cliquer le premier résultat doit descendre dans CETTE langue
                await pg.evaluate("()=>document.querySelector('.L:not([hidden]) .sdlg a').click()")
                await pg.wait_for_timeout(900)
                r["après clic"] = await pg.evaluate(
                    """()=>({y:Math.round(scrollY),
                             langue:(document.elementFromPoint(innerWidth/2,innerHeight/2)||{})
                                    .closest?.('.L')?.dataset.l})""")
            await pg.keyboard.press("Escape")
            await pg.wait_for_timeout(200)

            # une figure pilotable de cette langue répond-elle ?
            r["figures pilotables câblées"] = await pg.evaluate(
                """()=>{var f=[...document.querySelectorAll('.L:not([hidden]) figure.ix')];
                        var ok=f.filter(function(x){return x.querySelector('.ix-btns')
                          ? x.querySelectorAll('.ix-btns button,.ix-btns a').length>0 : true;});
                        return f.length+' figures, '+ok.length+' garnies';}""")
            rap[lang] = r

        await b.close()
    print(json.dumps(rap, ensure_ascii=False, indent=1))
    print("erreurs JS :", errs[:8])


asyncio.run(main())

/* Le Plateau — site behaviour
   thème, menu mobile, barre de progression, recherche plein texte */
(function () {
  'use strict';

  /* ---------------- theme ---------------- */
  var KEY = 'clel-theme';
  function apply(t) {
    if (t === 'dark' || t === 'light') document.documentElement.setAttribute('data-theme', t);
    else document.documentElement.removeAttribute('data-theme');
    var b = document.getElementById('themeBtn');
    if (b) {
      var dark = t === 'dark' || (t !== 'light' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);
      b.setAttribute('aria-label', dark ? 'Passer en mode clair' : 'Passer en mode sombre');
      b.querySelector('.lbl').textContent = dark
        ? (b.dataset.jour || 'Jour') : (b.dataset.nuit || 'Nuit');
      b.querySelector('.i-sun').style.display = dark ? '' : 'none';
      b.querySelector('.i-moon').style.display = dark ? 'none' : '';
    }
  }
  var stored = null;
  try { stored = localStorage.getItem(KEY); } catch (e) {}
  apply(stored);

  document.addEventListener('click', function (e) {
    var t = e.target.closest && e.target.closest('#themeBtn');
    if (!t) return;
    var cur = document.documentElement.getAttribute('data-theme');
    var sysDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    var next = cur ? (cur === 'dark' ? 'light' : 'dark') : (sysDark ? 'light' : 'dark');
    try { localStorage.setItem(KEY, next); } catch (e2) {}
    apply(next);
  });

  /* ---------------- mobile drawer ---------------- */
  var side = document.querySelector('.side'), scrim = document.querySelector('.scrim');
  function drawer(on) {
    if (!side) return;
    side.classList.toggle('open', on);
    if (scrim) scrim.classList.toggle('on', on);
    document.body.style.overflow = on ? 'hidden' : '';
  }
  var mb = document.getElementById('menuBtn');
  if (mb) mb.addEventListener('click', function () { drawer(!side.classList.contains('open')); });
  if (scrim) scrim.addEventListener('click', function () { drawer(false); });
  if (side) side.addEventListener('click', function (e) {
    if (e.target.closest('a')) drawer(false);
  });

  /* ------- révéler le chapitre courant dans le sommaire ------- */
  var cur = document.querySelector('.side a[aria-current="page"]');
  if (cur && side && side.scrollHeight > side.clientHeight + 8) {
    side.scrollTop = Math.max(0, cur.offsetTop - side.clientHeight / 2 + cur.offsetHeight / 2);
  }

  /* ---------------- reading progress ---------------- */
  var bar = document.querySelector('.progress');
  if (bar) {
    var tick = function () {
      var h = document.documentElement;
      var max = h.scrollHeight - h.clientHeight;
      bar.style.width = (max > 40 ? (h.scrollTop / max) * 100 : 0) + '%';
    };
    addEventListener('scroll', tick, { passive: true });
    addEventListener('resize', tick);
    tick();
  }

  /* ============================================================
     Les schémas se dessinent à l'entrée dans le cadre
     ============================================================ */
  (function () {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var figs = document.querySelectorAll('figure:not(.ix)');
    if (!figs.length || !('IntersectionObserver' in window)) return;
    document.documentElement.classList.add('anim');

    var GEO = { line: 1, path: 1, polyline: 1, polygon: 1, circle: 1, ellipse: 1, rect: 1 };

    function prime(fig) {
      if (fig.dataset.primed) return;
      fig.dataset.primed = '1';
      var svg = fig.querySelector('svg');
      if (!svg) return;
      var nodes = svg.querySelectorAll('*'), n = 0;
      for (var i = 0; i < nodes.length; i++) {
        var el = nodes[i];
        if (el.closest('defs, clipPath, mask, marker, linearGradient, radialGradient, pattern')) continue;
        var tag = el.tagName.toLowerCase();
        var delay = Math.min(n * 13, 620);
        if (GEO[tag] && typeof el.getTotalLength === 'function') {
          var cs = getComputedStyle(el);
          var stroked = cs.stroke && cs.stroke !== 'none';
          var dashed = cs.strokeDasharray && cs.strokeDasharray !== 'none';
          if (stroked && !dashed) {
            var len = 0;
            try { len = el.getTotalLength(); } catch (e) { len = 0; }
            if (len > 0.5 && len < 12000) {
              el.style.setProperty('--l', len.toFixed(1));
              el.style.setProperty('--d', delay + 'ms');
              el.classList.add('dw');
              n++;
              continue;
            }
          }
        }
        if (tag === 'text' || tag === 'use' || tag === 'image' ||
            (GEO[tag] && !el.classList.contains('dw'))) {
          el.style.setProperty('--d', (delay + 260) + 'ms');
          el.classList.add('fdin');
          n++;
        }
      }
    }

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        prime(e.target);
        requestAnimationFrame(function () { e.target.classList.add('seen'); });
        io.unobserve(e.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });

    for (var i = 0; i < figs.length; i++) io.observe(figs[i]);
  })();

  /* ============================================================
     Le texte se pose : ouverture de chapitre, intertitres, encadrés
     ============================================================ */
  (function () {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    if (!('IntersectionObserver' in window)) return;
    var sel = '.ch-h, .ch h3, .tw, .tip, .note, .warn, .close';
    var els = document.querySelectorAll(sel);
    if (!els.length) return;
    document.documentElement.classList.add('anim');

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        e.target.classList.add('seen');
        io.unobserve(e.target);
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.12 });

    for (var i = 0; i < els.length; i++) {
      els[i].classList.add('rv');
      io.observe(els[i]);
    }
  })();

  /* ============================================================
     Loupe : n'importe quel schéma s'ouvre en plein écran
     ============================================================ */
  (function () {
    var dlg = document.getElementById('zdlg');
    if (!dlg) return;
    var wrap = dlg.querySelector('#zWrap'), cap = dlg.querySelector('#zCap'),
        name = dlg.querySelector('#zdlgN');
    var zw = 0, zx = 0, zy = 0, base = 0;

    var ICON = '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/>' +
               '<path d="M20 20l-3.5-3.5M8 11h6M11 8v6"/></svg>';

    function apply() {
      wrap.style.setProperty('--zw', zw + 'px');
      wrap.style.setProperty('--zx', zx + 'px');
      wrap.style.setProperty('--zy', zy + 'px');
    }
    function fit() { zw = base; zx = 0; zy = 0; apply(); }
    function scale(f) { zw = Math.max(280, Math.min(9000, zw * f)); apply(); }

    function open(fig) {
      var svg = fig.querySelector('svg');
      if (!svg) return;
      wrap.innerHTML = '';
      var c = svg.cloneNode(true);
      c.removeAttribute('style');
      wrap.appendChild(c);
      var f = fig.querySelector('figcaption');
      cap.textContent = f ? f.textContent.trim() : '';
      var lab = f ? (f.textContent.trim().match(/^Fig\.\s*[\d.]+/) || [''])[0] : '';
      name.textContent = lab || 'Schéma';
      dlg.classList.add('on');
      document.body.style.overflow = 'hidden';
      requestAnimationFrame(function () {
        var vb = (c.getAttribute('viewBox') || '0 0 620 400').split(/[\s,]+/);
        var ar = (+vb[2] || 620) / (+vb[3] || 400);
        var w = wrap.clientWidth * 0.92, h = wrap.clientHeight * 0.92;
        base = Math.max(280, Math.min(w, h * ar));
        fit();
      });
    }
    function close() {
      dlg.classList.remove('on'); wrap.innerHTML = ''; document.body.style.overflow = '';
    }

    dlg.querySelector('#zClose').onclick = close;
    dlg.querySelector('#zFit').onclick = fit;
    dlg.querySelector('#zIn').onclick = function () { scale(1.35); };
    dlg.querySelector('#zOut').onclick = function () { scale(1 / 1.35); };
    dlg.addEventListener('wheel', function (e) {
      if (!dlg.classList.contains('on')) return;
      e.preventDefault(); scale(e.deltaY < 0 ? 1.12 : 1 / 1.12);
    }, { passive: false });

    var down = false, px = 0, py = 0;
    wrap.addEventListener('pointerdown', function (e) {
      down = true; px = e.clientX; py = e.clientY;
      wrap.classList.add('drag'); wrap.setPointerCapture(e.pointerId);
    });
    wrap.addEventListener('pointermove', function (e) {
      if (!down) return;
      zx += e.clientX - px; zy += e.clientY - py; px = e.clientX; py = e.clientY; apply();
    });
    ['pointerup', 'pointercancel'].forEach(function (t) {
      wrap.addEventListener(t, function () { down = false; wrap.classList.remove('drag'); });
    });
    addEventListener('keydown', function (e) {
      if (!dlg.classList.contains('on')) return;
      if (e.key === 'Escape') { e.preventDefault(); close(); }
      else if (e.key === '+' || e.key === '=') scale(1.25);
      else if (e.key === '-') scale(1 / 1.25);
      else if (e.key === '0') fit();
    });

    var fine = matchMedia('(hover:hover) and (pointer:fine)').matches;

    document.querySelectorAll('figure:not(.ix)').forEach(function (fig) {
      var svg = fig.querySelector('svg');
      if (!svg) return;

      var b = document.createElement('button');
      b.className = 'zoombtn'; b.type = 'button';
      b.setAttribute('aria-label', 'Agrandir le schéma');
      b.innerHTML = ICON;
      b.addEventListener('click', function () { open(fig); });
      fig.appendChild(b);
      if (!fine) return;

      /* --- la loupe suit le curseur --- */
      var lens = null, clone = null, raf = 0, tx = 0, ty = 0, Z = 1.9, D = 168;
      function build() {
        lens = document.createElement('div');
        lens.className = 'lens';
        clone = svg.cloneNode(true);
        clone.removeAttribute('style');
        /* on garde les id : url(#…) et <use> se résolvent sur l'original,
           qui est identique et vient avant dans le document. */
        clone.setAttribute('aria-hidden', 'true');
        clone.setAttribute('focusable', 'false');
        lens.appendChild(clone);
        fig.appendChild(lens);
      }
      function place() {
        raf = 0;
        var r = svg.getBoundingClientRect(), fr = fig.getBoundingClientRect();
        clone.style.width = (r.width * Z) + 'px';
        clone.style.height = (r.height * Z) + 'px';
        clone.style.left = (D / 2 - tx * Z) + 'px';
        clone.style.top = (D / 2 - ty * Z) + 'px';
        lens.style.left = (r.left - fr.left + tx - D / 2) + 'px';
        lens.style.top = (r.top - fr.top + ty - D / 2) + 'px';
      }
      svg.addEventListener('pointerenter', function (e) {
        if (e.pointerType !== 'mouse') return;
        if (!lens) build();
        lens.classList.add('on');
      });
      svg.addEventListener('pointermove', function (e) {
        if (e.pointerType !== 'mouse' || !lens) return;
        var r = svg.getBoundingClientRect();
        tx = e.clientX - r.left; ty = e.clientY - r.top;
        if (!raf) raf = requestAnimationFrame(place);
      });
      svg.addEventListener('pointerleave', function () {
        if (lens) lens.classList.remove('on');
      });
    });
  })();

  /* ---------------- search ---------------- */
  var dlg = document.getElementById('sdlg');
  if (!dlg) return;
  var input = dlg.querySelector('input'), out = dlg.querySelector('.sres');
  var sel = -1, rows = [];

  function esc(s) {
    return s.replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function fold(s) {
    return s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  }
  function mark(text, q) {
    var f = fold(text), i = f.indexOf(q);
    if (i < 0) return esc(text);
    return esc(text.slice(0, i)) + '<em>' + esc(text.slice(i, i + q.length)) + '</em>' +
      esc(text.slice(i + q.length));
  }

  function open() {
    dlg.classList.add('on');
    input.value = ''; out.innerHTML = ''; sel = -1; rows = [];
    render('');
    setTimeout(function () { input.focus(); }, 20);
  }
  function close() { dlg.classList.remove('on'); }

  function render(qraw) {
    var q = fold(qraw.trim());
    out.innerHTML = '';
    rows = [];
    var data = window.BOOK_INDEX || [];
    if (q.length < 2) {
      var html = '';
      for (var i = 0; i < Math.min(8, data.length); i++) {
        html += '<a href="' + data[i].u + '"><span class="rn">' + esc(data[i].n) +
          '</span><div class="rt">' + esc(data[i].t) + '</div>' +
          '<div class="rs">' + esc(data[i].l.slice(0, 110)) + '…</div></a>';
      }
      out.innerHTML = html || '';
      rows = Array.prototype.slice.call(out.querySelectorAll('a'));
      return;
    }
    var hits = [];
    for (var k = 0; k < data.length; k++) {
      var d = data[k];
      var inT = d.tf.indexOf(q), inB = d.bf.indexOf(q);
      if (inT < 0 && inB < 0) continue;
      var snip = '';
      if (inB >= 0) {
        var s = Math.max(0, inB - 60), e = Math.min(d.b.length, inB + q.length + 90);
        snip = (s > 0 ? '…' : '') + d.b.slice(s, e) + (e < d.b.length ? '…' : '');
      } else snip = d.l.slice(0, 130) + '…';
      var freq = 0, at = -1;
      while ((at = d.bf.indexOf(q, at + 1)) >= 0) { freq++; if (freq > 40) break; }
      hits.push({ d: d, snip: snip,
        score: (inT >= 0 ? 0 : 4000) - freq * 60 + (inB < 0 ? 9999 : inB / 40) });
    }
    hits.sort(function (a, b) { return a.score - b.score; });
    if (!hits.length) {
      out.innerHTML = '<a class="sel" style="cursor:default"><div class="rs">' +
        esc(dlg.dataset.vide || 'Aucun résultat pour') +
        ' « ' + esc(qraw.trim()) + ' ».</div></a>';
      rows = []; return;
    }
    var h2 = '';
    for (var j = 0; j < Math.min(24, hits.length); j++) {
      var x = hits[j];
      h2 += '<a href="' + x.d.u + '"><span class="rn">' + esc(x.d.n) + '</span>' +
        '<div class="rt">' + mark(x.d.t, q) + '</div>' +
        '<div class="rs">' + mark(x.snip, q) + '</div></a>';
    }
    out.innerHTML = h2;
    rows = Array.prototype.slice.call(out.querySelectorAll('a'));
    sel = -1;
  }

  function move(step) {
    if (!rows.length) return;
    if (sel >= 0) rows[sel].classList.remove('sel');
    sel = (sel + step + rows.length) % rows.length;
    rows[sel].classList.add('sel');
    rows[sel].scrollIntoView({ block: 'nearest' });
  }

  input.addEventListener('input', function () { render(input.value); });
  dlg.addEventListener('click', function (e) { if (e.target === dlg) close(); });
  var sb = document.getElementById('searchBtn');
  if (sb) sb.addEventListener('click', open);

  addEventListener('keydown', function (e) {
    var opened = dlg.classList.contains('on');
    if (!opened) {
      var tag = (e.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea') return;
      if (e.key === '/' || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k')) {
        e.preventDefault(); open(); return;
      }
      if (e.key === 'ArrowRight' && !e.metaKey && !e.ctrlKey && !e.altKey) {
        var n = document.querySelector('.pager .nxt a, .pager a.nxt'); if (n) n.click();
      }
      if (e.key === 'ArrowLeft' && !e.metaKey && !e.ctrlKey && !e.altKey) {
        var p = document.querySelector('.pager .prv a, .pager a.prv'); if (p) p.click();
      }
      return;
    }
    if (e.key === 'Escape') { e.preventDefault(); close(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
    else if (e.key === 'Enter' && sel >= 0 && rows[sel].href) { rows[sel].click(); }
  });
})();

/* le sommaire s'ouvre sur le chapitre où l'on se trouve */
(function () {
  var side = document.querySelector('.side'), cur = side && side.querySelector('a[aria-current="page"]');
  if (!side || !cur) return;
  var d = cur.offsetTop - side.clientHeight / 2 + cur.offsetHeight / 2;
  side.scrollTop = Math.max(0, d);
})();

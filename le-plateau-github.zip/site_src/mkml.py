#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rend le site multilingue sans réécrire les gabarits à la main.

Le principe : toutes les chaînes françaises de l'habillage sont déjà listées
dans i18n.py, avec leur traduction. On les remplace donc automatiquement par un
jeton {{clé}} dans les gabarits, une fois pour toutes ; ensuite le générateur
substitue le jeton par la langue demandée.

  python3 mkml.py --jetons   → pose les jetons dans les gabarits (une seule fois)
  python3 mkml.py --verifie  → dit ce qui reste en français sans jeton
"""
import os
import re
import sys

import i18n

SRC = os.path.dirname(os.path.abspath(__file__))
GABARITS = ["index.tpl.html", "acces.tpl.html", "bande.tpl.html", "paiement.tpl.html"]

# Toutes les tables, aplaties en {clé: {langue: texte}}
TABLES = {}
for k, v in i18n.S.items():
    TABLES["s." + k] = v
for k, v in i18n.HOME.items():
    TABLES["h." + k] = v
for k, v in i18n.ACCES.items():
    TABLES["a." + k] = v
for k, v in i18n.LOCK.items():
    TABLES["l." + k] = v
for k, v in i18n.TODO.items():
    TABLES["t." + k] = v


def cle(texte_fr):
    """La clé dont le français vaut exactement ce texte."""
    for k, v in TABLES.items():
        if v.get("fr") == texte_fr:
            return k
    return None


def poser():
    """Remplace chaque chaîne française connue par son jeton, la plus longue
    d'abord — sinon « Annexe » mangerait « Annexes »."""
    ordre = sorted(TABLES.items(), key=lambda kv: -len(kv[1].get("fr", "")))
    for g in GABARITS:
        p = os.path.join(SRC, g)
        s = open(p, encoding="utf-8").read()
        n = 0
        for k, v in ordre:
            fr = v.get("fr", "")
            if len(fr) < 4 or "%s" in fr:
                continue
            if fr in s:
                s = s.replace(fr, "{{" + k + "}}")
                n += 1
        open(p, "w", encoding="utf-8").write(s)
        print("%-22s %2d jetons posés" % (g, n))


def rendre(s, lang):
    """Substitue les jetons pour une langue."""
    def un(m):
        k = m.group(1)
        v = TABLES.get(k)
        if not v:
            return m.group(0)
        return v.get(lang, v.get("fr", ""))
    return re.sub(r"\{\{([a-z]+\.[A-Za-zА-Яа-яЁёбء-ي_0-9]+)\}\}", un, s)


def verifier():
    """Ce qui reste en français dans les gabarits, hors jetons."""
    mots = re.compile(r"\b(?:le|la|les|des|une|vous|votre|pour|dans|avec|sur|que|qui"
                      r"|est|sont|ce|cette|nous|plus|tout|toute|par|aux?)\b", re.I)
    for g in GABARITS:
        s = open(os.path.join(SRC, g), encoding="utf-8").read()
        s = re.sub(r"\{\{[^}]+\}\}", " ", s)
        s = re.sub(r"<(script|style)\b.*?</\1>", " ", s, flags=re.S)
        restes = []
        for txt in re.findall(r">([^<>]{12,})<", s):
            t = txt.strip()
            if len(mots.findall(t)) >= 2:
                restes.append(re.sub(r"\s+", " ", t)[:78])
        print("\n%s — %d passages encore en dur :" % (g, len(restes)))
        for r in restes[:12]:
            print("   ", r)


if __name__ == "__main__":
    if "--jetons" in sys.argv:
        poser()
    elif "--verifie" in sys.argv:
        verifier()
    else:
        print(__doc__)

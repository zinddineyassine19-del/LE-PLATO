# -*- coding: utf-8 -*-
"""Les trois langues du site : tout ce qui n'est pas le corps des chapitres.

Le corps des chapitres vient du livre lui-même (un fichier par langue). Ici on
tient l'habillage : la barre du haut, le sommaire, la page d'accès, le paiement,
le panneau des chapitres fermés, le pied de page, et les titres des 35 sections.
"""

LANGS = ["fr", "en", "ar"]
DIR = {"fr": "ltr", "en": "ltr", "ar": "rtl"}
NOM = {"fr": "Français", "en": "English", "ar": "العربية"}
COURT = {"fr": "FR", "en": "EN", "ar": "ع"}
HTMLLANG = {"fr": "fr", "en": "en", "ar": "ar"}

# ---------------------------------------------------------------- l'habillage
S = {
    "titre": {
        "fr": "Le Plateau",
        "en": "The Set",
        "ar": "البلاطو",
    },
    "auteur": {"fr": "Yassine Zineddine", "en": "Yassine Zineddine",
               "ar": "ياسين زين الدين"},
    "chercher": {"fr": "Rechercher", "en": "Search", "ar": "بحث"},
    "chercher_aria": {"fr": "Rechercher dans le livre", "en": "Search the book",
                      "ar": "ابحث في الكتاب"},
    "chercher_ph": {
        "fr": "Rechercher un terme, un chapitre, une notion…",
        "en": "Search a term, a chapter, an idea…",
        "ar": "ابحث عن مصطلح أو فصل أو فكرة…",
    },
    "nuit": {"fr": "Nuit", "en": "Night", "ar": "ليل"},
    "jour": {"fr": "Jour", "en": "Day", "ar": "نهار"},
    "theme_aria": {"fr": "Changer de thème", "en": "Switch theme", "ar": "تغيير المظهر"},
    "menu_aria": {"fr": "Ouvrir le sommaire", "en": "Open the contents",
                  "ar": "افتح الفهرس"},
    "langue_aria": {"fr": "Changer de langue", "en": "Change language",
                    "ar": "تغيير اللغة"},
    "sommaire": {"fr": "Sommaire du livre", "en": "Table of contents",
                 "ar": "فهرس الكتاب"},
    "accueil": {"fr": "Accueil", "en": "Home", "ar": "الرئيسية"},
    "chapitre": {"fr": "Chapitre", "en": "Chapter", "ar": "الفصل"},
    "annexe": {"fr": "Annexe", "en": "Appendix", "ar": "ملحق"},
    "annexes": {"fr": "Annexes", "en": "Appendices", "ar": "الملاحق"},
    "retour": {"fr": "Retour", "en": "Back", "ar": "رجوع"},
    "droits": {
        "fr": "© Yassine Zineddine — tous droits réservés",
        "en": "© Yassine Zineddine — all rights reserved",
        "ar": "© ياسين زين الدين — جميع الحقوق محفوظة",
    },
    "livre_complet": {"fr": "Le livre complet", "en": "The complete book",
                      "ar": "الكتاب كاملاً"},
    "tout_page": {"fr": "Tout sur une page", "en": "Everything on one page",
                  "ar": "كل شيء في صفحة واحدة"},
    # --- navigation entre chapitres ---
    "suivant": {"fr": "suivant", "en": "next", "ar": "التالي"},
    "precedent": {"fr": "précédent", "en": "previous", "ar": "السابق"},
    # --- recherche ---
    "naviguer": {"fr": "naviguer", "en": "move", "ar": "تنقّل"},
    "ouvrir": {"fr": "ouvrir", "en": "open", "ar": "فتح"},
    "fermer": {"fr": "fermer", "en": "close", "ar": "إغلاق"},
    "aucun_res": {"fr": "Aucun résultat pour", "en": "No result for",
                  "ar": "لا نتيجة لـ"},
    # --- la loupe ---
    "schema": {"fr": "Schéma", "en": "Diagram", "ar": "رسم"},
    "agrandir": {"fr": "Agrandir le schéma", "en": "Enlarge the diagram",
                 "ar": "تكبير الرسم"},
    "ajuster": {"fr": "ajuster", "en": "fit", "ar": "ملاءمة"},
    "schema_grand": {"fr": "Schéma agrandi", "en": "Enlarged diagram",
                     "ar": "الرسم مكبّراً"},
    # --- la musique d'ambiance ---
    "son_aria": {"fr": "Couper ou remettre la musique d'ambiance",
                 "en": "Mute or unmute the ambient music",
                 "ar": "كتم موسيقى الخلفية أو تشغيلها"},
    "son_on": {"fr": "Musique", "en": "Music", "ar": "موسيقى"},
    "son_off": {"fr": "Silence", "en": "Mute", "ar": "صمت"},
}

# ---------------------------------------------------------------- les parties
PARTIES = [
    {"tag": {"fr": "Partie I", "en": "Part I", "ar": "الجزء الأول"},
     "nom": {"fr": "La caméra", "en": "The camera", "ar": "الكاميرا"},
     "desc": {
         "fr": "Ce que la machine fait de la lumière : le capteur, l'objectif, "
               "l'exposition, le cadre et le mouvement.",
         "en": "What the machine does with light: the sensor, the lens, exposure, "
               "the frame and movement.",
         "ar": "ما تفعله الآلة بالضوء: المستشعر، العدسة، التعريض، الإطار والحركة."}},
    {"tag": {"fr": "Partie II", "en": "Part II", "ar": "الجزء الثاني"},
     "nom": {"fr": "La lumière", "en": "The light", "ar": "الضوء"},
     "desc": {
         "fr": "Les quatre propriétés, la loi de l'inverse du carré, la couleur, "
               "et comment on construit un éclairage qui raconte quelque chose.",
         "en": "The four properties, the inverse square law, colour, and how to "
               "build lighting that tells you something.",
         "ar": "الخصائص الأربع، قانون التربيع العكسي، اللون، وكيف نبني إضاءة "
               "تروي شيئاً."}},
    {"tag": {"fr": "Partie III", "en": "Part III", "ar": "الجزء الثالث"},
     "nom": {"fr": "Dans la machine", "en": "Inside the machine", "ar": "داخل الآلة"},
     "desc": {
         "fr": "L'anatomie technique : capteur, objectif, codec, projecteur, DMX "
               "et le balayage de l'image.",
         "en": "The technical anatomy: sensor, lens, codec, fixture, DMX and how "
               "the image is scanned.",
         "ar": "التشريح التقني: المستشعر، العدسة، الكوديك، الكشّاف، DMX ومسح الصورة."}},
    {"tag": {"fr": "Partie IV", "en": "Part IV", "ar": "الجزء الرابع"},
     "nom": {"fr": "Sur le plateau", "en": "On set", "ar": "في البلاطو"},
     "desc": {
         "fr": "Le geste : mesurer la lumière, filtrer, faire le point, tenir la "
               "caméra, dompter le soleil et éclairer un fond vert.",
         "en": "The craft: metering the light, filtering, pulling focus, holding "
               "the camera, taming the sun and lighting a green screen.",
         "ar": "الممارسة: قياس الضوء، الترشيح، ضبط البؤرة، حمل الكاميرا، ترويض "
               "الشمس وإضاءة الشاشة الخضراء."}},
    {"tag": {"fr": "Partie V", "en": "Part V", "ar": "الجزء الخامس"},
     "nom": {"fr": "Le son", "en": "Sound", "ar": "الصوت"},
     "desc": {
         "fr": "Les bases, et rien de plus : ce que le micro entend, le niveau, "
               "la distance, les gestes de plateau qui sauvent un son — et la "
               "claquette, qui recolle l'image et le son.",
         "en": "The basics, and no more: what the microphone hears, level, "
               "distance, the on-set habits that save a soundtrack — and the "
               "slate, which glues picture and sound back together.",
         "ar": "الأساسيات لا أكثر: ما يلتقطه الميكروفون، المستوى، المسافة، "
               "وعادات البلاطو التي تنقذ الصوت — والكلاكيت التي تلحم الصورة "
               "بالصوت."}},
    {"tag": {"fr": "Partie VI", "en": "Part VI", "ar": "الجزء السادس"},
     "nom": {"fr": "Le montage", "en": "Editing", "ar": "المونتاج"},
     "desc": {
         "fr": "Les bases encore : ranger ses rushes, couper au bon endroit, "
               "sentir le rythme, et exporter sans abîmer le travail.",
         "en": "The basics again: organising the rushes, cutting in the right "
               "place, feeling the pace, and exporting without spoiling the work.",
         "ar": "الأساسيات كذلك: ترتيب المواد، القطع في المكان الصحيح، الإحساس "
               "بالإيقاع، والتصدير دون إفساد العمل."}},
]

ANNEXES_D = [
    {"fr": "Les huit plans de feu réunis dans une seule figure : un clic et le plan "
           "se dessine à l'échelle, avec son image, son matériel et ses pièges.",
     "en": "The eight lighting plots in a single figure: one click and the plot "
           "draws itself to scale, with its image, its kit and its traps.",
     "ar": "مخططات الإضاءة الثمانية في رسم واحد: نقرة واحدة فيُرسم المخطط بمقياسه، "
           "مع صورته وعتاده ومطبّاته."},
    {"fr": "Ce qu'il faut vérifier avant, pendant et après un tournage — plus les "
           "sources techniques du livre.",
     "en": "What to check before, during and after a shoot — plus the book's "
           "technical sources.",
     "ar": "ما يجب التحقق منه قبل التصوير وأثناءه وبعده — مع المصادر التقنية للكتاب."},
]

# ---------------------------------------------------------------- l'accueil
HOME = {
    "eyebrow": {"fr": "Formation audiovisuelle · le manuel",
                "en": "Film school · the manual",
                "ar": "تكوين سمعي بصري · الدليل"},
    # Le nom tient en deux mots : l'article reste blanc, le mot passe en ambre.
    # En arabe l'article ne se détache pas du mot, le premier morceau est vide.
    "t1": {"fr": "Le", "en": "The", "ar": ""},
    "t2": {"fr": "Plateau", "en": "Set", "ar": "البلاطو"},
    "sub": {
        "fr": "Un manuel illustré de <b>prise de vues, de lumière, de son et de "
              "montage</b>. 41 chapitres, 68 schémas dessinés à la main — dont "
              "dix-huit que l'on manipule à la souris —, plus huit plans de feu "
              "prêts à monter, en français avec la terminologie anglaise des plateaux.",
        "en": "An illustrated manual of <b>camera, light, sound and editing</b>. "
              "41 chapters, 68 hand-drawn diagrams — eighteen of them you drive "
              "with the mouse — plus eight ready-to-build lighting plots, with the "
              "working English vocabulary of the set.",
        "ar": "دليل مصوَّر في <b>التصوير والإضاءة والصوت والمونتاج</b>. واحد "
              "وأربعون فصلاً، ثمانية وستون رسماً مرسومة باليد — ثمانية عشر منها "
              "تُحرَّك بالفأرة — وثمانية مخططات إضاءة جاهزة للتركيب، مع المصطلح "
              "الإنجليزي المستعمل في البلاطوهات."},
    "cta1": {"fr": "Commencer le chapitre 1", "en": "Start chapter 1",
             "ar": "ابدأ بالفصل الأول"},
    "cta2": {"fr": "Tout lire sur une page", "en": "Read it all on one page",
             "ar": "اقرأ كل شيء في صفحة واحدة"},
    "pdf": {"fr": "PDF · 121 pages", "en": "PDF · 121 pages", "ar": "PDF · ١٢١ صفحة"},
    "s1": {"fr": "chapitres", "en": "chapters", "ar": "فصلاً"},
    "s2": {"fr": "schémas", "en": "diagrams", "ar": "رسماً"},
    "s3": {"fr": "manipulables", "en": "interactive", "ar": "تفاعلياً"},
    "s4": {"fr": "trois langues", "en": "trilingual", "ar": "ثلاث لغات"},
    "s4v": {"fr": "FR·EN·AR", "en": "FR·EN·AR", "ar": "FR·EN·AR"},
    "defiler": {"fr": "Sommaire", "en": "Contents", "ar": "الفهرس"},
    "sec1": {"fr": "Le livre, partie par partie", "en": "The book, part by part",
             "ar": "الكتاب، جزءاً بجزء"},
    "sec1p": {
        "fr": "Six parties qui se lisent dans l'ordre : la caméra, l'objectif, la "
              "lumière, le plateau — puis le son et le montage, sans lesquels tout "
              "le reste ne sert à rien.",
        "en": "Six parts that read in order: the camera, the lens, the light, the "
              "set — then sound and editing, without which none of the rest is of "
              "any use.",
        "ar": "ستة أجزاء تُقرأ بالترتيب: الكاميرا، ثم العدسة، ثم الضوء، ثم "
              "البلاطو — ثم الصوت والمونتاج، وبدونهما لا ينفع الباقي."},
    "sec2": {"fr": "Annexes", "en": "Appendices", "ar": "الملاحق"},
    "sec3": {"fr": "Lire la suite", "en": "Read the rest", "ar": "اقرأ البقية"},
    "sec3p": {
        "fr": "Quatre chapitres sont ouverts pour que vous jugiez sur pièces. Les "
              "vingt-neuf autres, les deux annexes et le PDF de 117 pages sont dans "
              "le livre complet.",
        "en": "Four chapters are open so you can judge for yourself. The other "
              "twenty-nine, both appendices and the 101-page PDF are in the "
              "complete book.",
        "ar": "أربعة فصول مفتوحة لتحكم بنفسك. أما التسعة والعشرون الباقية "
              "والملحقان وملف PDF من ١١٧ صفحة فهي في الكتاب الكامل."},
}

# ---------------------------------------------------------------- la porte
LOCK = {
    "k": {"fr": "Ce qu'il y a derrière", "en": "What is behind this door",
          "ar": "ما وراء هذا الباب"},
    "t": {"fr": "La suite demande le livre complet",
          "en": "The rest needs the complete book",
          "ar": "البقية تتطلّب الكتاب الكامل"},
    "d": {"fr": "Quarante et un chapitres, cinquante-neuf schémas dessinés à la main "
                "— dix-sept se manipulent à la souris —, les deux annexes et le PDF "
                "de 117 pages.",
          "en": "Forty-one chapters, fifty-nine hand-drawn diagrams — seventeen "
                "of them driven with the mouse — both appendices and the 101-page PDF.",
          "ar": "واحد وأربعون فصلاً، وسبعة وستون رسماً مرسومة باليد — سبعة عشر "
                "منها تُحرَّك بالفأرة — والملحقان وملف PDF من ١١٧ صفحة."},
    "manip": {"fr": " Celui-ci se manipule à la souris.",
              "en": " This one is driven with the mouse.",
              "ar": " وهذا الرسم يُحرَّك بالفأرة."},
    "btn": {"fr": "Obtenir le livre —", "en": "Get the book —", "ar": "احصل على الكتاب —"},
    "f": {"fr": "chapitres restent ouverts, pour juger sur pièces :",
          "en": "chapters stay open, so you can judge for yourself:",
          "ar": "فصول تبقى مفتوحة لتحكم بنفسك:"},
    "combien": {"fr": "Quatre", "en": "Four", "ar": "أربعة"},
}

# ---------------------------------------------------------------- pas traduit
TODO = {
    "k": {"fr": "Pas encore traduit", "en": "Not translated yet",
          "ar": "لم يُترجَم بعد"},
    "t": {"fr": "Ce chapitre n'existe pas encore dans cette langue",
          "en": "This chapter does not exist in this language yet",
          "ar": "هذا الفصل غير متوفر بعد بهذه اللغة"},
    "d": {"fr": "Le livre est écrit en français et la traduction avance chapitre par "
                "chapitre. En attendant, celui-ci se lit dans les langues déjà prêtes.",
          "en": "The book was written in French and the translation advances chapter "
                "by chapter. In the meantime, this one can be read in the languages "
                "already finished.",
          "ar": "كُتب الكتاب بالفرنسية والترجمة تتقدّم فصلاً بفصل. في انتظار ذلك، "
                "يمكن قراءة هذا الفصل باللغات الجاهزة."},
    "lire": {"fr": "Lire ce chapitre en", "en": "Read this chapter in",
             "ar": "اقرأ هذا الفصل بـ"},
}

# ---------------------------------------------------------------- la page d'accès
ACCES = {
    "eye": {"fr": "Le livre complet", "en": "The complete book", "ar": "الكتاب الكامل"},
    "sub": {"fr": "Quarante et un chapitres de prise de vues et d'éclairage, écrits et "
                  "dessinés à la main, en français avec la terminologie anglaise des "
                  "plateaux.",
            "en": "Forty-one chapters of camera and lighting, written and drawn by "
                  "hand, with the working English vocabulary of the set.",
            "ar": "واحد وأربعون فصلاً في التصوير والإضاءة، مكتوبة ومرسومة باليد، "
                  "مع المصطلح الإنجليزي المستعمل في البلاطوهات."},
    "fois": {"fr": "une fois, pour toujours", "en": "once, for good", "ar": "مرة واحدة، إلى الأبد"},
    "buy": {"fr": "Payer et recevoir le livre", "en": "Pay and get the book",
            "ar": "ادفع واستلم الكتاب"},
    "nocard": {"fr": "Par carte sur la page sécurisée du prestataire, ou par virement, "
                     "espèces ou paiement mobile. <b>Aucun numéro de carte ne passe par "
                     "ce site.</b>",
               "en": "By card on the provider's secure page, or by bank transfer, cash "
                     "or mobile payment. <b>No card number ever passes through this "
                     "site.</b>",
               "ar": "بالبطاقة على صفحة المزوّد الآمنة، أو بتحويل بنكي أو نقداً أو "
                     "بالدفع عبر الهاتف. <b>لا يمرّ أي رقم بطاقة عبر هذا الموقع.</b>"},
    "recevez": {"fr": "Ce que vous recevez", "en": "What you get", "ar": "ما ستحصل عليه"},
    "i1t": {"fr": "Le site complet", "en": "The complete site", "ar": "الموقع كاملاً"},
    "i1d": {"fr": "Les 41 chapitres et les 2 annexes, à garder sur votre ordinateur. Il "
                  "fonctionne hors ligne, sans compte et sans mot de passe.",
            "en": "All 41 chapters and both appendices, yours to keep. It works "
                  "offline, with no account and no password.",
            "ar": "الفصول الواحد والأربعون والملحقان، تحتفظ بها على حاسوبك. يعمل "
                  "دون اتصال، بلا حساب وبلا كلمة سر."},
    "i2t": {"fr": "67 schémas dessinés à la main", "en": "67 hand-drawn diagrams",
            "ar": "٥٩ رسماً مرسومة باليد"},
    "i2d": {"fr": "Dont dix-huit que l'on manipule à la souris : le triangle "
                  "d'exposition, la profondeur de champ, le plateau à trois "
                  "projecteurs, le posemètre, la mise au point, le soleil heure par "
                  "heure…",
            "en": "Seventeen of them driven with the mouse: the exposure triangle, "
                  "depth of field, the three-light set, the meter, focus pulling, the "
                  "sun hour by hour…",
            "ar": "سبعة عشر منها تُحرَّك بالفأرة: مثلث التعريض، عمق الميدان، البلاطو "
                  "بثلاثة كشّافات، مقياس الضوء، ضبط البؤرة، الشمس ساعة بساعة…"},
    "i3t": {"fr": "Le PDF, 117 pages", "en": "The PDF, 117 pages", "ar": "ملف PDF، ١١٧ صفحة"},
    "i3d": {"fr": "Mis en pages pour être imprimé et relié, ou lu sur une tablette au "
                  "tournage.",
            "en": "Typeset to be printed and bound, or read on a tablet on set.",
            "ar": "مُنسَّق للطباعة والتجليد، أو للقراءة على لوح إلكتروني في التصوير."},
    "i4t": {"fr": "Huit plans de feu prêts à monter", "en": "Eight ready-to-build plots",
            "ar": "ثمانية مخططات إضاءة جاهزة"},
    "i4d": {"fr": "Matériel, ordre de montage, pièges, et l'image obtenue calculée "
                  "depuis les positions réelles des projecteurs.",
            "en": "Kit, rigging order, traps, and the resulting image computed from "
                  "the real positions of the lights.",
            "ar": "العتاد، ترتيب التركيب، المطبّات، والصورة الناتجة محسوبة من "
                  "المواقع الحقيقية للكشّافات."},
    "avant": {"fr": "Avant de payer, lisez quatre chapitres entiers",
              "en": "Before paying, read four full chapters",
              "ar": "قبل أن تدفع، اقرأ أربعة فصول كاملة"},
    "avantp": {"fr": "Ils sont ouverts, avec leurs schémas manipulables — c'est "
                     "exactement le travail que contiennent les vingt-neuf autres.",
               "en": "They are open, with their interactive diagrams — this is exactly "
                     "the work the other twenty-nine contain.",
               "ar": "إنها مفتوحة برسومها التفاعلية — وهذا بالضبط ما تحتويه الفصول "
                     "التسعة والعشرون الأخرى."},
    "payer": {"fr": "Comment payer", "en": "How to pay", "ar": "كيف تدفع"},
    "payerp": {"fr": "Deux portes. La première quand votre passerelle sera ouverte, la "
                     "seconde marche dès aujourd'hui.",
               "en": "Two doors. The first once the gateway is open, the second works "
                     "today.",
               "ar": "بابان. الأول حين تُفتح بوابة الدفع، والثاني يعمل منذ اليوم."},
    "p1k": {"fr": "1 · Par carte bancaire", "en": "1 · By bank card", "ar": "١ · بالبطاقة البنكية"},
    "p1t": {"fr": "Sur la page sécurisée de la banque", "en": "On the bank's secure page",
            "ar": "على صفحة البنك الآمنة"},
    "p1d": {"fr": "Vous cliquez, vous arrivez sur la page du prestataire de paiement, "
                  "vous entrez votre carte là-bas. <b>Aucun numéro de carte ne passe "
                  "par ce site</b> — ce site n'a ni serveur ni base de données, il n'a "
                  "rien où mettre un numéro de carte, et il n'en veut pas.",
            "en": "You click, you land on the payment provider's page, you enter your "
                  "card there. <b>No card number passes through this site</b> — it has "
                  "no server and no database, nowhere to put a card number, and it "
                  "wants none.",
            "ar": "تنقر فتصل إلى صفحة مزوّد الدفع وتُدخل بطاقتك هناك. <b>لا يمرّ أي "
                  "رقم بطاقة عبر هذا الموقع</b> — فليس له خادم ولا قاعدة بيانات، ولا "
                  "مكان يضع فيه رقم بطاقة، ولا يريده."},
    "p1b": {"fr": "Payer %s par carte", "en": "Pay %s by card", "ar": "ادفع %s بالبطاقة"},
    "p2k": {"fr": "2 · Virement, espèces ou paiement mobile",
            "en": "2 · Transfer, cash or mobile payment",
            "ar": "٢ · تحويل أو نقداً أو دفع عبر الهاتف"},
    "p2t": {"fr": "En trois gestes", "en": "In three steps", "ar": "في ثلاث خطوات"},
    "e1": {"fr": "Envoyez %s", "en": "Send %s", "ar": "أرسل %s"},
    "e1s": {"fr": "par l'un de ces trois chemins :", "en": "by one of these three routes:",
            "ar": "بإحدى هذه الطرق الثلاث:"},
    "titulaire": {"fr": "Titulaire", "en": "Account holder", "ar": "صاحب الحساب"},
    "banque": {"fr": "Banque", "en": "Bank", "ar": "البنك"},
    "rib": {"fr": "RIB", "en": "IBAN / RIB", "ar": "الحساب البنكي"},
    "copier": {"fr": "copier", "en": "copy", "ar": "نسخ"},
    "copie": {"fr": "copié", "en": "copied", "ar": "تم النسخ"},
    "esp": {"fr": "<b>En espèces</b> — dans n'importe quelle agence Wafacash, "
                  "Cash&nbsp;Plus ou Barid&nbsp;Cash, au nom de <b>%s</b>. Gardez le "
                  "reçu : son numéro me sert de référence.",
            "en": "<b>In cash</b> — at any Wafacash, Cash&nbsp;Plus or "
                  "Barid&nbsp;Cash counter, to <b>%s</b>. Keep the receipt: its number "
                  "is my reference.",
            "ar": "<b>نقداً</b> — في أي وكالة وفاكاش أو كاش بلوس أو بريد كاش، باسم "
                  "<b>%s</b>. احتفظ بالوصل: رقمه هو مرجعي."},
    "wal": {"fr": "<b>Depuis votre m-wallet</b> — au <b>%s</b>. Un m-wallet marocain a "
                  "son propre IBAN et transfère vers un compte bancaire.",
            "en": "<b>From your m-wallet</b> — to <b>%s</b>. A Moroccan m-wallet has "
                  "its own IBAN and transfers to a bank account.",
            "ar": "<b>من محفظتك الإلكترونية</b> — إلى <b>%s</b>. للمحفظة المغربية "
                  "رقم حساب خاص بها وتحوّل إلى حساب بنكي."},
    "e2": {"fr": "Dites-le-moi.", "en": "Tell me.", "ar": "أخبرني."},
    "e2s": {"fr": "Écrivez votre nom et la référence du virement ou du reçu, puis "
                  "cliquez : WhatsApp s'ouvre avec le message déjà écrit.",
            "en": "Write your name and the transfer or receipt reference, then click: "
                  "WhatsApp opens with the message already written.",
            "ar": "اكتب اسمك ومرجع التحويل أو الوصل ثم انقر: يفتح واتساب والرسالة "
                  "مكتوبة سلفاً."},
    "nom_l": {"fr": "Votre nom", "en": "Your name", "ar": "اسمك"},
    "nom_p": {"fr": "Prénom et nom", "en": "First and last name", "ar": "الاسم والنسب"},
    "ref_l": {"fr": "Référence du virement ou du reçu", "en": "Transfer or receipt reference",
              "ar": "مرجع التحويل أو الوصل"},
    "ref_p": {"fr": "le numéro sur votre reçu", "en": "the number on your receipt",
              "ar": "الرقم المدوَّن على وصلك"},
    "waб": {"fr": "J'ai payé — envoyez-moi le livre", "en": "I have paid — send me the book",
            "ar": "لقد دفعت — أرسل لي الكتاب"},
    "mailb": {"fr": "ou par courriel", "en": "or by e-mail", "ar": "أو بالبريد الإلكتروني"},
    "warn": {"fr": "Ne mettez jamais votre numéro de carte dans ce formulaire, ni dans "
                   "un message. Personne n'a besoin de le connaître — ni moi, ni "
                   "quiconque.",
             "en": "Never put your card number in this form, or in a message. Nobody "
                   "needs it — not me, not anyone.",
             "ar": "لا تضع أبداً رقم بطاقتك في هذه الاستمارة ولا في رسالة. لا أحد "
                   "يحتاجه — لا أنا ولا غيري."},
    "e3": {"fr": "Je vérifie et je vous envoie le livre.",
           "en": "I check and send you the book.",
           "ar": "أتحقّق ثم أرسل لك الكتاب."},
    "e3s": {"fr": "Je regarde mon compte, et vous recevez le lien de téléchargement. "
                  "Comptez quelques heures — c'est le seul inconvénient de cette "
                  "porte-là.",
            "en": "I look at my account, and you get the download link. Allow a few "
                  "hours — that is the only drawback of this door.",
            "ar": "أنظر في حسابي فتصلك رابط التحميل. احسب بضع ساعات — هذا هو العيب "
                  "الوحيد لهذا الباب."},
    "msg": {"fr": "Bonjour Yassine, je viens de payer %s pour La Caméra et la Lumière.",
            "en": "Hello Yassine, I have just paid %s for The Camera and the Light.",
            "ar": "مرحباً ياسين، لقد دفعت للتو %s مقابل كتاب الكاميرا والضوء."},
    "msg_nom": {"fr": "Nom", "en": "Name", "ar": "الاسم"},
    "msg_ref": {"fr": "Référence du paiement", "en": "Payment reference", "ar": "مرجع الدفع"},
    "msg_fin": {"fr": "Pouvez-vous m'envoyer le lien du livre ? Merci.",
                "en": "Could you send me the link to the book? Thank you.",
                "ar": "هل يمكنك أن ترسل لي رابط الكتاب؟ شكراً."},
    "honn": {"fr": "Un mot honnête.", "en": "An honest word.", "ar": "كلمة صادقة."},
    "honnp": {"fr": "Ce que vous achetez, ce sont des fichiers : une fois téléchargés, "
                    "ils sont à vous et rien ne les verrouille. Je préfère vous faire "
                    "confiance plutôt que vous enfermer. Si le livre vous sert, "
                    "dites-le à quelqu'un de votre promotion.",
              "en": "What you buy are files: once downloaded they are yours and nothing "
                    "locks them. I would rather trust you than cage you. If the book "
                    "serves you, tell someone in your year.",
              "ar": "ما تشتريه ملفات: بمجرد تحميلها تصبح لك ولا شيء يقفلها. أفضّل أن "
                    "أثق بك على أن أحبسك. إن نفعك الكتاب فأخبر به زميلاً من دفعتك."},
    "quest": {"fr": "Une question avant d'acheter ? Écrivez-moi, je réponds.",
              "en": "A question before buying? Write to me, I answer.",
              "ar": "سؤال قبل الشراء؟ راسلني، أنا أجيب."},
    "retour_site": {"fr": "Retour au site", "en": "Back to the site", "ar": "العودة إلى الموقع"},
}


# ---------------------------------------------------------------- restes
S["titre_page"] = {"fr": "Le Plateau — Yassine Zineddine",
                   "en": "The Set — Yassine Zineddine",
                   "ar": "البلاطو — ياسين زين الدين"}
S["edition"] = {"fr": "Le Plateau · édition française",
                "en": "The Set · English edition",
                "ar": "البلاطو · النسخة العربية"}
ACCES["titre_page"] = {"fr": "Obtenir le livre — La Caméra et la Lumière",
                       "en": "Get the book — The Camera and the Light",
                       "ar": "احصل على الكتاب — الكاميرا والضوء"}
HOME["bande_n"] = {"fr": "Avec leurs schémas manipulables : c'est exactement le "
                         "travail que contiennent les vingt-neuf autres chapitres.",
                   "en": "With their interactive diagrams: this is exactly the work "
                         "the other twenty-nine chapters contain.",
                   "ar": "برسومها التفاعلية: وهذا بالضبط ما تحتويه الفصول التسعة "
                         "والعشرون الأخرى."}
ACCES["esp_t"] = {"fr": "En espèces", "en": "In cash", "ar": "نقداً"}
ACCES["esp_d"] = {"fr": "— dans n'importe quelle agence Wafacash, Cash Plus ou "
                        "Barid Cash, au nom de", "en": "— at any Wafacash, Cash Plus "
                        "or Barid Cash counter, to", "ar": "— في أي وكالة وفاكاش أو "
                        "كاش بلوس أو بريد كاش، باسم"}
ACCES["esp_f"] = {"fr": ". Gardez le reçu : son numéro me sert de référence.",
                  "en": ". Keep the receipt: its number is my reference.",
                  "ar": ". احتفظ بالوصل: رقمه هو مرجعي."}
ACCES["wal_t"] = {"fr": "Depuis votre m-wallet", "en": "From your m-wallet",
                  "ar": "من محفظتك الإلكترونية"}
ACCES["wal_d"] = {"fr": "— au", "en": "— to", "ar": "— إلى"}
ACCES["wal_f"] = {"fr": ". Un m-wallet marocain a son propre IBAN et transfère vers "
                        "un compte bancaire.",
                  "en": ". A Moroccan m-wallet has its own IBAN and transfers to a "
                        "bank account.",
                  "ar": ". للمحفظة المغربية رقم حساب خاص بها وتحوّل إلى حساب بنكي."}
ACCES["p1b0"] = {"fr": "Payer", "en": "Pay", "ar": "ادفع"}
ACCES["payer_carte"] = {"fr": "par carte", "en": "by card", "ar": "بالبطاقة"}
ACCES["envoyez"] = {"fr": "Envoyez", "en": "Send", "ar": "أرسل"}
ACCES["obtenir"] = {"fr": "Obtenir le livre —", "en": "Get the book —",
                    "ar": "احصل على الكتاب —"}

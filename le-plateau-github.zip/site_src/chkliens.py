#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tous les liens du site mènent quelque part : fichiers et ancres."""
import os, re, sys, collections
import os as _os
ICI = _os.path.dirname(_os.path.abspath(__file__))
RACINE = _os.path.dirname(ICI)            # le dossier du dépôt


R = _os.path.join(RACINE, "site")
casses = collections.defaultdict(list)
pages = []
for d, _s, fs in os.walk(R):
    for f in fs:
        if f.endswith(".html"):
            pages.append(os.path.join(d, f))

for p in sorted(pages):
    s = open(p, encoding="utf-8").read()
    ids = set(re.findall(r'\bid="([^"]+)"', s))
    base = os.path.dirname(p)
    for h in set(re.findall(r'\bhref="([^"]+)"', s)):
        if h.startswith(("http", "mailto:", "data:", "#")) or h == "":
            if h.startswith("#") and len(h) > 1 and h[1:] not in ids:
                casses["ancre morte"].append(os.path.relpath(p, R) + " → " + h)
            continue
        cible, _, anc = h.partition("#")
        q = os.path.normpath(os.path.join(base, cible))
        if not os.path.exists(q):
            casses["fichier absent"].append(os.path.relpath(p, R) + " → " + h)
        elif anc:
            t = open(q, encoding="utf-8").read()
            if anc not in set(re.findall(r'\bid="([^"]+)"', t)):
                casses["ancre morte"].append(os.path.relpath(p, R) + " → " + h)

for k, v in casses.items():
    print("%-16s %d" % (k, len(v)))
    for x in sorted(set(v))[:10]:
        print("   ", x)
print("pages vérifiées :", len(pages), "· liens cassés :", sum(len(v) for v in casses.values()))
sys.exit(1 if casses else 0)

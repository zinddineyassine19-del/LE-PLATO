/* ==========================================================================
   Le son du site
   --------------------------------------------------------------------------
   Deux choses, et elles ne se mélangent pas.

   LE FOND — un morceau, en boucle, très bas : vingt décibels sous son propre
   niveau. Assez bas pour qu'on l'oublie au bout d'une minute, ce qui est
   exactement ce qu'on demande à une musique de fond. Il entre en fondu sur
   huit secondes — personne ne doit sursauter.

   LE DÉCLENCHEUR — le bruit d'un appareil photo, fabriqué à chaque clic. Du
   bruit blanc filtré pour la mécanique, une impulsion pour l'éclair, et le
   sifflement du condensateur derrière. Sur un bouton ou un lien :
   l'obturateur complet. Ailleurs : le petit claquement sec d'un obturateur
   électronique. L'écart entre les deux rideaux change à chaque fois — deux
   clics ne sonnent jamais exactement pareil.

   Une seule machine pour toute la page, même quand trois langues cohabitent
   dans un seul document : le garde-fou ci-dessous y veille.
   ========================================================================== */
(function () {
  'use strict';
  if (window.__clelAmbiance) return;
  window.__clelAmbiance = true;

  var CLE = 'clel-son';
  var etat = null;                 /* null = jamais choisi, '1' ou '0' sinon */
  try { etat = localStorage.getItem(CLE); } catch (e) {}

  var VOL = 0.10;                  /* le fond : −20 dB sous le morceau */
  var fond = null, fondu = null, allume = false;
  var ctx = null, clics = null, sec = null, mouille = null, dernier = 0;

  /* ====================================================================== */
  /*  LE FOND                                                               */
  /* ====================================================================== */
  function faireFond() {
    if (fond !== null || !window.CLEL_AMBIANCE) return fond;
    fond = new Audio();
    fond.loop = true;
    fond.preload = 'auto';
    fond.volume = 0;
    /* Si le fichier manque, on ne casse rien : il reste le déclencheur. */
    fond.addEventListener('error', function () { fond = false; });
    fond.src = window.CLEL_AMBIANCE;
    return fond;
  }

  function versVolume(cible, ms, puisArreter) {
    clearInterval(fondu);
    if (!fond) return;
    var de = fond.volume, t0 = Date.now();
    fondu = setInterval(function () {
      if (!fond) { clearInterval(fondu); return; }
      var k = Math.min(1, (Date.now() - t0) / ms);
      try { fond.volume = Math.max(0, Math.min(1, de + (cible - de) * k)); } catch (e) {}
      if (k >= 1) {
        clearInterval(fondu);
        if (puisArreter) { try { fond.pause(); } catch (e) {} }
      }
    }, 60);
  }

  /* ====================================================================== */
  /*  LE DÉCLENCHEUR                                                        */
  /* ====================================================================== */

  /* Une réverbération ne se télécharge pas : on la calcule. Du bruit qui
     s'éteint en exponentielle, c'est déjà une pièce. */
  function salle() {
    var d = 1.6, n = Math.floor(ctx.sampleRate * d);
    var buf = ctx.createBuffer(2, n, ctx.sampleRate);
    for (var c = 0; c < 2; c++) {
      var ch = buf.getChannelData(c);
      for (var i = 0; i < n; i++) {
        var t = i / n;
        ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, 3.2) * (t < 0.002 ? t / 0.002 : 1);
      }
    }
    var cv = ctx.createConvolver();
    cv.buffer = buf;
    return cv;
  }

  function brancher(src, dry, wet) {
    var a = ctx.createGain(), b = ctx.createGain();
    a.gain.value = dry; b.gain.value = wet;
    src.connect(a); a.connect(sec);
    src.connect(b); b.connect(mouille);
  }

  var BRUIT = null;
  function bruit() {
    if (BRUIT) return BRUIT;
    var n = Math.floor(ctx.sampleRate * 0.9);
    BRUIT = ctx.createBuffer(1, n, ctx.sampleRate);
    var d = BRUIT.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return BRUIT;
  }

  /* une bouffée de bruit filtré : c'est avec ça qu'on fait de la mécanique */
  function souffle(t, dur, type, f, q, vol) {
    var src = ctx.createBufferSource();
    src.buffer = bruit();
    var bp = ctx.createBiquadFilter();
    bp.type = type; bp.frequency.value = f; bp.Q.value = q;
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.0015);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(bp); bp.connect(g); g.connect(clics);
    src.start(t, Math.random() * 0.4); src.stop(t + dur + 0.02);
  }

  /* le corps de l'appareil : une masse qui bouge, donc du grave très court */
  function corps(t, f, dur, vol) {
    var o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(f * 1.6, t);
    o.frequency.exponentialRampToValueAtTime(f, t + dur * 0.5);
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(clics);
    o.start(t); o.stop(t + dur + 0.02);
  }

  function obturateur(t) {
    /* premier rideau : le miroir claque, le grave part avec lui */
    corps(t, 96, 0.075, 0.30);
    souffle(t, 0.022, 'bandpass', 2300, 1.1, 0.34);
    souffle(t + 0.002, 0.010, 'highpass', 5200, 0.7, 0.16);
    /* second rideau, un souffle plus tard : c'est lui qui donne la « pose » */
    var d = 0.068 + Math.random() * 0.012;
    souffle(t + d, 0.026, 'bandpass', 1850, 1.0, 0.26);
    corps(t + d, 78, 0.055, 0.17);
  }

  function flash(t) {
    /* l'éclair : une impulsion, rien de plus — très court et très clair */
    souffle(t, 0.016, 'highpass', 3400, 0.6, 0.30);
    souffle(t, 0.045, 'bandpass', 1200, 0.9, 0.10);
    /* la recharge : le sifflement qui monte derrière, et qu'on oublie */
    var o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(4600, t + 0.05);
    o.frequency.exponentialRampToValueAtTime(8200, t + 0.62);
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.017, t + 0.18);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.66);
    o.connect(g); g.connect(clics);
    o.start(t + 0.05); o.stop(t + 0.7);
  }

  function moteurClics() {
    if (ctx) return true;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();
    var rev = salle();
    sec = ctx.createGain(); sec.gain.value = 1; sec.connect(ctx.destination);
    mouille = ctx.createGain(); mouille.gain.value = 1;
    mouille.connect(rev); rev.connect(ctx.destination);
    clics = ctx.createGain(); clics.gain.value = 0.30;
    brancher(clics, 1, 0.16);
    return true;
  }

  function declic(plein) {
    if (!allume || !moteurClics()) return;
    if (ctx.state === 'suspended') ctx.resume();
    var now = Date.now();
    if (now - dernier < 110) return;        /* un double-clic ne double pas le son */
    dernier = now;
    var t = ctx.currentTime + 0.006;
    if (plein) { obturateur(t); flash(t + 0.014); }
    else {
      /* obturateur électronique : un seul petit claquement, sans mécanique */
      souffle(t, 0.012, 'bandpass', 2600, 1.4, 0.13);
      corps(t, 150, 0.030, 0.07);
    }
  }

  /* ====================================================================== */
  /*  L'INTERRUPTEUR                                                        */
  /* ====================================================================== */
  function demarrer() {
    if (allume) return;
    allume = true;
    moteurClics();
    if (ctx && ctx.state === 'suspended') ctx.resume();
    if (faireFond()) {
      var p = fond.play();
      if (p && p.catch) p.catch(function () {});
      versVolume(VOL, 8000);                /* la montée dure huit secondes */
    }
    marquer();
  }

  function arreter() {
    if (!allume) { marquer(); return; }
    allume = false;
    versVolume(0, 900, true);
    if (ctx) setTimeout(function () { if (!allume && ctx) ctx.suspend(); }, 1400);
    marquer();
  }

  function marquer() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-son]'), function (x) {
      x.classList.toggle('on', allume);
      x.setAttribute('aria-pressed', allume ? 'true' : 'false');
      var l = x.querySelector('.lbl');
      if (l) l.textContent = x.getAttribute(allume ? 'data-off' : 'data-on') || l.textContent;
    });
  }

  var ACTIFS = 'a,button,summary,label,input,select,[role="button"],[data-go],' +
               '.ix-b,.pcard,.acard,.langsel a,.side a,.pager a';

  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-son]');
    if (b) {
      e.preventDefault();
      if (allume) {
        arreter(); etat = '0';
      } else {
        demarrer(); etat = '1';
        declic(true);                   /* on entend tout de suite ce qu'on allume */
      }
      try { localStorage.setItem(CLE, etat); } catch (err) {}
      return;
    }
    /* Sélectionner du texte n'est pas cliquer : on ne sonne pas là-dessus. */
    try { if (String(window.getSelection()).length > 1) return; } catch (err) {}
    declic(!!(e.target.closest && e.target.closest(ACTIFS)));
  });

  /* Un navigateur refuse le son tant que personne n'a rien fait : on attend
     donc le premier geste. Sur l'accueil on part tout seul ; ailleurs, on ne
     repart que si le lecteur l'avait demandé. */
  function accueil() { return !!document.querySelector('.hero'); }

  ['pointerdown', 'keydown', 'wheel', 'touchstart'].forEach(function (ev) {
    window.addEventListener(ev, function once() {
      ['pointerdown', 'keydown', 'wheel', 'touchstart'].forEach(function (e2) {
        window.removeEventListener(e2, once);
      });
      if (etat === '0') return;
      if (etat === '1' || accueil()) demarrer();
    }, { passive: true });
  });

  /* Onglet caché : on se tait. Rien de plus agaçant qu'un son qui sort d'un
     onglet qu'on ne regarde plus. */
  document.addEventListener('visibilitychange', function () {
    if (!allume) return;
    if (document.hidden) {
      if (fond) { try { fond.pause(); } catch (e) {} }
      if (ctx) ctx.suspend();
    } else {
      if (fond) { var p = fond.play(); if (p && p.catch) p.catch(function () {}); }
      if (ctx && ctx.state === 'suspended') ctx.resume();
    }
  });

  window.addEventListener('beforeprint', function () { if (allume) arreter(); });
  marquer();
})();

/* ==========================================================================
   La lumière suit la main — moteur
   --------------------------------------------------------------------------
   Une seule boucle d'animation pour toute la page. Elle n'écrit que des
   variables CSS, et uniquement quand quelque chose a bougé ; dès que tout
   est au repos elle s'arrête d'elle-même.
   ========================================================================== */
(function () {
  'use strict';

  var root = document.documentElement;
  var calm = matchMedia('(prefers-reduced-motion: reduce)');
  var fine = matchMedia('(hover:hover) and (pointer:fine)');

  /* ---- le fond remonte sur la racine : les calques se glissent dessous ---- */
  function syncBg() {
    document.body.style.background = '';
    var bg = getComputedStyle(document.body).backgroundColor;
    if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
      root.style.background = bg;
      document.body.style.background = 'transparent';
    }
  }
  syncBg();
  new MutationObserver(syncBg).observe(root, { attributes: true, attributeFilter: ['data-theme'] });
  try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', syncBg); } catch (e) {}

  /* ---- les calques ---- */
  var stage = document.createElement('div');
  stage.className = 'fx-stage';
  stage.setAttribute('aria-hidden', 'true');
  var rich = document.body.classList.contains('home') ||
             !!document.querySelector('.hero');
  if (rich) root.classList.add('fx-rich');
  /* dans le fichier trilingue, seule la langue affichée compte */
  function laBooksec() {
    return document.querySelector('.L:not([hidden]) .booksec')
        || document.querySelector('.booksec');
  }
  var book = laBooksec();
  var html = book ? '<div class="fx-ground"></div>' : '';
  html += '<div class="fx-key"></div><div class="fx-fill"></div>';
  if (rich) html += '<div class="fx-beam"></div>';
  if (!calm.matches) html += '<div class="fx-grain"></div>';
  stage.innerHTML = html;
  document.body.insertBefore(stage, document.body.firstChild);
  root.classList.add('fx-on');

  /* ======================================================================
     L'état : où est la souris, où en est le scroll
     ====================================================================== */
  var W = innerWidth, H = innerHeight;
  var mx = 0.5, my = 0.34;          /* cible, en fraction d'écran */
  var cx = 0.5, cy = 0.34;          /* position lissée */
  var lum = 0;                      /* présence du curseur */
  var lumT = 0;
  var running = false, frame = 0;

  function wake() {
    if (running) return;
    running = true;
    frame = requestAnimationFrame(tick);
  }

  function setVar(n, v) { root.style.setProperty(n, v); }

  /* ---- le héros : progression du scroll dans le premier écran ---- */
  var hero = document.querySelector('.hero');
  var hp = 0, hpShown = -1, gShown = -1;
  function heroProgress() {
    if (!hero) return 0;
    var r = hero.getBoundingClientRect();
    var span = r.height || 1;
    return Math.max(0, Math.min(1, -r.top / span));
  }

  /* ======================================================================
     La boucle
     ====================================================================== */
  function tick() {
    frame = 0;
    var moved = false;

    /* lissage : la lumière n'est jamais nerveuse */
    var k = calm.matches ? 1 : 0.085;
    var dx = mx - cx, dy = my - cy, dl = lumT - lum;
    if (Math.abs(dx) > 0.0004 || Math.abs(dy) > 0.0004) {
      cx += dx * k; cy += dy * k; moved = true;
    }
    if (Math.abs(dl) > 0.004) { lum += dl * 0.07; moved = true; }

    if (moved) {
      var px = (cx - 0.5) * W, py = (cy - 0.5) * H;
      setVar('--kx', px.toFixed(1) + 'px');
      setVar('--ky', py.toFixed(1) + 'px');
      /* l'appoint répond à l'opposé, mais de moins loin : c'est un appoint */
      setVar('--fx', (-px * 0.62).toFixed(1) + 'px');
      setVar('--fy', (-py * 0.34 + H * 0.12).toFixed(1) + 'px');
      setVar('--bx', (px * 0.22).toFixed(1) + 'px');
      setVar('--lum', lum.toFixed(3));
      setVar('--pmx', (cx * 2 - 1).toFixed(3));
      setVar('--pmy', (cy * 2 - 1).toFixed(3));
    }

    if (hero) {
      var v = heroProgress();
      if (Math.abs(v - hpShown) > 0.002) {
        hp = hpShown = v;
        hero.style.setProperty('--hp', v.toFixed(3));
        moved = true;
      }
    }

    book = laBooksec();
    if (book && book.offsetParent !== null) {
      /* Le papier doit être entièrement levé AVANT que la première ligne du
         livre n'apparaisse : on l'allume un écran plus tôt, sinon on lirait
         du texte sombre sur un fond sombre le temps du fondu. */
      var top = book.getBoundingClientRect().top;
      var g = Math.max(0, Math.min(1, (H * 2 - top) / (H * 0.7)));
      if (Math.abs(g - gShown) > 0.004) {
        gShown = g;
        setVar('--inbook', g.toFixed(3));
        moved = true;
      }
    } else if (gShown !== 0) {
      gShown = 0; setVar('--inbook', '0'); moved = true;
    }

    if (moved) frame = requestAnimationFrame(tick);
    else running = false;
  }

  /* ======================================================================
     Les entrées
     ====================================================================== */
  addEventListener('resize', function () {
    W = innerWidth; H = innerHeight; hpShown = -1; wake();
  }, { passive: true });

  addEventListener('scroll', function () { wake(); }, { passive: true });

  if (fine.matches && !calm.matches) {
    addEventListener('pointermove', function (e) {
      if (e.pointerType !== 'mouse') return;
      mx = e.clientX / W; my = e.clientY / H; lumT = 1; wake();
    }, { passive: true });
    addEventListener('pointerleave', function () { lumT = 0; wake(); }, { passive: true });
    document.addEventListener('mouseleave', function () { lumT = 0; wake(); });
  }
  wake();

  /* ======================================================================
     Le titre se lève ligne par ligne
     ====================================================================== */
  (function () {
    if (calm.matches) return;
    var h = document.querySelector('.htitle');
    if (!h) return;
    var lines = [];
    /* la structure est « texte + <span class="l2">texte </span> » */
    Array.prototype.slice.call(h.childNodes).forEach(function (n) {
      if (n.nodeType === 3) {
        if (!n.textContent.trim()) return;
        lines.push({ node: n, text: n.textContent, cls: '' });
      } else if (n.nodeType === 1) {
        lines.push({ node: n, text: n.textContent, cls: n.className });
      }
    });
    if (!lines.length) return;
    var out = '';
    lines.forEach(function (l, i) {
      out += '<span class="fx-ln ' + l.cls + '" style="--d:' + (80 + i * 120) + 'ms">' +
             '<i>' + l.text.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</i></span>';
    });
    h.innerHTML = out;
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        h.querySelectorAll('.fx-ln').forEach(function (s) { s.classList.add('seen'); });
      });
    });
  })();

  /* ======================================================================
     Tout ce qui entre dans le cadre se pose
     ====================================================================== */
  (function () {
    if (calm.matches || !('IntersectionObserver' in window)) return;
    var sel = '.sec-h, .sec-p, .pcard, .acard, .hstat > div, .tocgrid > *, ' +
              '.homefoot .wrap > *, .bookcard, .cta-row';
    var els = Array.prototype.slice.call(document.querySelectorAll(sel));
    if (!els.length) return;

    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        e.target.classList.add('seen');
        io.unobserve(e.target);
      });
    }, { rootMargin: '0px 0px -7% 0px', threshold: 0.1 });

    /* le décalage se compte entre voisins, pas sur toute la page :
       une carte au bas du document ne doit pas attendre deux secondes */
    var last = null, n = 0;
    els.forEach(function (el) {
      if (el.parentElement !== last) { last = el.parentElement; n = 0; }
      el.classList.add('fx-up');
      el.style.setProperty('--d', Math.min(n * 70, 420) + 'ms');
      n++;
      io.observe(el);
    });
  })();

  /* ======================================================================
     Les cartes s'inclinent sous le curseur
     ====================================================================== */
  (function () {
    if (calm.matches || !fine.matches) return;
    var cards = document.querySelectorAll('.pcard, .acard, .bookcard');
    if (!cards.length) return;

    Array.prototype.forEach.call(cards, function (c) {
      c.classList.add('fx-tilt');
      var raf = 0, nx = 0, ny = 0, gx = 50, gy = 50;

      function paint() {
        raf = 0;
        c.style.setProperty('--tx', nx.toFixed(3));
        c.style.setProperty('--ty', ny.toFixed(3));
        c.style.setProperty('--th', '1');
        c.style.setProperty('--gx', gx.toFixed(1) + '%');
        c.style.setProperty('--gy', gy.toFixed(1) + '%');
      }
      c.addEventListener('pointermove', function (e) {
        if (e.pointerType !== 'mouse') return;
        var r = c.getBoundingClientRect();
        nx = (e.clientX - r.left) / r.width * 2 - 1;
        ny = (e.clientY - r.top) / r.height * 2 - 1;
        gx = (e.clientX - r.left) / r.width * 100;
        gy = (e.clientY - r.top) / r.height * 100;
        c.classList.add('fx-live');
        if (!raf) raf = requestAnimationFrame(paint);
      }, { passive: true });
      c.addEventListener('pointerleave', function () {
        c.classList.remove('fx-live');
        nx = ny = 0;
        c.style.setProperty('--tx', '0');
        c.style.setProperty('--ty', '0');
        c.style.setProperty('--th', '0');
      });
    });
  })();
})();

/* le choix de langue se retient d'une page à l'autre */
(function () {
  var l = document.documentElement.lang;
  if (l) { try { localStorage.setItem('clel-lang', l.slice(0, 2)); } catch (e) {} }
})();

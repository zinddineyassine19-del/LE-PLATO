#!/usr/bin/env python3
"""Passe en revue les 59 schémas et signale tout texte qui en chevauche un autre
ou qui déborde du cadre. Indispensable après un changement de caractère :
les largeurs ne sont plus les mêmes."""
import asyncio, json, os, sys, glob
import os as _os
ICI = _os.path.dirname(_os.path.abspath(__file__))
RACINE = _os.path.dirname(ICI)            # le dossier du dépôt

from playwright.async_api import async_playwright

JS = r"""
() => {
  var out = [];
  document.querySelectorAll('figure svg').forEach(function (svg, si) {
    var fig = svg.closest('figure');
    var head = fig.querySelector('figcaption b, .ix-head b');
    var name = head ? head.textContent.trim().slice(0, 22) : ('svg#' + si);
    var vb = svg.viewBox && svg.viewBox.baseVal;
    var ts = [];
    svg.querySelectorAll('text').forEach(function (t) {
      if (!t.textContent.trim()) return;
      var st = getComputedStyle(t);
      if (st.display === 'none' || st.visibility === 'hidden' || +st.opacity < 0.08) return;
      var g;
      try { g = t.getBBox(); } catch (e) { return; }
      if (!g.width || !g.height) return;
      // position réelle dans le repère du svg (les <g transform> comptent)
      var m = t.getScreenCTM(), r = svg.getScreenCTM();
      if (m && r) {
        var inv = r.inverse().multiply(m);
        var p1 = new DOMPoint(g.x, g.y).matrixTransform(inv);
        var p2 = new DOMPoint(g.x + g.width, g.y + g.height).matrixTransform(inv);
        g = {x: Math.min(p1.x, p2.x), y: Math.min(p1.y, p2.y),
             width: Math.abs(p2.x - p1.x), height: Math.abs(p2.y - p1.y)};
      }
      ts.push({s: t.textContent.trim().slice(0, 26), x: g.x, y: g.y, w: g.width, h: g.height});
    });
    var bad = [];
    for (var i = 0; i < ts.length; i++) {
      var a = ts[i];
      if (vb && vb.width) {
        if (a.x < vb.x - 1.5 || a.x + a.w > vb.x + vb.width + 1.5)
          bad.push({type: 'déborde', a: a.s, x: Math.round(a.x), r: Math.round(a.x + a.w)});
      }
      for (var j = i + 1; j < ts.length; j++) {
        var b = ts[j];
        var oy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
        var ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
        if (oy > 0.45 * Math.min(a.h, b.h) && ox > 1.5)
          bad.push({type: 'chevauche', a: a.s, b: b.s, ox: Math.round(ox)});
      }
    }
    if (bad.length) out.push({fig: name, n: bad.length, cas: bad.slice(0, 6)});
  });
  return out;
}
"""


async def main():
    FR = _os.path.join(RACINE, "site", "fr")
    pages = sorted(glob.glob(_os.path.join(FR, "ch*.html"))) + \
            [_os.path.join(FR, "annexe-a.html"),
             _os.path.join(FR, "annexe-b.html"),
             # le livre lui-même : c'est lui qui garde les schémas statiques que le
             # site remplace par leur version pilotable — et c'est lui qui fait le PDF
             _os.path.join(RACINE, "fr", "le-plateau-fr.html")]
    errs, found = [], []
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/opt/pw-browsers/chromium")
        pg = await b.new_page(viewport={"width": 1280, "height": 1000})
        pg.on("pageerror", lambda e: errs.append(str(e)))
        for f in pages:
            await pg.goto("file://" + f)
            await pg.evaluate("async()=>{await document.fonts.ready;}")
            await pg.wait_for_timeout(260)
            r = await pg.evaluate(JS)
            for x in r:
                x["page"] = os.path.basename(f)
                found.append(x)
        await b.close()
    print(json.dumps(found, ensure_ascii=False, indent=1))
    print("pages :", len(pages), "· schémas en défaut :", len(found))
    print("erreurs JS :", errs[:6])


asyncio.run(main())

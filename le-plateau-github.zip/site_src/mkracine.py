#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""La racine du site : le choix de la langue, le mode d'emploi, les réglages.

Ces trois fichiers étaient écrits à la main, ce qui voulait dire qu'une
construction partant d'un dossier vide donnait un site sans porte d'entrée.
Ils se fabriquent maintenant comme le reste.

    python3 mkracine.py
"""
import os
import shutil

ICI = os.path.dirname(os.path.abspath(__file__))
RACINE = os.path.dirname(ICI)
OUT = os.path.join(RACINE, "site")
os.makedirs(OUT, exist_ok=True)

import i18n

TITRES = " · ".join(i18n.S["titre"][L] for L in i18n.LANGS)

PAGE = """<!doctype html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%(titres)s</title>
<meta name="description" content="%(desc)s">
<link rel="alternate" hreflang="fr" href="fr/index.html">
<link rel="alternate" hreflang="en" href="en/index.html">
<link rel="alternate" hreflang="ar" href="ar/index.html">
<link rel="alternate" hreflang="x-default" href="fr/index.html">
<link rel="icon" href="data:image/svg+xml,%%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%%3E%%3Ccircle cx='16' cy='16' r='15' fill='%%23101520'/%%3E%%3Ccircle cx='16' cy='16' r='7' fill='none' stroke='%%23E5A63E' stroke-width='2.5'/%%3E%%3C/svg%%3E">
<style>
html{color-scheme:dark;background:#0C0F14;color:#E7EBF2}
body{margin:0;min-height:100svh;display:grid;place-items:center;
  font:16px/1.6 system-ui,sans-serif;padding:24px}
.c{text-align:center;max-width:32rem}
h1{font:600 clamp(24px,5vw,34px)/1.15 Georgia,serif;margin:0 0 10px}
p{color:#8A94A3;margin:0 0 26px;font-size:15px}
.g{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
a{display:block;min-width:132px;padding:14px 20px;border-radius:10px;
  border:1px solid #2B3441;color:#E7EBF2;text-decoration:none;
  transition:border-color .15s,background .15s}
a:hover,a:focus-visible{border-color:#E5A63E;background:rgba(229,166,62,.08);outline:none}
a b{display:block;font-size:17px}
a span{font-size:12px;color:#8A94A3;font-family:ui-monospace,monospace}
</style></head>
<body><div class="c">
<h1>%(titre_fr)s</h1>
<p>%(invite)s</p>
<div class="g">
%(liens)s
</div>
</div>
<script>
/* On envoie le visiteur dans sa langue sans qu'il ait à choisir — mais le
   choix reste affiché pour ceux qui arrivent sans JavaScript. */
(function () {
  var L = null;
  try { L = localStorage.getItem("clel-lang"); } catch (e) {}
  if (!L) {
    var n = (navigator.languages || [navigator.language || "fr"]).join(",").toLowerCase();
    L = /(^|,)ar/.test(n) ? "ar" : (/(^|,)en/.test(n) ? "en" : "fr");
  }
  if (["fr", "en", "ar"].indexOf(L) < 0) L = "fr";
  location.replace(L + "/index.html");
})();
</script>
</body></html>
"""

liens = "\n".join(
    '  <a href="%s/index.html" hreflang="%s" lang="%s"><b>%s</b><span>%s</span></a>'
    % (L, L, L, i18n.NOM[L], L.upper()) for L in i18n.LANGS)

open(os.path.join(OUT, "index.html"), "w", encoding="utf-8").write(
    PAGE % {"titres": TITRES, "titre_fr": i18n.S["titre"]["fr"],
            "desc": "Manuel illustré de prise de vues, de lumière, de son et "
                    "de montage. Français · English · العربية.",
            "invite": "Choisissez votre langue · Choose your language · اختر لغتك",
            "liens": liens})

# le mode d'emploi voyage avec le site
shutil.copy(os.path.join(ICI, "LISEZ-MOI.txt"), os.path.join(OUT, "LISEZ-MOI.txt"))

# Les réglages Netlify, pour qui dépose le dossier à la main. Quand le dépôt
# en a déjà un à sa racine (le cas quand on passe par Git), celui-là fait foi
# et on n'en met pas un second dans le site.
_n = os.path.join(ICI, "netlify.site.toml")
_deja = os.path.exists(os.path.join(RACINE, "netlify.toml"))
if os.path.exists(_n) and not _deja:
    shutil.copy(_n, os.path.join(OUT, "netlify.toml"))
elif _deja:
    _v = os.path.join(OUT, "netlify.toml")
    if os.path.exists(_v):
        os.remove(_v)

print("racine du site : index.html, LISEZ-MOI.txt" +
      ("" if _deja else ", netlify.toml"))

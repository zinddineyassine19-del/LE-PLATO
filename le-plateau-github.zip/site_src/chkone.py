#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Épreuve du fichier unique : les trois langues, le débordement, les erreurs."""
import asyncio, json
import os as _os
ICI = _os.path.dirname(_os.path.abspath(__file__))
RACINE = _os.path.dirname(ICI)            # le dossier du dépôt

from playwright.async_api import async_playwright

F = "file://" + _os.path.join(RACINE, "sortie", "le-plateau-site.html")


async def main():
    errs, rap = [], {}
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/opt/pw-browsers/chromium")
        pg = await b.new_page(viewport={"width": 1280, "height": 900})
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console:" + m.text) if m.type == "error" else None)
        await pg.goto(F)
        await pg.evaluate("async()=>{await document.fonts.ready}")
        await pg.wait_for_timeout(500)

        rap["langues visibles au chargement"] = await pg.evaluate(
            "()=>[...document.querySelectorAll('.L')].filter(d=>!d.hidden).map(d=>d.dataset.l)")

        for lang in ("ar", "en", "fr"):
            ok = await pg.evaluate(
                """(l)=>{var a=document.querySelector('.L:not([hidden]) .langsel [data-go="'+l+'"]');
                         if(!a) return false; a.click(); return true;}""", lang)
            await pg.wait_for_timeout(350)
            st = await pg.evaluate(
                """()=>({lang:document.documentElement.lang,dir:document.documentElement.dir,
                        vis:[...document.querySelectorAll('.L')].filter(d=>!d.hidden).map(d=>d.dataset.l),
                        h1:(document.querySelector('.L:not([hidden]) h1')||{}).textContent})""")
            rap["clic → " + lang] = {"bouton trouvé": ok, **st}

            for w, h in ((1280, 900), (390, 780)):
                await pg.set_viewport_size({"width": w, "height": h})
                await pg.wait_for_timeout(220)
                ov = await pg.evaluate(
                    """(w)=>{var o=[];document.querySelectorAll('.L:not([hidden]) *').forEach(function(e){
                        var r=e.getBoundingClientRect();
                        if(r.width&&(r.right>w+1.5||r.left<-1.5))
                          o.push((e.tagName+'.'+(e.className.baseVal!==undefined?e.className.baseVal:e.className)).slice(0,40)
                                 +' ['+Math.round(r.left)+'→'+Math.round(r.right)+']');});
                       return {dx:document.documentElement.scrollWidth-w,n:o.length,ex:o.slice(0,5)};}""", w)
                rap["débord %s @%d" % (lang, w)] = ov
            await pg.set_viewport_size({"width": 1280, "height": 900})

        # retour au français pour compter le livre
        await pg.evaluate("""()=>document.querySelector('.L:not([hidden]) .langsel [data-go="fr"]').click()""")
        await pg.wait_for_timeout(300)
        rap["chapitres fr"] = await pg.evaluate(
            """()=>document.querySelectorAll('.L[data-l="fr"] section.ch').length""")
        rap["figures fr"] = await pg.evaluate(
            """()=>document.querySelectorAll('.L[data-l="fr"] figure svg').length""")
        rap["mots de vente restants"] = await pg.evaluate(
            r"""()=>{var t=document.body.innerText;
                 return ['Payer','Paiement','199','Acheter','Débloquer','verrou']
                        .filter(function(w){return t.indexOf(w)>=0});}""")
        # un lien interne au hasard doit bien descendre
        await pg.evaluate("""()=>{var a=document.querySelector('.L[data-l="fr"] a[href="#c39"]');
                                  if(a) a.click();}""")
        await pg.wait_for_timeout(600)
        rap["saut vers c39 (scrollY)"] = await pg.evaluate("()=>Math.round(scrollY)")
        await b.close()
    print(json.dumps(rap, ensure_ascii=False, indent=1))
    print("erreurs JS :", errs[:8])


asyncio.run(main())

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Construit le site « Le Plateau » à partir du livre HTML.

  python3 mksite.py --lang=fr   (ou en, ar)

Le livre est libre : tout le texte, tous les schémas et le PDF sont publiés.
"""
import re, os, json, html as H, shutil, sys, unicodedata
from urllib.parse import quote
import os as _os
ICI = _os.path.dirname(_os.path.abspath(__file__))
RACINE = _os.path.dirname(ICI)            # le dossier du dépôt


LANG = "fr"
for _a in sys.argv:
    if _a.startswith("--lang="):
        LANG = _a.split("=", 1)[1]
assert LANG in ("fr", "en", "ar"), LANG

import i18n, mkml
def T(k):
    """Une chaîne de l'habillage, dans la langue en cours."""
    v = mkml.TABLES.get(k)
    assert v, "clé inconnue : " + k
    return v.get(LANG) or v["fr"]
RTL = (i18n.DIR[LANG] == "rtl")

BOOK = _os.path.join(RACINE, "fr", "le-plateau-fr.html")
SRC = ICI
OUT = _os.path.join(RACINE, "site", LANG)
PDF = _os.path.join(RACINE, "sortie", "Le-Plateau.pdf")

shutil.rmtree(OUT, ignore_errors=True)

os.makedirs(OUT + "/assets", exist_ok=True)
book = open(BOOK, encoding="utf-8").read()

# --- les figures pilotables remplacent leur version statique (site seulement) ---
IX = {"Fig. 2.1": "fig2-1.html", "Fig. 3.1": "fig3-1.html",
      "Fig. 4.1": "fig4-1.html", "Fig. 5.1": "fig5-1.html",
      "Fig. 8.1": "fig8-1.html", "Fig. 9.1": "fig9-1.html",
      "Fig. 10.1": "fig10-1.html", "Fig. 13.1": "fig13-1.html",
      "Fig. 14.1": "fig14-1.html", "Fig. 15.1": "fig15-1.html",
      "Fig. 28.1": "fig28-1.html", "Fig. 29.1": "fig29-1.html",
      "Fig. 30.1": "fig30-1.html", "Fig. 31.1": "fig31-1.html",
      "Fig. 32.1": "fig32-1.html", "Fig. 33.1": "fig33-1.html",
      "Fig. 6.1": "fig6-1.html"}
for tag, fn in IX.items():
    pat = re.compile(r"<figure>(?:(?!</figure>).)*?<b>" + re.escape(tag) + r"</b>.*?</figure>", re.S)
    repl = open(os.path.join(SRC, "fx", fn), encoding="utf-8").read().rstrip()
    if "/*@PLANS@*/null" in repl:
        repl = repl.replace("/*@PLANS@*/null", open(
            os.path.join(SRC, "fx", "plans_svg.json"),
            encoding="utf-8").read().replace("</", "<\\/"))
    book, n = pat.subn(lambda m: repl, book, count=1)
    assert n == 1, "figure interactive non trouvée : " + tag

# --- l'annexe des plans de feu : sur le site, un seul plan variable ---
_ate = open(os.path.join(SRC, "fx", "figA-1.html"), encoding="utf-8").read().rstrip()
_ate = _ate.replace("/*@PLANS@*/null", open(
    os.path.join(SRC, "fx", "plans_svg.json"), encoding="utf-8").read().replace("</", "<\\/"))
book, _n = re.subn(r"<!--PLANS-START-->.*?<!--PLANS-END-->", lambda m: _ate,
                   book, count=1, flags=re.S)
assert _n == 1, "bloc des huit plans introuvable"
print("figures pilotables :", len(IX) + 1)

# --------------------------------------------------- les corps d'une autre langue
# L'édition arabe précédente emploie les mêmes identifiants de section et la même
# structure : ses chapitres c1 à c27 et son annexe ck se replacent tels quels.
TRAD = {}
if LANG == "ar":
    _ar = open(SRC + "/ar-2024.html", encoding="utf-8").read()
    for _sid, _b in re.findall(r'<section[^>]*id="([^"]+)"[^>]*>(.*?)</section>', _ar, re.S):
        if _sid in ("c28", "gl"):      # c28 arabe est un autre chapitre, gl n'existe plus
            continue
        TRAD[_sid] = _b
_p = os.path.join(SRC, "corps_%s.json" % LANG)
if os.path.exists(_p):
    TRAD.update(json.load(open(_p, encoding="utf-8")))
print("corps disponibles en %s : %d / 44" % (LANG, len(TRAD) if LANG != "fr" else 36))

# ---------------------------------------------------------------- extraction
css = re.search(r"<style>(.*?)</style>", book, re.S).group(1)
defs = re.search(r"(<svg width=\"0\".*?</svg>)", book, re.S).group(1)
secs = re.findall(r'(<section class="ch" id="[^"]+">.*?</section>)', book, re.S)
assert len(secs) == 44, len(secs)

meta = []
for s in secs:
    m = re.search(r'id="([^"]+)">\s*<header class="ch-h"><span class="ch-n">([^<]*)</span>'
                  r'<div><h2>(.*?)</h2><p class="lat">(.*?)</p>', s, re.S)
    meta.append({"id": m.group(1), "n": m.group(2).strip(),
                 "t": m.group(3), "lat": m.group(4), "body": s})

PARTS = [(p["tag"][LANG], p["nom"][LANG], p["desc"][LANG], r)
         for p, r in zip(i18n.PARTIES,
                         [range(0, 10), range(10, 19), range(19, 27),
                          range(27, 33), range(33, 38), range(38, 42)])]
ANNEX = [(42, i18n.ANNEXES_D[0][LANG]), (43, i18n.ANNEXES_D[1][LANG])]

def fname(i):
    d = meta[i]
    if d["id"] == "pf": return "annexe-a.html"
    if d["id"] == "ck": return "annexe-b.html"
    return "ch%02d.html" % int(d["n"])

def label(i):
    d = meta[i]
    q = T("s.annexe") if d["id"] in ("pf", "ck") else T("s.chapitre")
    return q + " " + d["n"]

def part_of(i):
    for (tag, nom, _d, rng) in PARTS:
        if i in rng:
            return tag + " · " + nom
    return T("s.annexes")

# ---------------------------------------------------------------- assets
open(OUT + "/assets/book.css", "w", encoding="utf-8").write(
    css + "\n\n" + open(SRC + "/chrome.css", encoding="utf-8").read()
        + "\n\n" + open(SRC + "/fx/ix.css", encoding="utf-8").read()
        + "\n\n" + open(SRC + "/fx/motion.css", encoding="utf-8").read()
        + "\n\n" + open(SRC + "/fx/acces.css", encoding="utf-8").read())
open(OUT + "/assets/site.js", "w", encoding="utf-8").write(
    open(SRC + "/site.js", encoding="utf-8").read()
    + "\n\n" + open(SRC + "/fx/motion.js", encoding="utf-8").read()
    + "\n\n" + open(SRC + "/fx/ambient.js", encoding="utf-8").read())

# La musique de fond : un seul fichier pour les trois langues, à la racine.
# L'adresse est relative à la PAGE (site/<langue>/x.html), pas au script.
_amb = os.path.join(SRC, "assets", "ambiance.mp3")
if os.path.exists(_amb):
    shutil.copy(_amb, os.path.join(RACINE, "site", "ambiance.mp3"))
    with open(OUT + "/assets/site.js", "r+", encoding="utf-8") as _f:
        _t = _f.read(); _f.seek(0)
        _f.write('window.CLEL_AMBIANCE="../ambiance.mp3";\n' + _t)
# le portrait de l'accueil, gardé à la source pour survivre à une reconstruction
for _f in ("portrait.png", "portrait.webp"):
    _src = os.path.join(SRC, "assets", _f)
    if os.path.exists(_src):
        shutil.copy(_src, OUT + "/assets/" + _f)
    else:
        assert os.path.exists(OUT + "/assets/" + _f), "portrait manquant : " + _f

# Le PDF est le même pour les trois langues : une seule copie, à la racine du
# site, et chaque langue y renvoie. Trois copies pesaient huit mégaoctets de plus.
if os.path.exists(PDF):
    shutil.copy(PDF, os.path.dirname(OUT.rstrip("/")) + "/Le-Plateau.pdf")
    _vieux = OUT + "/Le-Plateau.pdf"
    if os.path.exists(_vieux):
        os.remove(_vieux)

# ---------------------------------------------------------------- index de recherche
def plain(s):
    s = re.sub(r"<(svg|figure)\b.*?</\1>", " ", s, flags=re.S)
    s = re.sub(r"<[^>]+>", " ", s)
    s = H.unescape(s)
    return re.sub(r"\s+", " ", s).strip()

def fold(s):
    s = s.lower()
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn")

def langsel():
    """Les trois langues, chacune pointant sur la même page dans son dossier."""
    return ('<div class="langsel" role="group" aria-label="%s">' % T("s.langue_aria")
            + "".join('<a class="lang%s" href="../%s/@@PAGE@@" hreflang="%s" '
                      'lang="%s">%s</a>'
                      % (" on" if L == LANG else "", L, L, L, i18n.COURT[L])
                      for L in i18n.LANGS) + "</div>")


# -------------------------------------------------- le panneau « pas traduit »
# Le livre est libre : plus aucun cadenas nulle part. Un chapitre qui n'existe
# pas encore dans une langue le dit sous un globe, pas sous une serrure.
LOCKSVG = ('<svg class="lock-i" viewBox="0 0 24 24" aria-hidden="true">'
           '<circle cx="12" cy="12" r="9"/>'
           '<path d="M3 12h18M12 3c2.6 2.6 2.6 15.4 0 18M12 3C9.4 5.6 9.4 18.4 12 21"/>'
           '</svg>')


# ---------------------------------------------------------------- fragments partagés
TOPBAR = ("""<div class="progress" aria-hidden="true"></div>
<header class="topbar">
  <div class="topbar-in">
    <button class="iconbtn" id="menuBtn" aria-label="@@T:s.menu_aria@@">
      <svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
    </button>
    <a class="brand" href="index.html"><span class="mark"></span>@@T:s.titre@@</a>
    <span class="spacer"></span>
    <button class="iconbtn" id="searchBtn" aria-label="@@T:s.chercher_aria@@">
      <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
      <span class="lbl">@@T:s.chercher@@</span>
    </button>
    @@LANGSEL@@
    <button class="iconbtn sonbtn" data-son type="button" aria-pressed="false"
            aria-label="@@T:s.son_aria@@" data-on="@@T:s.son_on@@" data-off="@@T:s.son_off@@">
      <svg class="i-on" viewBox="0 0 24 24"><path d="M4 9.5h3.5L12 5.5v13L7.5 14.5H4z"/><path d="M16 9.4a4 4 0 0 1 0 5.2"/><path d="M18.6 6.8a7.6 7.6 0 0 1 0 10.4"/></svg>
      <svg class="i-off" viewBox="0 0 24 24"><path d="M4 9.5h3.5L12 5.5v13L7.5 14.5H4z"/><path d="M16.5 10l4 4M20.5 10l-4 4"/></svg>
      <span class="lbl">@@T:s.son_on@@</span>
    </button>
    <button class="iconbtn" id="themeBtn" aria-label="@@T:s.theme_aria@@" data-jour="@@T:s.jour@@" data-nuit="@@T:s.nuit@@">
      <svg class="i-sun" viewBox="0 0 24 24" style="display:none"><circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4"/></svg>
      <svg class="i-moon" viewBox="0 0 24 24"><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z"/></svg>
      <span class="lbl">@@T:s.nuit@@</span>
    </button>
  </div>
</header>
<div class="scrim" aria-hidden="true"></div>""")

def _tr(x):
    x = re.sub(r"@@T:([a-z]+\.[a-z_]+)@@", lambda m: T(m.group(1)), x)
    return re.sub(r"@@TL:([a-z]+\.[a-z_]+)@@", lambda m: T(m.group(1)).lower(), x)

TOPBAR = _tr(TOPBAR).replace("@@LANGSEL@@", langsel())

ZOOMDLG = _tr("""<div class="zdlg" id="zdlg" role="dialog" aria-modal="true" aria-label="@@T:s.schema_grand@@">
  <div class="zdlg-bar">
    <span id="zdlgN">@@T:s.schema@@</span><span class="sp"></span>
    <button class="ix-b" type="button" id="zOut">−</button>
    <button class="ix-b" type="button" id="zFit">@@T:s.ajuster@@</button>
    <button class="ix-b" type="button" id="zIn">+</button>
    <button class="ix-b" type="button" id="zClose">@@T:s.fermer@@</button>
  </div>
  <div class="zdlg-wrap" id="zWrap"></div>
  <p class="zdlg-cap" id="zCap"></p>
</div>""")

SEARCH = _tr("""<div class="sdlg" id="sdlg" role="dialog" aria-modal="true" aria-label="@@T:s.chercher_aria@@" data-vide="@@T:s.aucun_res@@">
  <div class="sbox">
    <input type="search" placeholder="@@T:s.chercher_ph@@" autocomplete="off" spellcheck="false">
    <div class="sres"></div>
    <div class="shint"><span><kbd>↑</kbd><kbd>↓</kbd> @@T:s.naviguer@@</span><span><kbd>↵</kbd> @@T:s.ouvrir@@</span><span><kbd>Esc</kbd> @@T:s.fermer@@</span><span><kbd>←</kbd><kbd>→</kbd> @@TL:s.chapitre@@</span></div>
  </div>
</div>""")

def sidebar(cur=None, anchors=False):
    o = ['<nav class="side" aria-label="%s">' % T("s.sommaire")]
    for tag, name, _d, rng in PARTS:
        o.append('<p class="part">%s · %s</p><ol>' % (tag, name))
        for i in rng:
            o.append(lien(i, cur, anchors))
        o.append("</ol>")
    o.append('<p class="part">%s</p><ol>' % T("s.annexes"))
    for i, _ in ANNEX:
        o.append(lien(i, cur, anchors))
    o.append("</ol>")
    o.append("</nav>")
    return "\n".join(o)


def titre_de(i):
    """Le titre du chapitre dans la langue en cours."""
    h = entete(i)
    m = re.search(r"<h2>(.*?)</h2>", h, re.S)
    return m.group(1) if m else meta[i]["t"]


def lien(i, cur, anchors):
    href = ("#" + meta[i]["id"]) if anchors else fname(i)
    cu = ' aria-current="page"' if (not anchors and fname(i) == cur) else ""
    return ('<li><a href="%s"%s><b>%s</b><span>%s</span></a></li>'
            % (href, cu, meta[i]["n"], titre_de(i)))

HEAD = """<!doctype html>
<html lang="%(lg)s" dir="%(dr)s">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%(title)s — %(marque)s</title>
<meta name="description" content="%(desc)s">
<meta name="author" content="Yassine Zineddine"><link rel="stylesheet" href="assets/book.css">
<link rel="icon" href="data:image/svg+xml,%%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%%3E%%3Ccircle cx='16' cy='16' r='15' fill='%%23101520'/%%3E%%3Ccircle cx='16' cy='16' r='7' fill='none' stroke='%%23E5A63E' stroke-width='2.5'/%%3E%%3C/svg%%3E">
<style>@page{size:A4;margin:16mm 13mm}</style>
</head>
<body>
"""

FOOT = ('<p class="foot"><span>%s</span><span><a href="index.html">%s</a> · '
        '<a href="../Le-Plateau.pdf" download>PDF</a> · '
        '<a href="livre-complet.html">%s</a></span></p>'
        % (T("s.droits"), T("s.accueil"), T("s.tout_page")))

TAIL = ('\n%s\n%s\n<script src="assets/search-index.js"></script>\n'
        '<script src="assets/site.js"></script>\n</body>\n</html>\n')

def corps_brut(i):
    """Le corps dans la langue demandée, ou None s'il n'existe pas encore."""
    if LANG == "fr":
        return meta[i]["body"]
    b = TRAD.get(meta[i]["id"])
    if not b:
        return None
    return '<section class="ch" id="%s">%s</section>' % (meta[i]["id"], b)


def entete(i):
    """L'en-tête du chapitre : son numéro, son titre, son sous-titre."""
    d = meta[i]
    b = corps_brut(i)
    if b:
        m = re.search(r"(<header class=\"ch-h\">.*?</header>)", b, re.S)
        if m:
            return m.group(1)
    # pas de traduction : on garde le numéro, on prend le titre anglais du livre
    t = d["lat"] if LANG == "en" else d["t"]
    return ('<header class="ch-h"><span class="ch-n">%s</span><div><h2>%s</h2>'
            '<p class="lat">%s</p></div></header>'
            % (d["n"], t, d["t"] if LANG == "en" else d["lat"]))


def _dispo(L):
    """Les identifiants de section réellement écrits dans la langue L."""
    if L == "fr":
        return {d["id"] for d in meta}
    ids = set()
    if L == "ar":
        _a = open(SRC + "/ar-2024.html", encoding="utf-8").read()
        ids |= {m for m in re.findall(r'<section[^>]*id="([^"]+)"', _a)
                if m not in ("c28", "gl")}
    _p = os.path.join(SRC, "corps_%s.json" % L)
    if os.path.exists(_p):
        ids |= set(json.load(open(_p, encoding="utf-8")).keys())
    return ids


DISPO = {L: _dispo(L) for L in i18n.LANGS}


def pas_traduit(i):
    """Le panneau d'un chapitre qui n'existe pas encore dans cette langue.

    On ne renvoie que vers les langues où le chapitre existe vraiment :
    proposer une porte qui donne sur le même panneau serait se moquer du monde.
    """
    autres = [L for L in i18n.LANGS
              if L != LANG and meta[i]["id"] in DISPO[L]]
    liens = " \u00b7 ".join('<a href="../%s/%s">%s</a>' % (L, fname(i), i18n.NOM[L])
                            for L in autres)
    return ('<section class="ch" id="%s">%s\n'
            '<div class="lock todo">%s'
            '<p class="lock-k">%s</p>'
            '<h3 class="lock-t">%s</h3>'
            '<p class="lock-d">%s</p>'
            '<p class="lock-f">%s %s</p>'
            "</div>\n</section>"
            % (meta[i]["id"], entete(i), LOCKSVG, T("t.k"), T("t.t"), T("t.d"),
               T("t.lire"), liens))


def corps_de(i):
    """Le corps tel qu'il paraît : entier, ou pas encore traduit."""
    b = corps_brut(i)
    return pas_traduit(i) if b is None else b

# ------------------------------------------------------- index de recherche
# On indexe ce que le lecteur a vraiment sous les yeux : le titre et le texte
# dans SA langue. Indexer le français sous un habillage arabe donnait une
# recherche qui ne trouvait rien et affichait des titres étrangers.
index = []
for i, d in enumerate(meta):
    corps = corps_brut(i)
    t = H.unescape(re.sub(r"<[^>]+>", "", titre_de(i)))
    if corps is None:
        # pas encore traduit : on l'indexe par son titre, et on le dit. Servir
        # un paragraphe français sous un titre anglais n'aide personne.
        txt, lead = "", T("t.t")
    else:
        txt = plain(corps)
        lead = re.search(r'<p class="lead">(.*?)</p>', corps, re.S)
        lead = plain(lead.group(1)) if lead else txt[:160]
    index.append({"u": fname(i), "n": label(i), "t": t, "l": lead,
                  "b": txt, "tf": fold(t + " " + H.unescape(d["lat"])), "bf": fold(txt)})
open(OUT + "/assets/search-index.js", "w", encoding="utf-8").write(
    "window.BOOK_INDEX=" + json.dumps(index, ensure_ascii=False, separators=(",", ":")) + ";")


# ---------------------------------------------------------------- pages de chapitre
for i, d in enumerate(meta):
    f = fname(i)
    title = H.unescape(re.sub(r"<[^>]+>", "", d["t"]))
    desc = H.unescape(index[i]["l"])[:180].replace('"', "'")
    pager = ['<nav class="pager" aria-label="Navigation entre chapitres">']
    if i > 0:
        pager.append('<a class="prv" href="%s"><span class="dir">← %s</span>'
                     '<span class="ttl">%s</span></a>'
                     % (fname(i - 1), label(i - 1), titre_de(i - 1)))
    else:
        pager.append('<a class="prv ghost" href="#" tabindex="-1" aria-hidden="true">'
                     '<span class="dir">—</span><span class="ttl">—</span></a>')
    if i < len(meta) - 1:
        pager.append('<a class="nxt" href="%s"><span class="dir">%s →</span>'
                     '<span class="ttl">%s</span></a>'
                     % (fname(i + 1), label(i + 1), titre_de(i + 1)))
    else:
        pager.append('<a class="nxt" href="index.html"><span class="dir">%s →</span>'
                     '<span class="ttl">%s</span></a>' % (T("s.retour"), T("s.accueil")))
    pager.append("</nav>")

    corps = corps_de(i)
    page = (HEAD % {"title": "%s · %s" % (label(i), title), "desc": desc,
                    "lg": i18n.HTMLLANG[LANG], "dr": i18n.DIR[LANG],
                    "marque": T("s.titre")}
            + TOPBAR + "\n" + defs + '\n<div class="shell">\n' + sidebar(cur=f)
            + '\n<main class="artmain">\n'
            + '<p class="crumb"><a href="index.html">%s</a> · %s · %s</p>\n'
              % (T("s.accueil"), part_of(i), label(i))
            + corps + "\n" + "\n".join(pager) + "\n" + FOOT
            + "\n</main>\n</div>")
    open(os.path.join(OUT, f), "w", encoding="utf-8").write(
        (page + TAIL % (SEARCH + "\n" + ZOOMDLG, "")).replace("@@PAGE@@", f))

# ---------------------------------------------------------------- livre complet
# Dans la vitrine il existe aussi, mais fait des mêmes corps réduits : il ne
# contient donc pas une ligne de plus que les pages de chapitre.
full = (HEAD % {"title": T("s.livre_complet"), "desc": T("s.tout_page"),
                "lg": i18n.HTMLLANG[LANG], "dr": i18n.DIR[LANG],
                "marque": T("s.titre")}
        + TOPBAR + "\n" + defs + '\n<div class="shell">\n' + sidebar(anchors=True)
        + '\n<main class="artmain">\n'
        + '<p class="crumb"><a href="index.html">Accueil</a> · Le livre complet</p>\n'
        + "\n".join(corps_de(i) for i in range(len(meta))) + "\n" + FOOT + "\n</main>\n</div>")
open(OUT + "/livre-complet.html", "w", encoding="utf-8").write(
    (full + TAIL % (SEARCH + "\n" + ZOOMDLG, "")).replace("@@PAGE@@", "livre-complet.html"))

# ---------------------------------------------------------------- accueil
tpl = mkml.rendre(open(SRC + "/index.tpl.html", encoding="utf-8").read(), LANG)
tpl = tpl.replace('<html lang="fr" dir="ltr">',
                  '<html lang="%s" dir="%s">' % (i18n.HTMLLANG[LANG], i18n.DIR[LANG]))
cards = []
for tag, name, dsc, rng in PARTS:
    li = "".join('<li><a href="%s"><b>%s</b><span>%s</span></a></li>'
                 % (fname(i), meta[i]["n"], meta[i]["t"]) for i in rng)
    cards.append('<article class="pcard"><p class="pn">%s</p><h3>%s</h3>'
                 '<p class="pd">%s</p><ol>%s</ol></article>' % (tag, name, dsc, li))
ann = "".join('<a class="acard" href="%s"><span class="an">Annexe %s</span>'
              '<h4>%s</h4><p>%s</p></a>' % (fname(i), meta[i]["n"], meta[i]["t"], dsc)
              for i, dsc in ANNEX)
tpl = tpl.replace("<!--PARTS-->", "\n".join(cards)).replace("<!--ANNEX-->", ann)

# le sélecteur de langue dans la barre du haut de l'accueil
_sel = langsel()
tpl = tpl.replace('<button class="iconbtn sonbtn"', _sel + '\n<button class="iconbtn sonbtn"', 1)


open(OUT + "/index.html", "w", encoding="utf-8").write(tpl.replace("@@PAGE@@", "index.html"))

print("pages :", len(os.listdir(OUT)) )
for f in sorted(os.listdir(OUT)):
    p = os.path.join(OUT, f)
    if os.path.isfile(p):
        print("  %-28s %7.1f Ko" % (f, os.path.getsize(p) / 1024))
print("  assets/:", ", ".join(sorted(os.listdir(OUT + "/assets"))))
